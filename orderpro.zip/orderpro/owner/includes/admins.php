<?php
if(isset($_GET['act']) && $_GET['act']=='delete' && $_GET['id'])
{
	$delete="delete from admin where id=".(int)$_GET['id'];
	$db->query($delete);
	$general->redirect('index.php?p=agents&msg=3');
}
if(isset($_GET['act']) && $_GET['act']=='st' && $_GET['id'])
{
	$delete="update admin set inactive='".$_GET['inactive']."' where id=".(int)$_GET['id'];
	$db->query($delete);
	$general->redirect('index.php?p=agents&msg=5');
}
?>

<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-10">
    <h2>Admins</h2>
    <ol class="breadcrumb">
      <li> <a href="index.php">Home</a> </li>
      <li class="active"> <strong>Admins</strong> </li>
    </ol>
  </div>
  <div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
  <div class="row">
    <div class="col-lg-12">
  <?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
  <?php if($_GET['msg']<>3) {?>
  <div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <?php if($_GET['msg']==1) { ?>
    Admin added successfully.
    <?php } else if($_GET['msg']==2) {?>
    Admin updated successfully.
    <?php } else if($_GET['msg']==4) {?>
    Admin already exist.
    <?php } else if($_GET['msg']==5) {?>
    Admin status changed successfully.
    <?php } ?>
  </div>
  <?php } ?>
  <?php if($_GET['msg']==3){?>
  <div class="alert alert-error">
    <button type="button" class="close" data-dismiss="alert">×</button>
    Admin deleted successfully. </div>
  <?php } ?>
  <?php } ?>
  <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>Admins</h5>
        </div>
        <div class="ibox-content">
          <div class="table-responsive">
            <table class="table table-striped table-bordered table-hover dataTables-example" >
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
			$query = "select * from admin where user_role='agent'";
			$count = $db->num_rows($query);
			if($count){
				$i=1; 
				$rows = $db->get_results($query);
				foreach($rows as $row) { 
				?>
                <tr class="odd gradeX">
                  <td><?php echo $row['id']; ?></td>
                  <td><?php echo $row['name']; ?></td>
                  <td><?php echo $row['email']; ?></td>
                  <td><?php echo $row['phone']; ?></td>
                  <td>
				  <?php if($row['inactive']==0){?>
                  <a href='index.php?p=agents&act=st&id=<?php echo $row["id"];?>&inactive=1' onclick="if(!confirm('Are you sure you want to change status.')) return false;"><span class="label label-success">Active</span></a>
                  <?php }else{ ?>
                  <a href='index.php?p=agents&act=st&id=<?php echo $row["id"];?>&inactive=0' onclick="if(!confirm('Are you sure you want to delete status.')) return false;"><span class="label label-danger">Inactive</span></a>
                  <?php } ?>
                  </td>
                  <td><a href='index.php?p=agent&id=<?php echo $row["id"]; ?>'>
                <button class="btn btn-primary btn-xs tooltip-top"  data-original-title="Edit"><i class="fa fa-pencil"></i></button>
                </a><a href='index.php?p=agents&act=delete&id=<?php echo $row["id"];?>' onclick="if(!confirm('Are you sure you want to delete this user.')) return false;">
                <button class="btn btn-danger btn-xs tooltip-top"  data-original-title="Delete"><i class="fa fa-trash-o "></i></button>
                </a></td>
                </tr>
            <?php $i++; } } else { ?>
            <tr class="even gradeC">
              <td colspan="6" align="center">No Admins Found</td>
            </tr>
            <?php } ?>
          </tbody>
        </table>
       </div>
        </div>
      </div>
    </div>
  </div>
</div>