<?php
	
	date_default_timezone_set('ASIA/KOLKATA');
	$date = date('d/m/Y');
	global $db;
	
?>

<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-12" align="center">
		<h2>
			<?php //if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
		COLLECTION REPORT</h2>
	<!--	<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong>
				<?php// if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
			Punching Report</strong> </li>
		</ol>-->
	</div>
	<!--<div class="col-lg-2"> </div> -->
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	
	
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>      
				<?php if($_GET['msg']==1){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">×</button>
					Issue Added successfully. </div>
					<?php } if($_GET['msg']==4){?>
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">×</button>
					Issue Update successfully. </div>
				<?php } ?>
			<?php } ?>
			
			<div class="ibox float-e-margins">
			<!--	<div class="ibox-title">
					<h5>
						<?php //if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
					Collection Report</h5>
				</div> -->
				<div class="ibox-content">
					<form method="post" enctype="multipart/form-data">
						<div class="box-body">
							
							<div class="modal-body">
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group"><label>SELECT STAFF*</label> 
										<select name="staff" id="staff" class="form-control input-sm" style="height:35px;">
											<option value="All">ALL</option>
											<!--<option value="custom">Custom</option>-->
											<?php
												$query = "select * from usertable Where ustat = '1' ";
												$count = $db->num_rows($query);
												if($count){
													$i=1; 
													
													$rows = $db->get_results($query);
													foreach($rows as $row) { 
													?>
													<option value="<?php echo $row['uid']; ?>"><?php echo $row['staffname']; ?></option>
												<?php $i++; } } else { }?>			
												
										</select>
										<label class="help-inline" id="volume_number_view" style="color:red;"></label>
										
										</div>
									</div>											
									<div class="col-lg-6">
										<div class="form-group" id="data_5">
											<label>SELECT DATE*</label>
											<div class="input-daterange input-group" id="datepicker">
												<input type="text" class="input-sm form-control" name="start" id="start" value="<?php echo $date; ?>" readonly />
												<span class="input-group-addon">to</span>
												<input type="text" class="input-sm form-control" name="end" id="end" value="<?php echo $date; ?>" readonly />
											</div>
										</div>
									</div>
								</div>	
							</div>
                        </div>
						<div class="modal-footer">
							<input type="reset" class="btn btn-default" name="cancel" id="cancel" value="Cancel">
							<input type="button" name="btn_submit" value="Get Report" id="Update_add_Distributer" class="btn btn-info pull-right"/>
							<!--<input type="submit" id="btn_submit_m"  name="btn_submit_m"  value="confirm Order" id="btn_submit_m" class="btn btn-info pull-right"/> -->
							<input type="submit" id ="btn_submit_m" style="Display:none;" name='btn_submit_m'  value="Get Report"  class="btn btn-info pull-right"/>
						</div>
					</form>
					<div class="table-responsive" id="resultdetails">
					    
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	window.onload = function() {
	$('#Update_add_Distributer').bind('click', function() {	
		var staff =$("#staff").val();
		var start = $("#start").val();
		var end = $("#end").val();
		var action = 'get_collection';
		$("#resultdetails").html('');
		jQuery.ajax({
			url:'../api/ajax_get_role.php',
			type: "POST",
			data: {staff:staff,start:start,end:end,action:action},
			success: function(data)
			{
			    //alert(data);
				$("#resultdetails").html(data);
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	
	});
	
	
		$('.r1').bind('change', function() 
			{
				var val = $(this).val();
				if(val == '1')
				{
					$("#data_4").show();
					$("#data_5").hide();
				}
				else if(val == '2')
				{
					$("#data_4").hide();
					$("#data_5").show();
				}
			});
	};
	
</script>