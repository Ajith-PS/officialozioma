<?php
session_start();
	$id = $_SESSION['auserid'];
	global $db,$general;	
?>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2><?php// if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Feedback</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Feedback Details</strong> </li>
		</ol>
	</div>
	
	
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
				<?php if($_GET['msg']==1 || $_GET['msg']==2) {?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">�</button>
						<?php if($_GET['msg']==1) { ?>
							Order Placed successfully.
							<?php } else if($_GET['msg']==2) {?>
							Feedback Placed successfully.
							<?php } else if($_GET['msg']==4) {?>
							User already exist.
						<?php } ?>
					</div>
				<?php } ?>
				<?php if($_GET['msg']==3){?>
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">�</button>
					User deleted successfully. </div>
				<?php } ?>
			<?php } ?>
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Feedback Details</h5>
				</div>
				<div class="ibox-content">
					<div class="table-responsive">
						<div style="text-align:right; margin-bottom:10px;">
						</div>
						<table class="table table-striped table-bordered table-hover dataTables-example" >
							<thead>
								<tr>
									<th>Sl. No.</th>									
									<th>Company Name</th>
									<th>Order ID</th>
									<th>Order Date</th>                  
									<!--<th>Product Name</th>
									<th>Quantity</th>
									<th>Color</th>
									<th>Size</th>
									<th>Status</th> -->
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									
									//$query = "select * from orders where buyer_id='".$_SESSION['auserid']."' and is_deleted='0'  ORDER BY po_date DESC";
									$query = "select * from orders where status = 'Delivered' and feedstatus = '1' GROUP BY order_id ORDER BY dateandtime DESC";
									$count = $db->num_rows($query);
									if($count){
										$i=1; 
										$l=1; 
										$rows = $db->get_results($query);
										foreach($rows as $row) { 
										
											$comp_query = "Select * from buyer_details where buyer_id = '".$row['buyer_id']."'";
											$comp_res = $db->get_row($comp_query);
										?>
										<tr class="odd gradeX">   
											<td><?php echo $l++; ?></td>   
											<td><?php echo $comp_res['company_name']; ?></td> 
											<td><?php echo $row['order_id']; ?></td>               
											<td><?php echo $row['dateandtime']; ?></td>                  
											<!--<td><?php /* echo $row['product_name']; ?></td>                  
											<td><?php echo $row['qty']; ?> (<?php echo $row['unit']; ?>)</td>    
											<td><?php echo $row['color']; ?></td>   											 										
											<td><?php echo $row['size']; ?></td>    
											<td class="client-status"><span class="label <?php if ($row['status']=="Ordered"){echo "label-warning";}else if ($row['status']=="Cancelled"){echo "label-danger";}else if ($row['status']=="Confirmed"){echo "label-primary";	}else if ($row['status']=="Delivered"){echo "label-info";}?>"><?php echo $row['status']; */?></span></td> -->
											<td>
												<button onclick="getprod_dels(this.value);"  type="button" data-toggle="modal" data-target="#myModal2" value="<?php echo $row['order_id']; ?>" class="btn btn-primary btn-xs tooltip-top"  data-original-title="Edit"><i class="fa fa-eye"></i></button>
											</td>
										</tr>
										<?php $i++; }
										
									} else { ?>
									<tr class="even gradeC">
										<td colspan="9" align="center">No Order's Found</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
					<div class="table-responsive">
						<div style="text-align:right; margin-bottom:10px;">
						</div>
						<div class="text-right">
							
						</div>
						<div class="modal inmodal" id="myModal2" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog">
								
								<form id="Update_prod" method="post" enctype="multipart/form-data">
									<div class="modal-content animated bounceInRight">
										<div class="modal-header">
											<button onclick="location.reload();" type="button" class="close" data-dismiss="modal"><span aria-hidden="true" onclick="location.reload();" >&times;</span><span onclick="location.reload();"  class="sr-only">Close</span></button>
											<i class="fa fa-shopping-cart modal-icon"></i>
											<h4 class="modal-title">Feedback Details</h4>
											<small class="font-bold"></small>
										</div>
										<input type="hidden" name="or_id" id="or_id" value="" />
										<div class="modal-body">
											<div class="row">	
												<div class="col-lg-12">
													<div  id ="Update_manufact_name_" class="form-group"><label>Subject*</label> <input  id="subject" name="subject" type="text" placeholder="Enter Subject" class="form-control " readonly></input></div>
												</div>	
											</div>	
											
											<div class="row">
												<div class="col-lg-12">
													<div  id ="Update_weight_"  class="form-group"><label>Message*</label> <textarea rows="4" cols="50" name="message" id="message"class="form-control " readonly></textarea></div>
												</div>														
											</div>		
										</div>
										<div class="modal-footer">																					
											<button type="button" onclick="location.reload();" class="btn btn-primary" data-dismiss="modal">OK</button>
											<!--<button type="button" onclick="submit_1()" class="btn btn-primary">Submit</button> -->
										</div>
									</div>
								</form>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	function filterCat(val){
		location.replace('index.php?p=users&type=paid&cat='+val);
	}
	function Refresh_page()
	{
		
		setTimeout("window.open(self.location, '_self');", 300000);
	}
	
	function getprod_dels(order_id)
	{
		jQuery.ajax({
				url:'../api/ajax_get_role.php?action=get_feedback',
				type: "POST",
				data: {order_id:order_id},
				success: function(data)
				{
					var fields = data.split('~');
				//	alert(fields);
					$( "#subject" ).val(fields[1]);
					$( "#message" ).val(fields[2]);
				//	location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
		});
	}
	
	function submit_1(){
		
		var subject = $.trim($("#subject").val());
		var message = $.trim($("#message").val());
		var orderid = $.trim($("#or_id").val());
		if ( $.trim($("#subject").val())=="")
		{
			$( "#subject" ).addClass( "has-error" );
			
		}
		else if ( $.trim($("#message").val())=="")
		{
			$( "#subject" ).removeClass( "has-error" );
			$( "#message" ).addClass( "has-error" );
			
		}
		else
		{
			$( "#subject" ).removeClass( "has-error" );
			$( "#message" ).removeClass( "has-error" );
			
			jQuery.ajax({
				url:'../api/api.php?action=addfeed',
				type: "POST",
				data: {orderid:orderid,subject:subject,message:message,},
				success: function(data)
				{
					
					if(data == 2)
					{
						alert('Your Feedback placed Successfully !');
					}
					else
					{
						alert('Your Feedback not placed please try again after sometime. Thankyou !');
					}
					location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
			});
		}
	}
</script>