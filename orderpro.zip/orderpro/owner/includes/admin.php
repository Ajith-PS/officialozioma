<?php
include 'classes/agent.php'; 
$obj_content=new content();
if(isset($_GET['id']) && !isset($_POST['btn_submit']))
{
	$_POST=$obj_content->getData((int)$_GET['id']);	
}
if(isset($_POST['btn_submit']))
{
	$error=array();
	if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	$error=$obj_content->checkData($_POST,$id);
	
	if(count($error)==0)
	{
		if($id!='')
		{
			$obj_content->updateData($_POST,$id);
		}
		else 
		{
			$obj_content->insertData($_POST);
		}
	}	
}
?>

<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-10">
    <h2>
      <?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
      Admin</h2>
    <ol class="breadcrumb">
      <li> <a href="index.php">Home</a> </li>
      <li class="active"> <strong>
        <?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
        Admin</strong> </li>
    </ol>
  </div>
  <div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
  <div class="row">
    <div class="col-lg-12">
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>
            <?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
            Admin</h5>
        </div>
        <div class="ibox-content">
          <form method="post" enctype="multipart/form-data">
            <div class="box-body">
              <div class="form-group <?php if(isset($error['name']) && strlen(trim($error['name']))) echo 'has-error';?>">
                <label class="control-label" for="focusedInput">Name<span class="required">*</span></label>
                <input class="form-control" type="text" required name="name" id="name" value="<?php if(isset($_POST['name'])) echo $_POST['name']; ?>">
                <?php if(isset($error['name']) && strlen(trim($error['name']))){?>
                <label class="help-inline"><?php echo $error['name'];?></label>
                <?php } ?>
              </div>
              <div class="form-group <?php if(isset($error['email']) && strlen(trim($error['email']))) echo 'has-error';?>">
                <label class="control-label" for="focusedInput">Email<span class="required">*</span></label>
                <input class="form-control" type="text" required name="email" id="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>">
                <?php if(isset($error['email']) && strlen(trim($error['email']))){?>
                <label class="help-inline"><?php echo $error['email'];?></label>
                <?php } ?>
              </div>
              <div class="form-group <?php if(isset($error['phone']) && strlen(trim($error['telephone']))) echo 'has-error';?>">
                <label class="control-label" for="focusedInput">Phone<span class="required">*</span></label>
                <input class="form-control" type="text" required name="phone" id="phone" value="<?php if(isset($_POST['phone'])) echo $_POST['phone']; ?>">
                <?php if(isset($error['phone']) && strlen(trim($error['phone']))){?>
                <label class="help-inline"><?php echo $error['phone'];?></label>
                <?php } ?>
              </div>
              <div class="form-group <?php if(isset($error['username']) && strlen(trim($error['username']))) echo 'has-error';?>">
                <label class="control-label" for="focusedInput">Username<span class="required">*</span></label>
                <input class="form-control" type="text" required name="username" id="username" value="<?php if(isset($_POST['username'])) echo $_POST['username']; ?>">
                <?php if(isset($error['username']) && strlen(trim($error['username']))){?>
                <label class="help-inline"><?php echo $error['username'];?></label>
                <?php } ?>
              </div>
              <div class="form-group <?php if(isset($error['password']) && strlen(trim($error['password']))) echo 'has-error';?>">
                <label class="control-label" for="focusedInput">Password<span class="required">*</span></label>
                <input class="form-control" type="text" required name="password" id="password" value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>">
                <?php if(isset($error['password']) && strlen(trim($error['password']))){?>
                <label class="help-inline"><?php echo $error['password'];?></label>
                <?php } ?>
              </div>
              
            </div>
            <div class="box-footer">
              <input type="reset" class="btn btn-default" name="cancel" id="cancel" value="Cancel" onclick="return cancelme();">
              <input type="submit" name="btn_submit" value="<?php if(isset($_GET['id'])) {  echo "Update Admin"; } else { echo "Add Admin"; } ?>" id="submit" class="btn btn-info pull-right"/>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
function cancelme()
{
	$(".form-group").removeClass("error");
	$(".help-inline").hide();
	$("#client").attr("client","0"); 
	$("#title").attr('value',"");
	$("#description").attr('value',"");
	$("#priority").attr('value',"");
	$("#min_exp").attr('value',"");
	$("#max_exp").attr('value',"");
	$("#country").val('0');
	$("#state").val('0');
	$("#city").val('0');
	$("#salary_range").val('0');
	$("#industry").attr('value','0');
	$("#expertise").attr('value','0');
	$("#type_of_company").attr('value','0');
	$("#area").attr('value','0');
	
	$("#example-nSelectedText").attr('value','');
	$("#expertise option[value='']").attr('selected', false)
	$("#example-nSelectedText option[value='']").attr('selected', false)
	
	
	//$("#date01").val('');
	$("option:selected").prop("selected", false)
}
</script> 
