 <?php
	global $db,$general;
	date_default_timezone_set('Asia/Kolkata');
	// include 'classes/users.php'; 
	// $obj_content=new content();
	// global $db,$general;
	// if(isset($_GET['id']) && !isset($_POST['btn_submit_m']) && !isset($_POST['btn_submitUpdat']))
	// {
	// $_POST=$obj_content->getData($_GET['id']);	
	// //$_POST1=$obj_content->getcreditData($_GET['id']);	
	
	// }
	// if(isset($_POST['btn_submit_m']) && !isset($_POST['btn_submitUpdat']))
	// {
	// $error=array();
	// if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
	// if($id!='')
	// {
	// $obj_content->updateData($_POST,$id);
	// }
	// else 
	// { 
	// $obj_content->insertData($_POST);
	// }
	
	// }
	// if(isset($_POST['btn_submitUpdat']))
	// {
	// $obj_content->updateData($_POST,$_GET['id']);
	
	// }
?>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>
			<?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
		Log</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong>
				<?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
			Log</strong> </li>
		</ol>
	</div>
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	
	
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>      
				<?php if($_GET['msg']==1){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">�</button>
					User Added successfully. </div>
					<?php } if($_GET['msg']==4){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">�</button>
					User Update successfully. </div>
				<?php } ?>
			<?php } ?>
			
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>
						
					Log</h5>
				</div>
				<div class="ibox-content">
					<div class="row">
						<div class="col-lg-12">
							<div class="ibox float-e-margins">
								<div class="ibox-title">
									<h5>Your daily feed</h5>
									<div class="ibox-tools">
									<?php $msg_count = "Select * from Log_details";
										$msg_count1 = "Select * from Log_details order by dateandtime DESC limit 0,10";
										$count = $db->num_rows($msg_count);
										$rows = $db->get_results($msg_count1);
									?>
										<span class="label label-warning-light pull-right"><?php echo $count; ?> Messages</span>
										<input type = "hidden" name="rownum" id = "rownum" value= "<?php echo $count; ?>" />
									</div>
								</div>
								<div class="ibox-content">
									
									<div>
										<div class="feed-activity-list" id = "addlog">
											<?php 
											foreach($rows as $row)
											{
												$user_details = $db->get_row("Select * from login_and_user_details where id='".$row['added_by']."'");
											?>
												<div class="feed-element">
													<a href="profile.html" class="pull-left">
														<img alt="image" class="img-circle" src="img/profile.jpg">
													</a>
													<div class="media-body ">
													<?php 
														$olddate = strtotime($row['dateandtime']);
														$newdate = date('Y-m-d', $olddate);
														$newdate1 = date('d.m.Y', $olddate);
														$time = date('h:i A',$olddate);
														$timeDiff1 = "";
														if($newdate == date('Y-m-d'))
														{
														//echo date("Y-m-d h:i:sa");
															$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
															$timeDiff1 = abs($endTimeStamp1 - $olddate);
															$timeDiff1 = round($timeDiff1 / 60);
			
															if($timeDiff1 > 59)
															{
																$timeDiff1 = floor($timeDiff1 / 60);
																$timeDiff1 = $timeDiff1."hours ago";																
															}
															else
															{
																$timeDiff1 = $timeDiff1."mins ago";
															}
														}
														else if ($newdate == date('Y-m-d',strtotime("-1 days")))
														{
															$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
															$timeDiff1 = abs($endTimeStamp1 - $olddate);
															$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
														}
														else
														{
																$startTimeStamp = strtotime($newdate);
																$endTimeStamp = strtotime("today");

																$timeDiff1 = abs($endTimeStamp - $startTimeStamp);

																$numberDays = $timeDiff1/86400;  // 86400 seconds in one day

																// and you might want to convert to integer
																$timeDiff1 = intval($numberDays)."days ago";
																//echo $numberDays."days ago";
																}
													?>
														<small class="pull-right"><?php echo $timeDiff1; ?> </small>
														<strong><?php echo $user_details['username']; echo "(".$user_details['role'].")";?> </strong> <?php echo $row['message']; ?> 
														<?php echo $row['role']; ?> <strong><?php echo "(".$row['full_name'].")";?> </strong> <?php echo "with ID : ".$row['user_id']; ?> 
														<br>
														<small class="text-muted"><?php
															
																if($newdate == date('Y-m-d'))
																	echo "Today";
																else if ($newdate == date('Y-m-d',strtotime("-1 days")))
																	echo "Yesterday";
																else
																{
																$startTimeStamp = strtotime($newdate);
																$endTimeStamp = strtotime("today");

																$timeDiff = abs($endTimeStamp - $startTimeStamp);

																$numberDays = $timeDiff/86400;  // 86400 seconds in one day

																// and you might want to convert to integer
																$numberDays = intval($numberDays);
																echo $numberDays."days ago";
																}
															
															echo " ".$time." - ".$newdate1;
															?> </small>
														
													</div>
												</div>
										<?php } ?>
											
									<!--		<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/a2.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right">2h ago</small>
													<strong>Mark Johnson</strong> posted message on <strong>Monica Smith</strong> site. <br>
													<small class="text-muted">Today 2:10 pm - 12.06.2014</small>
												</div>
											</div>
											<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/a3.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right">2h ago</small>
													<strong>Janet Rosowski</strong> add 1 photo on <strong>Monica Smith</strong>. <br>
													<small class="text-muted">2 days ago at 8:30am</small>
												</div>
											</div>
											<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/a4.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right text-navy">5h ago</small>
													<strong>Chris Johnatan Overtunk</strong> started following <strong>Monica Smith</strong>. <br>
													<small class="text-muted">Yesterday 1:21 pm - 11.06.2014</small>
													<div class="actions">
														<a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Like </a>
														<a class="btn btn-xs btn-white"><i class="fa fa-heart"></i> Love</a>
													</div>
												</div>
											</div>
											<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/a5.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right">2h ago</small>
													<strong>Kim Smith</strong> posted message on <strong>Monica Smith</strong> site. <br>
													<small class="text-muted">Yesterday 5:20 pm - 12.06.2014</small>
													<div class="well">
														Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.
														Over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
													</div>
													<div class="pull-right">
														<a class="btn btn-xs btn-white"><i class="fa fa-thumbs-up"></i> Like </a>
													</div>
												</div>
											</div>
											<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/profile.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right">23h ago</small>
													<strong>Monica Smith</strong> love <strong>Kim Smith</strong>. <br>
													<small class="text-muted">2 days ago at 2:30 am - 11.06.2014</small>
												</div>
											</div>
											<div class="feed-element">
												<a href="profile.html" class="pull-left">
													<img alt="image" class="img-circle" src="img/a7.jpg">
												</a>
												<div class="media-body ">
													<small class="pull-right">46h ago</small>
													<strong>Mike Loreipsum</strong> started following <strong>Monica Smith</strong>. <br>
													<small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
												</div>
											</div> -->
										</div>
										<button class="btn btn-primary btn-block m-t" id="loadmore" num_loaded="10"><i class="fa fa-arrow-down"></i> Show More</button>
										
									</div>
									
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
$('#loadmore').click(function() {
    var loaded = $(this).attr('num_loaded');
	var loaded1 = parseInt(loaded)+10;
	var rownum = parseInt($("#rownum").val());
	//alert(loaded1);
    jQuery.ajax({
			url:'../api/ajax_get_role.php?action=getlog',
			type: "POST",
			data: {'from':loaded,'to':loaded1},
			success: function(data)
			{
			//alert(data);
				$('#addlog').append(data);
				$('#loadmore').attr('num_loaded',loaded1);
				if(rownum > loaded1)
				{
					$('#loadmore').prop('disabled', false);
				}
				else
				{
					$('#loadmore').attr('disabled', 'disabled');
				}
			},
			error: function(xhr, status, error) {
				
				
			}
		});
});
</script>