<?php
	include("../api/add_log.php");
	if(isset($_GET['act']) && $_GET['act']=='delete' && $_GET['id'])
	{global $db,$general;	
		$query = "update buyer_details SET status='0' where buyer_id='".$_GET['id']."'";
		$insert=$db->query($query)  or die(mysql_error());
		if($insert){
			$query = "update login_and_user_details SET status='0' where id='".$_GET['id']."'";
			$insert=$db->query($query)  or die(mysql_error());
			if($insert){
				$query = "Select * from login_and_user_details where id='".$_GET['id']."'";
				$insert=$db->get_row($query)  or die(mysql_error());
					$obj = new add_log();
					$msg = "Owner deletes buyer";
					$result = $obj->log_details($insert['username'], 'buyer', $_GET['id'], $msg);
					if($result = 1)			
						$general->redirect('index.php?p=buyers-details&msg=3');
			}
		}
		
		
	}
?>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2><?php// if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Buyers Details</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?> Buyers Details</strong> </li>
		</ol>
	</div>
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
				<?php if($_GET['msg']==1 || $_GET['msg']==2) {?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<?php if($_GET['msg']==1) { ?>
							User added successfully.
							<?php } else if($_GET['msg']==2) {?>
							Buyer updated successfully.
							<?php } else if($_GET['msg']==4) {?>
							User already exist.
						<?php } ?>
					</div>
				<?php } ?>
				<?php if($_GET['msg']==3){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">×</button>
					Buyer deleted successfully. </div>
				<?php } ?>
			<?php } ?>
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?> Buyers</h5>
				</div>
				<div class="ibox-content">
					<div class="table-responsive">
						<div style="text-align:right; margin-bottom:10px;">
						</div>
						<table class="table table-striped table-bordered table-hover dataTables-example" >
							<thead>
								<tr>
									<th>Sl. No.</th>
									<th>Buyer Id</th>
									<th>Company Name</th> 
									<th>Name</th>									
									<th>User Name</th>
									<th>Location</th>
									<th>Cerdit Initial</th>
									<th>Cerdit Utilized</th>
									<th>Cerdit Balance</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									
									$query = "select * from buyer_details where status=1";
									
									$count = $db->num_rows($query);
									if($count){
										$i=1; 
										$l=1; 
										$rows = $db->get_results($query);
										
										
										foreach($rows as $row) { 
											
											//$user_details = $general->get_login_details($row['buyer_id']);
											$cerdit_details = $general->get_cerdit_details($row['buyer_id']);	
										?>
										<tr class="odd gradeX">   
											<td><?php echo $l++; ?></td>        
											<td><?php echo $row['buyer_id']; ?></td> 											
											<td><?php echo $row['company_name']; ?></td>                  
											<td><?php  echo $row['name_concerned_person']; ?></td>                  
											<td><?php  echo $row['email_id']; ?></td>                  
											<td><?php echo $row['location']; ?></td>    
											<td><?php echo $cerdit_details['credit_initial']; ?></td>    
											<td><?php echo $cerdit_details['credit_utilized']; ?></td>    
											<td><?php echo $cerdit_details['credit_balance']; ?></td>    
											
											<td>
												<a href='index.php?p=buyerview&id=<?php echo $row["buyer_id"];?>'><button class="btn btn-primary btn-xs tooltip-top"  data-original-title="View"><i class="fa fa-eye "></i></button></a>
											<a href='index.php?p=buyers&id=<?php echo $row["buyer_id"]; ?>'><button class="btn btn-primary btn-xs tooltip-top"  data-original-title="Edit"><i class="fa fa-pencil"></i></button></a><a href='index.php?p=buyers-details&act=delete&id=<?php echo $row["buyer_id"];?>' onclick="if(!confirm('Are you sure you want to delete this Buyer.')) return false;"><button class="btn btn-danger btn-xs tooltip-top"  data-original-title="Delete"><i class="fa fa-trash-o "></i></button></a></td>
										</tr>
										<?php $i++; }
										
									} else { ?>
									<tr class="even gradeC">
										<td colspan="7" align="center">No Buyer Found</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function filterCat(val){
		location.replace('index.php?p=users&type=paid&cat='+val);
	}
</script>