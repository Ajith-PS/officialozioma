<?php
	include 'classes/addvolume.php'; 
	$obj_content=new content();
	if(isset($_GET['id']) && !isset($_POST['btn_submit']) && !isset($_POST['btn_submitUpdat']))
	{
		$_POST=$obj_content->getData($_GET['id']);	
		$_POST1=$obj_content->getcreditData($_GET['id']);	
	
	}
	if(isset($_POST['btn_submit_m']) && !isset($_POST['btn_submitUpdat']))
	{
		$error=array();
		if(isset($_GET['id'])) $id=(int)$_GET['id']; else $id="";
			/*if($id!='')
			{
				$obj_content->updateData($_POST,$id);
			}
			else 
			{ */
				$obj_content->insertData($_POST);
			//}
		
	}
	if(isset($_POST['btn_submitUpdat']))
	{
		$obj_content->updateData($_POST,$_GET['id']);
		
	}
?>



<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>
			<?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
		Volume</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong>
				<?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
			Volume</strong> </li>
		</ol>
	</div>
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	
	
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>      
				<?php if($_GET['msg']==1){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">×</button>
					Volume Added successfully. </div>
					<?php } if($_GET['msg']==4){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">×</button>
					Volume Update successfully. </div>
				<?php } ?>
			<?php } ?>
			
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>
						<?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
					Volume</h5>
				</div>
				<div class="ibox-content">
					<form method="post" enctype="multipart/form-data">
						<div class="box-body">
							<div class="inmodal modal-body">
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label class="control-label" for="focusedInput">VOLUME NUMBER<span class="required">*</span></label>
											<input class="form-control" type="text" onkeyup="Check_number()" name="volume_number" id="volume_number" value="<?php if(isset($_POST['volume_number'])) echo $_POST['volume_number']; ?>" />											
											<label class="help-inline volume_number_view_text" style="color:red;"></label>
										</div>
									</div>	
									
									<div class="col-lg-6">
										<div class="form-group " >
											<label class="control-label" for="focusedInput">VOLUME YEAR<span class="required">*</span></label>
											<input class="form-control date-picker-year" type="text" name="volume_year" id="volume_year" value="<?php if(isset($_POST['volume_year'])) echo $_POST['volume_year']; else { echo "01/01/".date('Y');}?>" readonly>											
											<label class="help-inline volume_year_view_text" style="color:red;"></label>
										</div>
									</div>	
								</div>									
							</div>	
						</div>						
						<div class="box-footer">
							<?php if(isset($_GET['id'])) { ?>
								<a href="index.php?p=buyers-details"><input type="button" class="btn btn-default" name="cancel" id="cancel" value="Cancel"></a>
							<?php } else { ?>
							<input type="reset" class="btn btn-default" name="cancel" id="cancel" value="Cancel">
							<?php } ?>
							<input type="button" name="btn_submit" value="<?php if(isset($_GET['id'])) {  echo "Update Volume"; } else { echo "Add Volume"; } ?>" id="Update_add_Distributer" class="btn btn-info pull-right"/>
							<!--<input type="submit" id="btn_submit_m"  name="btn_submit_m"  value="confirm Order" id="btn_submit_m" class="btn btn-info pull-right"/> -->
							<input type="submit" id ="<?php if(isset($_GET['id'])) {  echo "btn_submitUpdat"; } else { echo "btn_submit_m"; } ?>" style="Display:none;" <?php if(isset($_GET['id'])) {  echo "name='btn_submitUpdat'"; } else {   echo "name='btn_submit_m'"; } ?>  value="<?php if(isset($_GET['id'])) {  echo "Update Volume"; } else { echo "Add Volume"; } ?>"  class="btn btn-info pull-right"/>
						<!--	<input type="submit" id ="Update_add_Distributer" <?php /* if(isset($_GET['id'])) {  echo "name='btn_submitUpdat'"; } else {   echo "name='btn_submit'"; } ?>  value="<?php if(isset($_GET['id'])) {  echo "Update Buyer"; } else { echo "Add Buyer"; } */?>" id="submit" class="btn btn-info pull-right"/> -->
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script>


window.onload = function() {
		
		$(function() {
			$('#Update_add_Distributer').bind('click', function() {	
				var volume_number = ($('#volume_number').val()).trim();								
				$( "#volume_number" ).removeClass( "has-error" );
				$( ".volume_number_view_text" ).html( "");				
				if(volume_number == "")
				{
					$( "#volume_number" ).addClass( "has-error" );
					$( ".volume_number_view_text" ).html( "Please Enter Volume Number" );					
				}				
				else
				{
					//if(getid == "")
					//{
						$("#btn_submit_m").click();	
					//}
					//else
					//{
					//	$("#btn_submitUpdat").click();								
					//}
				}				
			});
		});
		
	};
	// var input = document.getElementById('email');
	// input.addEventListener('keyup',function(){
	
	
	//});
	// $( document ).ready(function() {
	// $("#buyerid").on("keyup", function() {
	// alert($(this).val());
	// });
	
	// });
	function Check_Dup()
	{
		var from1 = jQuery('input[name=btn_submit]');
		
		//add disabled
		from1.attr('disabled', 'disabled');
		
		if ($('#Check_Username').hasClass('has-error')) {
			from1.attr('disabled', 'disabled');
		}
		else if ($('#username').val()=='') {
			from1.attr('disabled', 'disabled');
		}
		else
		{
			//remove it
			from1.removeAttr("disabled");
		}
		
		if ($('#distributorid_vidw').hasClass('has-error')) {
			from1.attr('disabled', 'disabled');
		}
		else if ($('#buyerid').val()=='') {
			from1.attr('disabled', 'disabled');
		}
		else
		{
			//remove it
			from1.removeAttr("disabled");
			
		}
		if ($('#email_').hasClass('has-error')) {
			from1.attr('disabled', 'disabled');
			
			
		}
		else if ($('#email').val()=='') {
			from1.attr('disabled', 'disabled');
			
		}
		else
		{	
			from1.removeAttr("disabled");
		}
		
	}
	
	function Check_suername()
	{
		var from1 = jQuery('input[name=btn_submit]');
		Check_Dup();
		var check_username = $("#username").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_username',
			type: "GET",
			data: {username:check_username},
			success: function(data)
			{
				if (data == "2")
				{
					$( "#Check_Username" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".distributorid_view_text" ).html( "User Name Already used" );
					return false;
				}
				if (data == "1")
				{
					$( "#Check_Username" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".distributorid_view_text" ).html( "Enter User Name" );
					return false;
				}
				if (data == "3")
				{$('#Update_add_Distributer').prop('disabled', false);
					$( "#Check_Username" ).removeClass( "has-error" );
					$( ".distributorid_view_text" ).html( "");
					return false;
				}
				
				Check_Dup();
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
		
	}
	function Check_Updatte()
	{
		var from1 = jQuery('input[name=btn_submit]');
		Check_Dup();
		var check_username = $("#username").val();
		var buyerid = $("#buyerid").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_Updateusername',
			type: "GET",
			data: {username:check_username,Dis_id:buyerid},
			success: function(data)
			{
				
				if (data == "2")
				{
					$( "#Check_Username" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".distributorid_view_text" ).html( "User Name Already used" );
					return false;
				}
				if (data == "1")
				{
					$( "#Check_Username" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".distributorid_view_text" ).html( "Enter User Name" );
					return false;
				}
				if (data == "3")
				{$('#Update_add_Distributer').prop('disabled', false);
					$( "#Check_Username" ).removeClass( "has-error" );
					from1.removeAttr("disabled");
					$('#Update_add_Distributer').prop('disabled', false);
					$( ".distributorid_view_text" ).html( "");
					return false;
				}
				
				Check_Dup();
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
		
	}
	function Check_email()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
	//	Check_Dup();
		var getid = ($('#getid').val()).trim();
		var check_email = $("#email").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_buyer_email',
			type: "GET",
			data: {check_email1:check_email,getid:getid},
			success: function(data)
			{
				
				if (data == "2")
				{	
					$( "#email" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".email1_view_text" ).html( "Email ID Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#email" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".email1_view_text" ).html( "Enter Email ID Name" );
					return false;
				}
				if (data == "4")
				{	
					$( "#email" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".email1_view_text" ).html( "Enter Valid Email ID Name" );
					return false;
				}
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#email" ).removeClass( "has-error" );
					$( ".email1_view_text" ).html( "");
					return false;
					
					
					
				}
				
		//		Check_Dup();
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	function Check_email_update()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		var buyerid = $("#buyerid").val();
		var check_email = $("#email").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_email_update',
			type: "GET",
			data: {check_email1:check_email,Dis_id:buyerid},
			success: function(data)
			{
				
				if (data == "2")
				{
					$( "#email_" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".email_view_text" ).html( "Email ID Already used" );
					return false;
				}
				if (data == "1")
				{
					$( "#email_" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".email_view_text" ).html( "Enter Email ID " );
					return false;
				}
				if (data == "4")
				{
					$( "#email_" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".email_view_text" ).html( "Enter Valid Email ID " );
					return false;
				}
				if (data == "3")
				{$('#Update_add_Distributer').prop('disabled', false);
					from1.removeAttr("disabled");
					$( "#email_" ).removeClass( "has-error" );
					$( ".email_view_text" ).html( "");
					return false;
				}
				
				
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	
	function Check_Vatno()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		
		var check_Vat = $("#vatno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_VAT_No',
			type: "GET",
			data: {check_vatno:check_Vat},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "Vat No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "Enter Vat No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_Vatno" ).removeClass( "has-error" );
					$( ".vatno_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	
	function Check_Vatno_update()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		var buyerid = $("#buyerid").val();
		var check_Vat = $("#vatno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_VAT_No_update',
			type: "GET",
			data: {check_vat_no:check_Vat,Dis_id:buyerid},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "Vat No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "Enter Vat No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_Vatno" ).removeClass( "has-error" );
					$( ".vatno_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	
	
	function Check_CstNo()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		
		var check_cstno = $("#cstno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_CST_No',
			type: "GET",
			data: {check_cstno:check_cstno},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_Cst" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".cst_view_text" ).html( "CST No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_Cst" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".cst_view_text" ).html( "Enter CST No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_Cst" ).removeClass( "has-error" );
					$( ".cst_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	
	function Check_Vatno_update()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		var buyerid = $("#buyerid").val();
		var cstno = $("#cstno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_cst_No_update',
			type: "GET",
			data: {check_cstno:check_cstno,Dis_id:buyerid},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "CST No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_Vatno" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".vatno_view_text" ).html( "Enter CST No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_Vatno" ).removeClass( "has-error" );
					$( ".vatno_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	function Check_pan()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		
		var check_panno = $("#panno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_pan_No',
			type: "GET",
			data: {check_panno:check_panno},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_pan" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".pan_view_text" ).html( "PAN No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_pan" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".pan_view_text" ).html( "Enter PAN No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_pan" ).removeClass( "has-error" );
					$( ".pan_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
	
	
	function Check_pan_update()
	{
		
		
		var from1 = jQuery('input[name=btn_submit]');
		var buyerid = $("#buyerid").val();
		var panno = $("#panno").val();
		jQuery.ajax({
			url:'../api/api.php?action=check_pan_No_update',
			type: "GET",
			data: {panno:panno,Dis_id:buyerid},
			success: function(data)
			{
				
				
				if (data == "2")
				{	
					$( "#distributorid_pan" ).addClass( "has-error" );
					
					from1.attr('disabled', 'disabled');
					$( ".pan_view_text" ).html( "PAN No. Already used" );
					return false;
				}
				if (data == "1")
				{	
					$( "#distributorid_pan" ).addClass( "has-error" );
					from1.attr('disabled', 'disabled');
					$( ".pan_view_text" ).html( "Enter PAN No." );
					return false;
				}
				
				if (data == "3")
				{
					
					$('#Update_add_Distributer').prop('disabled', false);
					$( "#distributorid_pan" ).removeClass( "has-error" );
					$( ".pan_view_text" ).html( "");
					return false;
					
					
					
				}
				
			},
			error: function(xhr, status, error) {
				
				
			}
		});
	}
</script>			