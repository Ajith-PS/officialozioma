	<!--<div class="wrapper wrapper-content">
	<div class="row">
		
	 <div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>New Orders</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins"><?php //echo $db->num_rows("SELECT * FROM purchase_orders where order_status='Ordered'"); ?></h1>
				</div>
			</div>
		</div> 
		<div class="col-lg-3">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>Total Orders</h5>
				</div>
				<div class="ibox-content">
					<h1 class="no-margins"><?php //echo $db->num_rows("SELECT * FROM purchase_orders"); ?></h1>
				</div>
			</div>
		</div> 
	</div>
</div> -->