<?php
	// if(isset($_GET['act']) && $_GET['act']=='delete' && $_GET['id'])
	// {
	// $delete="delete from user_saved_alerts where id=".(int)$_GET['id'];
	// $db->query($delete);
	// $general->redirect('index.php?p=userview&msg=3&id='.(int)$_GET['user_id']);
	// }
	
	$user_row = $db->get_row("SELECT * FROM buyer_details WHERE buyer_id='".$_GET['id']."'");
	$credit_limit = $db->get_row("SELECT * FROM credit_limit WHERE buyer_id='".$_GET['id']."'");
?>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Buyer Details</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong>Buyer Details</strong> </li>
		</ol>
	</div>
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>      
				<?php if($_GET['msg']==3){?>
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">�</button>
					User deleted successfully. </div>
					<?php } if($_GET['msg']==4){?>
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">�</button>
					Notification sent successfully. </div>
				<?php } ?>
			<?php } ?>
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5 style=" width: 100%; text-align: center; ">Buyer Details</h5>
				</div>
				
				<div class="ibox-content">
					<div class="table-responsive">
						<ul class="nav nav-pills nav-stacked">
							
							<table class="table table-striped table-bordered table-hover " >
								
								
								<tr>
									<th>Buyer ID</th>
									<td><?php echo $user_row['buyer_id']; ?></td>
									<th>Company Name</th>
									<td><?php echo $user_row['company_name']; ?></td>                  
									
								</tr>
								
								<tr>
									<th>Name</th>
									<td><?php echo $user_row['name_concerned_person']; ?></td>
									<th>User Name</th>
									<td><?php echo $user_row['email_id']; ?></td>                  
									
								</tr>
								<tr>
									<th>Location</th>
									<td><?php echo $user_row['location']; ?></td>
									<th>Credit Initial</th>
									<td><?php echo $credit_limit['credit_initial']; ?></td>                  
									
								</tr>
								<tr>
									<th>Credit Utilized</th>
									<td><?php echo $credit_limit['credit_utilized']; ?></td>
									<th>Credit Balance</th>
									<td><?php echo $credit_limit['credit_balance']; ?></td>                  
									
								</tr>
								<tr>
									<th>Phone</th>
									<td><?php echo $user_row['mobile']; ?></td>
									<th>Email Id</th>
									<td><?php echo $user_row['email_id']; ?></td>                  
									
								</tr>								
							</table>
							
							
						</ul>
						
						
					</div>
				</div>
			</div>
		</div>
	</div>
<!--	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5 style=" width: 100%; text-align: center; ">Payment Details</h5>
				</div>
				
				<div class="ibox-content">
					<div class="table-responsive">
						
						
						<div class="text-right">
							<!--<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal">
								Add Payment
							</button>-->
				<!--		</div>
						<div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content animated bounceInRight">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
										<i class="fa fa-credit-card modal-icon"></i>
										<h4 class="modal-title">ADD PAYMENT</h4>
										<small class="font-bold"></small>
									</div>
									<div class="modal-body">
										<div class="row">
											<div class="col-lg-6">
												<div class="form-group"><label>Payment Date*</label> <input id="add_pay_date" value="<?php //echo date("m/d/Y"); ?>" name="add_pay_date" type="text" placeholder="Select Date" class="form-control datepicker"></div>
											</div>	
											<div class="col-lg-6">
												<div class="form-group"><label>Cheque No.</label> <input id="add_pay_cheque_no" name="add_pay_cheque_no" type="text" placeholder="Enter Cheque No." class="form-control "></div>
											</div>	
										</div>	
										<div class="row">
											<div class="col-lg-6">
												<div class="form-group"><label>RTGS No.</label> <input id="add_pay_rtgs_no" name="add_pay_rtgs_no" type="text" placeholder="Enter RTGS No." class="form-control "></div>
											</div>	
											<div class="col-lg-6">
												<div class="form-group"><label>Amount*</label> <input id="add_pay_amount" name="add_pay_amount" type="text" placeholder="Enter Amount" class="form-control "></div>
											</div>	
										</div>	
										<div class="row">
											<div class="col-lg-6">
												<div class="form-group"><label>Drawn on Bank*</label> <input id="add_pay_drawn_on_bank" name="add_pay_drawn_on_bank" type="text" placeholder="Enter Drawn on Bank" class="form-control "></div>
											</div>	
											<div class="col-lg-6">
												<div class="form-group"><label>Refference Purchase Order No.*</label> 
													
													<select name="Order_Number" id="Order_Number" onchange="filterCat(this.value)" class="form-control input-sm" style="height:35px;">
														<option value="-1">Select Order No.</option>
														<option value="custom">Custom</option>
														<?php
														/*	$query = "select * from purchase_orders where dis_id=".(int)$_GET['id']." ";
															$count = $db->num_rows($query);
															if($count){
																$i=1; 
																
																$rows = $db->get_results($query);
																foreach($rows as $row) { 
																?>
																<option value="<?php echo $row['ref_purchase_order_no']; ?>"><?php echo $row['ref_purchase_order_no']; ?></option>
															<?php $i++; } } else { }?>			
															
													</select>
													
													
													
													
													
												<input id="add_pay_refference_purchase_order_no" name="add_pay_refference_purchase_order_no" type="text" style="Display:none;" placeholder="Enter Refference Purchase Order No." class="form-control "/></div>
											</div>	
										</div>	
										
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
										<button onclick="checkvalied();" type="button" class="btn btn-primary">Save changes</button>
									</div>
								</div>
							</div>
						</div>
						
						
						<table class="table table-striped table-bordered table-hover dataTables-example" >
							<thead>
								
								<tr>
									<th>SL.No.</th>
									<th>Payment ID</th>
									<th>Payment Date</th>
									<th>Cheque No.</th>                  
									
									<th>RTGS No.</th>
									<th>Amount</th>
									<th>Drawn on Bank</th>
									<th>Refference Purchase Order No.</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$query = "select * from payments where Dis_id=".(int)$_GET['id']." ";
									$count = $db->num_rows($query);
									if($count){
										$i=1; 
										$l=1; 
										$rows = $db->get_results($query);
										foreach($rows as $row) { 
										?>
										<tr class="odd gradeX">   
											<td><?php echo $l++; ?></td> 
											<td><?php echo $row['payment_id']; ?></td>               
											<td><?php echo $row['payment_date']; ?></td>                  
											<td><?php echo $row['cheque_no']; ?></td>                  
											
											<td><?php echo $row['RTGS_no']; ?></td>  
											<td><?php echo $row['amount']; ?></td>  
											<td><?php echo $row['drawn_on_bank']; ?></td>  
											<td><?php echo $row['ref_purchase_order_no']; ?></td>  
											
											<td>
												<a href='index.php?p=distributorview&act=delete&id=<?php echo $row["Dis_id"];?>&payment_id=<?php echo $row["payment_id"];?>' onclick="if(!confirm('Are you sure you want to delete this prompt.')) return false;"><button class="btn btn-danger btn-xs tooltip-top"  data-original-title="Delete"><i class="fa fa-trash-o "></i></button></a>
												
											</td>
										</tr>
									<?php $i++; } } else { ?>
									<tr class="even gradeC">
										<td colspan="9" align="center">No Payment Found</td>
									</tr>
								<?php } */?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div> -->
</div>
<script type="text/javascript">
	function filterCat(val){
		if(val =="custom")
		{
			$('#add_pay_refference_purchase_order_no').show();
		}
		else
		{
			$('#add_pay_refference_purchase_order_no').hide();
		}
	}
	
	function checkvalied()
	{
		
		var add_pay_date =$("#add_pay_date").val();
		var add_pay_amount =$("#add_pay_amount").val();
		var add_pay_drawn_on_bank =$("#add_pay_drawn_on_bank").val();
		var Order_Number =$("#Order_Number").val();
		var add_pay_refference_purchase_order_noalert =$("#add_pay_refference_purchase_order_noalert").val();
		var add_pay_cheque_no =$("#add_pay_cheque_no").val();
		var add_pay_rtgs_no =$("#add_pay_rtgs_no").val();
		
		if($("#add_pay_date").val() == "")
		{
			alert("Select Payment Date");
		}
		else if($("#add_pay_amount").val() == "")
		{
			alert("Enter Amount");
		}
		else if($("#add_pay_drawn_on_bank").val() == "")
		{
			alert("Enter drawn on bank");
		}
		else if($("#Order_Number").val() == "-1")
		{
			alert("Select reffence P.O. Number");
		}
		else if($("#Order_Number").val() == "custom")
		{
			if($("#add_pay_refference_purchase_order_noalert").val() == "")
			{
				alert("Enter reffence P.O. Number");
			}
			
			
		}
		
		else
		{
			jQuery.ajax({
				url:'../api/api.php?action=Add_payment',
				type: "GET",
				data: {add_pay_date:add_pay_date,add_pay_amount:add_pay_amount,add_pay_drawn_on_bank:add_pay_drawn_on_bank,Order_Number:Order_Number,add_pay_refference_purchase_order_noalert:add_pay_refference_purchase_order_noalert},
				success: function(data)
				{
					alert(data);
					
					// location.reload();
					
				},
				error: function(xhr, status, error) {
					
					alert(xhr.responseText);
				}
			});
		}
	}
</script>