<?php
include("../api/add_log.php");
	class content
	{
		function getData($id)
		{
			global $db;
			$select="select * from supplier_details where supplier_id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		
		function checkData($data,$id)
		{
			
			
			global $db; 
			$error=array();
			
			if(!strlen(trim($data['companyname']))) $error['companyname'] = "Enter Company Name";
			
			if(!strlen(trim($data['username']))) $error['username'] = "Enter Buyer Name";
			if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $error['email'] = "Invalid email";
		 
			
			if(!strlen(trim($data['password']))) $error['password'] = "Enter Password";
			/*if(!strlen(trim($data['phone']))) $error['phone'] = "Enter phone";
				if(!strlen(trim($data['password']))) $error['password'] = "Enter password";
				if(!strlen(trim($data['city']))) $error['city'] = "Enter city";
			if(!strlen(trim($data['country']))) $error['country'] = "Enter country";*/
			
			
			return $error;
			
		}
		
		
		function updateData($data,$id)
		{
			
			global $db,$general;	
			
			$query = "update login_and_user_details SET username='".$db->escape($data['username'])."',
			password='".$db->escape($data['password'])."',
			email='".$db->escape($data['email'])."',
			company_name='".$db->escape($data['company_name'])."',
			phone='".$db->escape($data['phone'])."',
			location='".$db->escape($data['location'])."',
			address='".$db->escape($data['address'])."'
			where id = '".$id."'";
			$insert=$db->query($query)  or die(mysql_error());
			if($insert)
			{				
				$query = "update supplier_details SET
				company_name='".$db->escape($data['company_name'])."',
				supplier_name='".$db->escape($data['username'])."',
				email='".$db->escape($data['email'])."',
				address='".$db->escape($data['address'])."',
				contact_number_of_company='".$db->escape($data['phone'])."',
				location='".$db->escape($data['location'])."',
				password='".$db->escape($data['password'])."'
				where supplier_id = '".$id."'";
				$insert=$db->query($query)  or die(mysql_error());
				if($insert)
				{	
					$obj = new add_log();
					$msg = "updated";
					$result = $obj->log_details($data['username'], 'supplier', $id, $msg);
						$general->redirect('index.php?p=suppliers-details&msg=2&id='.$id);
				}		
			}
		}
		
		function insertData($data)
		{
			global $db,$general;	
			
			$query_login = "INSERT INTO login_and_user_details SET username='".$db->escape($data['username'])."',
			password='".$db->escape($data['password'])."',
			email='".$db->escape($data['email'])."',
			company_name='".$db->escape($data['company_name'])."',
			phone='".$db->escape($data['phone'])."',
			location='".$db->escape($data['location'])."',
			address='".$db->escape($data['address'])."',
			status=1,
			role='supplier'";
			$insert_Login = $db->query($query_login) or die(mysql_error());
			$user_id = $db->lastid();	
			
			$query_Supplier = "INSERT INTO supplier_details SET supplier_id='".$db->escape($user_id)."',
			company_name='".$db->escape($data['company_name'])."',
			supplier_name='".$db->escape($data['username'])."',
			email='".$db->escape($data['email'])."',
			address='".$db->escape($data['address'])."',
			contact_number_of_company='".$db->escape($data['phone'])."',
			location='".$db->escape($data['location'])."',
			password='".$db->escape($data['password'])."',
			status = 1
			";
			
			
			$insert_Supplier = $db->query($query_Supplier) or die(mysql_error());
			
			if( $insert_Login && $insert_Supplier ){
				$obj = new add_log();
				$msg = "added";
				$result = $obj->log_details($data['username'], 'supplier', $user_id, $msg);
					$general->redirect('index.php?p=suppliers&msg=1');
			}
		}
		
	}
?>