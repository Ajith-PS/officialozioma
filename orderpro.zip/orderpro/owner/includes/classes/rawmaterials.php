<?php
	include("../api/add_log.php");
	session_start();
	class content
	{	
		function insertData($data)
		{
			global $db,$general;
			$order_id = mt_rand(100000, 999999);
			for($i=0; $i<sizeof($data['category_hidden']);$i++)
			{
				//$sel_query = "SELECT * from buyer_details where sys_dis_id = '".$db->escape($data['comp_name_hidden'][$i])."'";
				//$rows = $db->get_row($sel_query);
				
				$query = "INSERT INTO raw_material SET user_id='".$db->escape($_SESSION['auserid'])."',
				material_name='".$db->escape($data['mname_hidden'][$i])."',
				m_id = '".$db->escape($data['mid_hidden'][$i])."',
				qty='".$db->escape($data['quantity_hidden'][$i])."',			
				unit='".$db->escape($data['measurementunit_hidden'][$i])."',
				threshold='".$db->escape($data['threshold_hidden'][$i])."',
				category='".$db->escape($data['category_hidden'][$i])."',
				size='".$db->escape($data['size_hidden'][$i])."',
				colors='".$db->escape($data['colors_hidden'][$i])."',
				status = 'Ordered'";
				$insert = $db->query($query) or die(mysql_error());
				$user_id = $db->lastid();
				if($insert)
				{
					$obj = new add_log();
					$msg = "placed";
					$result = $obj->log_details($data['mname_hidden'][$i], 'raw material', $user_id, $msg);
				}
			}
			
			if($insert){
					$general->redirect('index.php?p=placematerials&msg=1');
			}
		}
		
	}
?>