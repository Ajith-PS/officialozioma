<?php
	include("../api/add_log.php");
	//require_once('../api/add_log.php');
	class content
	{
		function getData($id)
		{
			global $db;
			$select="select * from login_and_user_details where id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		function getcreditData($id)
		{
			global $db;
			$select="select * from credit_limit where buyer_id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		
		function checkData($data,$id)
		{
			
			
			global $db; 
			$error=array();
			
			if(!strlen(trim($data['companyname']))) $error['companyname'] = "Enter Company Name";
			
			if(!strlen(trim($data['username']))) $error['username'] = "Enter Buyer Name";
			if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $error['email'] = "Invalid email";
		 
			
			if(!strlen(trim($data['password']))) $error['password'] = "Enter Password";
			/*if(!strlen(trim($data['phone']))) $error['phone'] = "Enter phone";
				if(!strlen(trim($data['password']))) $error['password'] = "Enter password";
				if(!strlen(trim($data['city']))) $error['city'] = "Enter city";
			if(!strlen(trim($data['country']))) $error['country'] = "Enter country";*/
			
			
			return $error;
			
		}
		
		
		function updateData($data,$id)
		{
			
			global $db,$general;	
			$query = "update buyer_details SET name_concerned_person='".$db->escape($data['username'])."',				
			email_id='".$db->escape($data['email'])."',
			company_name='".$db->escape($data['company_name'])."',
			mobile='".$db->escape($data['phone'])."',
			location='".$db->escape($data['location'])."'
			where buyer_id='".$id."'";
			$insert=$db->query($query)  or die(mysql_error());
			
			if($insert){
				
				$query = "Update login_and_user_details SET username='".$db->escape($data['username'])."',
			password='".$db->escape($data['password'])."',
			email='".$db->escape($data['email'])."',
			company_name='".$db->escape($data['company_name'])."',
			phone='".$db->escape($data['phone'])."',
			location='".$db->escape($data['location'])."'
				where id='".$id."'";
				$insert=$db->query($query)  or die(mysql_error());
				if($insert){
				echo "<script>alert('".$query."')</script>";	
					// Calculation Get the current value check if it is greater then total value then add total vlue plus this value else if lesser then this value check utilize value and if lesser then this value add -the bal or if the passd value has greatr value then calculate and reduce in the balance value
					
					$query="select * from credit_limit where buyer_id='".$id."'";
					echo "<script>alert('".$query."')</script>";
					$num= $db->num_rows($query);		  
					if($num)
					{
						$row= $db->get_row($query);
						$credit_initial = intval($row['credit_initial']);   
						$credit_utilized = intval($row['credit_utilized']);   
						$credit_balance = intval($row['credit_balance']);   
						$creditlimit = intval($db->escape($_REQUEST['creditlimit']));   
						
						
						if ($creditlimit >= $credit_initial)
						
						{
							
							$credit_balanceP = ($creditlimit - $credit_initial);
							$credit_balanceP_F = $credit_balanceP + $credit_balance;
							
							
							
							
							
							$query = "update credit_limit SET credit_initial='".$db->escape($creditlimit)."',
							credit_balance='".$db->escape($credit_balanceP_F)."'
							where buyer_id='".$id."'";
							$insert=$db->query($query)  or die(mysql_error());
							if($insert){
								$obj = new add_log();
								$msg = "updated";
								$result = $obj->log_details($data['username'], 'buyer', $id, $msg);
								if($result = 1)
									$general->redirect('index.php?p=buyers-details&msg=2&id='.$id);
								
							}
							
						}
						
						else
						{
							$credit_balanceP = ($credit_initial - $creditlimit );
							$credit_balanceP_F =  $credit_balance - $credit_balanceP;
							
							$query = "update credit_limit SET credit_initial='".$db->escape($creditlimit)."',
							credit_balance='".$db->escape($credit_balanceP_F)."'
							where buyer_id='".$id."'";
							$insert=$db->query($query)  or die(mysql_error());
							if($insert){
								$obj = new add_log();
								$msg = "updated";
								$result = $obj->log_details($data['username'], 'buyer', $id, $msg);
								if($result = 1)
								$general->redirect('index.php?p=buyers-details&msg=2&id='.$id);
								
							}
							
							
						}
						
						
						
						
					}
					
					
					
					
					
				}
				
			}
		}
		
		function insertData($data)
		{
			global $db,$general;	
			//session_start();
			$newDate = date("Y", strtotime($data['volume_year']));
			$query_login = "INSERT INTO volume SET volume_number='".$db->escape($data['volume_number'])."', volume_year='".$db->escape($newDate)."'";
			$insert_Login = $db->query($query_login);
			if($result = 1)
			{
				$general->redirect('index.php?p=addvolume&msg=1');					
			}
		}
	
	}
?>