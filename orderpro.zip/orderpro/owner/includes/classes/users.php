<?php
include("../api/add_log.php");
	class content
	{
		function getData($id)
		{
			global $db;
			$select="select * from login_and_user_details where id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		function getcreditData($id)
		{
			global $db;
			$select="select * from credit_limit where buyer_id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		
		function checkData($data,$id)
		{
			
			
			global $db; 
			$error=array();
			
			if(!strlen(trim($data['companyname']))) $error['companyname'] = "Enter Company Name";
			
			if(!strlen(trim($data['username']))) $error['username'] = "Enter Buyer Name";
			if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $error['email'] = "Invalid email";
		 
			
			if(!strlen(trim($data['password']))) $error['password'] = "Enter Password";
			/*if(!strlen(trim($data['phone']))) $error['phone'] = "Enter phone";
				if(!strlen(trim($data['password']))) $error['password'] = "Enter password";
				if(!strlen(trim($data['city']))) $error['city'] = "Enter city";
			if(!strlen(trim($data['country']))) $error['country'] = "Enter country";*/
			
			
			return $error;
			
		}
		
		
		function updateData($data,$id)
		{
			
			global $db,$general;	
			$query = "UPDATE login_and_user_details SET username='".$db->escape($data['full_name'])."',
			password='".$db->escape($data['password'])."',
			role='".$db->escape($data['role'])."',
			plant_location='".$db->escape($data['Plant_location'])."',
			parent_role='".$db->escape($data['Parent_role'])."',
			email='".$db->escape($data['email'])."',			
			phone='".$db->escape($data['phone'])."',
			status='".$db->escape($data['status'])."'
			where id='".$id."'";
			$insert=$db->query($query)  or die(mysql_error());
			if($insert)
			{
				$obj = new add_log();
				$msg = "updated";
				$result = $obj->log_details($data['full_name'], 'user', $id, $msg);
					$general->redirect('index.php?p=users-details&msg=2&id='.$id);	
			}			
		}
		
		function insertData($data)
		{
			global $db,$general;	
			
			$query_login = "INSERT INTO login_and_user_details SET username='".$db->escape($data['full_name'])."',
			password='".$db->escape($data['password'])."',
			role='".$db->escape($data['role'])."',
			plant_location='".$db->escape($data['Plant_location'])."',
			parent_role='".$db->escape($data['Parent_role'])."',
			email='".$db->escape($data['email'])."',			
			phone='".$db->escape($data['phone'])."',
			status='".$db->escape($data['status'])."'";
			$insert_Login = $db->query($query_login) or die(mysql_error());
			$user_id = $db->lastid();
			
			if( $insert_Login){
				$obj = new add_log();
				$msg = "added";
				$result = $obj->log_details($data['full_name'], 'user', $user_id, $msg);
					$general->redirect('index.php?p=users&msg=1');
			}
		}
		
	}
?>