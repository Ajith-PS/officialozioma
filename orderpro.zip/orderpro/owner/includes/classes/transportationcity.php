<?php
	class content
	{ 
		function getData($id)
		{
			global $db;
			$select="select * from transport_cost_per_city where id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		function getData_product($id)
		{
			
			
			global $db;
			$query = "select * from transport_cost_per_city  where id='".$id."'";
			$rows = $db->get_results($query);
			foreach($rows as $row) {
				$select="select * from products where product_id='".$row['product_id']."'";
				$data=$db->get_row($select);
				return $data;
			}
		}
		function getData_City($id)
		{
			
			
			global $db;
			$query = "select * from transport_cost_per_city  where id='".$id."'";
			$rows = $db->get_results($query);
			foreach($rows as $row) {
				$select="select * from transportcity where id='".$row['city_id']."'";
				$data=$db->get_row($select);
				return $data;
			}
		}
		
	}
?>