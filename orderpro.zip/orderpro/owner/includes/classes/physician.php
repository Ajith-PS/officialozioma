<?php
class content
{
	function getData($id)
	{
		global $db;
		$select="select * from physicians where id=".(int)$id;
		$data=$db->get_row($select);
		return $data;
	}
	
	function checkData($data,$id)
	{
		global $db; 
		$error=array();
		
		if(!strlen(trim($data['name']))) $error['name'] = "Enter name";
		else{
			if($id) $sub_qry = " AND id<>".(int)$id; else $sub_qry = "";
			$query = "SELECT * FROM physicians WHERE name='".$db->escape($data['name'])."' $sub_qry";
			if($db->num_rows($query))  $error['name'] = "Name already exists";
		}
		
		return $error;
	}
	
	function updateData($data,$id)
	{	
		global $db, $general;
		$query = "update physicians SET name='".$db->escape($data['name'])."' where id=".(int)$id;
		$insert=$db->query($query)  or die(mysql_error());
		if($insert){
			$general->redirect('index.php?p=physicians&msg=2');
		}
	}
	
	function insertData($data)
	{	
		global $db, $general;
		$query = "INSERT INTO physicians SET name='".$db->escape($data['name'])."'";
		$insert = $db->query($query) or die(mysql_error());
		
		if($insert){
			$general->redirect('index.php?p=physicians&msg=1');
		}
	}
	
}
?>