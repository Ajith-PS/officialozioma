<?php

include("../api/add_log.php");
class content
{
	function getData($id)
	{
		global $db;
		$select="select * from products where product_id=".(int)$id;
		$data=$db->get_row($select);
		return $data;
	}
	
	function checkData($data,$id)
	{
		global $db; 
		$error=array();
		
		if(!strlen(trim($data['name']))) $error['name'] = "Enter name";
		else{
			if($id) $sub_qry = " AND id<>".(int)$id; else $sub_qry = "";
			$query = "SELECT * FROM products WHERE name='".$db->escape($data['name'])."' $sub_qry";
			if($db->num_rows($query))  $error['email'] = "Name already exists";
		}
		if(!strlen(trim($data['company_id']))) $error['company_id'] = "Enter company";
		
		return $error;
	}
	
	function updateData($data,$id)
	{
		global $db,$general;			
		$query = "update products SET product_name='".$db->escape($data['product_name'])."', product_code='".$db->escape($data['product_code'])."', measurement_unit='".$db->escape($data['measurementunit'])."', colors='".$db->escape($data['colors'])."', size='".$db->escape($data['size'])."' , gst='".$db->escape($data['gst'])."', rate_per_unit='".$db->escape($data['rate_per_unit'])."' , shell='".$db->escape($data['shell'])."', trolly='".$db->escape($data['trolly'])."', operations='".$db->escape($data['operations'])."', packaging='".$db->escape($data['packaging'])."', outsourcing='".$db->escape($data['outsourcing'])."' where product_id=".(int)$id;
		$insert=$db->query($query)  or die(mysql_error());
		if($insert){
			$msg = 'updated';
			$obj = new add_log();
			$result = $obj->log_details($data['product_name'], 'Product', $id, $msg);
			if($result = 1)
				$general->redirect('index.php?p=products-details&msg=2');
		}
	}
	
	function insertData($data)
	{
		global $db,$general;	
		
		$query = "INSERT INTO issue SET volume_number='".$db->escape($data['volume_number'])."', image_url='".$db->escape($data['issue_img'])."', date_from='".$db->escape($data['start'])."', date_to='".$db->escape($data['end'])."', page_from='".$db->escape($data['page_from'])."', page_to='".$db->escape($data['page_to'])."'";
		$insert = $db->query($query) or die(mysql_error());
		//$user_id = $db->lastid();
		if($insert){
				/*$msg = 'added';
				$obj = new add_log();
				$result = $obj->log_details($data['mname'], 'Raw Material', $user_id, $msg);
				if($result = 1)*/
					$general->redirect('index.php?p=addissue&msg=1');
		}
	}
	
}
?>