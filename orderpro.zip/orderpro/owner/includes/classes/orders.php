<?php
	include("../api/add_log.php");
	class content
	{	
		function insertData($data)
		{
			global $db,$general;
			$order_id = mt_rand(100000, 999999);
			$sel_query = "SELECT * from buyer_details where sys_dis_id = '".$db->escape($data['company_name_hidden'][0])."'";
				$rows = $db->get_row($sel_query);
				$credit_limit = $db->get_row("SELECT * from credit_limit WHERE buyer_id='".$rows['buyer_id']."'");
				
				$credit_initial = $credit_limit['credit_initial'];
				$credit_utilized = $credit_limit['credit_utilized'];
				$credit_balance = $credit_limit['credit_balance'];
				for($i=0; $i<count($_REQUEST['sub_total_price']); $i++)
				{				
					$totalval =	array_sum($_REQUEST['sub_total_price']);
				}
				$credit_balance_val = $credit_balance - $totalval;
				$credit_utilized_val = $credit_utilized + $totalval;
			//	echo "update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."' where buyer_id='".$rows['buyer_id']."'";
				$db->query("update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."' where buyer_id='".$rows['buyer_id']."'")  or die(mysql_error());			
			for($i=0; $i<sizeof($data['Prod_name_hidden']);$i++)
			{	
				$query = "INSERT INTO orders SET order_id='".$db->escape($order_id)."',
				buyer_id='".$db->escape($rows['buyer_id'])."',
				product_id='".$db->escape($data['Prod_id_hidden'][$i])."',			
				product_name='".$db->escape($data['Prod_name_hidden'][$i])."',
				qty='".$db->escape($data['quantity_hidden'][$i])."',
				gst='".$db->escape($data['gst_hidden'][$i])."',
				size='".$db->escape($data['size_hidden'][$i])."',
				color='".$db->escape($data['colors_hidden'][$i])."',
				unit='".$db->escape($data['measurementunit_hidden'][$i])."',
				unit_Price='".$db->escape($data['unit_price'][$i])."',
				prod_sub_total='".$db->escape($data['sub_total_price'][$i])."',
				status = 'Ordered'";
				$insert = $db->query($query) or die(mysql_error());

				if($insert)
				{
					$obj = new add_log();
					$msg = "placed";
					$result = $obj->log_details($rows['name_concerned_person'], 'Order', $rows['buyer_id'], $msg);
				}
			}
			
			if($insert){
					$general->redirect('index.php?p=orders&msg=1');
			}
		}
		
	}
?>