<?php
class content
{
	function getData($id)
	{
		global $db;
		$select="select * from admin where id=".(int)$id;
		$data=$db->get_row($select);
		return $data;
	}
	
	function checkData($data,$id)
	{
		global $db; 
		$error=array();
		
		if(!strlen(trim($data['name']))) $error['name'] = "Enter Firstname";
		if(!strlen(trim($data['username']))) $error['username'] = "Enter username";
		else{
			if($id) $sub_qry = " AND id<>".(int)$id; else $sub_qry = "";
			$query = "SELECT * FROM admin WHERE username='".$db->escape($data['username'])."' $sub_qry";
			if($db->num_rows($query))  $error['username'] = "Username already exists";
		}
		if(!strlen(trim($data['email']))) $error['email'] = "Enter email";
		else if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $error['email'] = "Invalid email";
		else{
			if($id) $sub_qry = " AND id<>".(int)$id; else $sub_qry = "";
			$query = "SELECT * FROM admin WHERE email='".$db->escape($data['email'])."' $sub_qry";
			if($db->num_rows($query))  $error['email'] = "Email already exists";
		}
		if(!strlen(trim($data['phone']))) $error['phone'] = "Enter phone";
		if(!strlen(trim($data['password']))) $error['password'] = "Enter password";
		
		return $error;
	}
	
	function updateData($data,$id)
	{
		global $db,$general;			
		$query = "update admin SET name='".$db->escape($data['name'])."',
										username='".$db->escape($data['username'])."',
										email='".$db->escape($data['email'])."',
										password='".$db->escape($data['password'])."',
										phone='".$db->escape($data['phone'])."'
										where id=".(int)$id;
		$insert=$db->query($query)  or die(mysql_error());
		if($insert){
			$general->redirect('index.php?p=admins&msg=2');
		}
	}
	
	function insertData($data)
	{
		global $db,$general;		
		$query = "INSERT INTO admin SET name='".$db->escape($data['name'])."',
										username='".$db->escape($data['username'])."',
										email='".$db->escape($data['email'])."',
										password='".$db->escape($data['password'])."',
										phone='".$db->escape($data['phone'])."'
										user_role = 'subadmin'";
		$insert = $db->query($query) or die(mysql_error());
		
		if($insert){
			$general->redirect('index.php?p=admins&msg=2');
		}
	}
	
}
?>