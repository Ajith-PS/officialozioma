<div class="footer">
	<!-- <div class="pull-right"> 10GB of <strong>250GB</strong> Free. </div>-->  	<div>webinfo,cochin,Ph 8281414270 </div>
</div>
</div>
</div>

<!-- Mainly scripts --> 
<script src="js/jquery-2.1.1.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script> 
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script> 

<!-- Flot --> 
<script src="js/plugins/flot/jquery.flot.js"></script> 
<script src="js/plugins/flot/jquery.flot.tooltip.min.js"></script> 
<script src="js/plugins/flot/jquery.flot.spline.js"></script> 
<script src="js/plugins/flot/jquery.flot.resize.js"></script> 
<script src="js/plugins/flot/jquery.flot.pie.js"></script> 
<script src="js/plugins/flot/jquery.flot.symbol.js"></script> 
<script src="js/plugins/flot/jquery.flot.time.js"></script> 

<!-- Peity --> 
<script src="js/plugins/peity/jquery.peity.min.js"></script> 
<script src="js/demo/peity-demo.js"></script> 
<script src="js/plugins/dataTables/datatables.min.js"></script>
<!-- FooTable -->
<script src="js/plugins/footable/footable.all.min.js"></script>
<!-- Custom and plugin javascript --> 
<script src="js/inspinia.js"></script> 
<script src="js/plugins/pace/pace.min.js"></script> 
<!-- Page-Level Scripts -->
<script>
	$(document).ready(function() {
		
		$('.footable').footable();
		$('.footable2').footable();
		
	});
	
</script>
<!-- jQuery UI --> 
<script src="js/plugins/jquery-ui/jquery-ui.min.js"></script> 

<!-- Data picker -->
<script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- Jvectormap --> 
<script src="js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script> 
<script src="js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script> 

<!-- EayPIE --> 
<script src="js/plugins/easypiechart/jquery.easypiechart.js"></script> 
<!-- Clock picker -->
<script src="js/plugins/clockpicker/clockpicker.js"></script>
<!-- Sparkline --> 
<script src="js/plugins/sparkline/jquery.sparkline.min.js"></script> 
<!-- Select2 -->
<script src="js/plugins/select2/select2.full.min.js"></script>
<!-- Sparkline demo data  --> 
<script src="js/demo/sparkline-demo.js"></script> 
<script src="js/plugins/summernote/summernote.min.js"></script>
<link rel="stylesheet" href="../css/jquery.switchButton.css" />
<script type="text/javascript" src="../js/jquery.switchButton.js"></script>
<script>
	$(document).ready(function() {
		$(".select2_demo_3").select2({
			placeholder: "Select a City",
			allowClear: true
		});
		
		$(".select2_demo_4").select2({
			placeholder: "Select a Product"
		});
		$("#btn_submit1").click(function(event) {
			var title = $("#title").val();
			var content = $(".note-editable").text();
			var banner = $("input[name=banner]").val();
			if(title <= 0)
			{
				
			}
			else if (content.length <= 0)
			{ 
				
			}
			else if (banner <= 0)
			{
				
			}
			else
			{
				$("#btn_submit2").click();				
				return false;
			}
			
		})
		
		$('.clockpicker').clockpicker( { twelvehour: true,vibrate:true });
		$('.summernote').summernote();
		$('.datepicker').datepicker();
		$('#data_1 .input-group.date').datepicker({
			todayBtn: "linked",
			keyboardNavigation: false,
			forceParse: false,
			calendarWeeks: true,
			autoclose: true
		});
		
		$('.dataTables-example').DataTable({
			dom: '<"html5buttons"B>lTfgitp',
			pageLength: "50",
			buttons: [
			{extend: 'print',
				customize: function (win){
					$(win.document.body).addClass('white-bg');
					$(win.document.body).css('font-size', '10px');
					
					$(win.document.body).find('table')
					.addClass('compact')
					.css('font-size', 'inherit');
				}
			}
			],
			"bStateSave": true,
		});
		$( "#healthcondition" ).switchButton({on_label: 'YES',off_label: 'NO'}).change(function(){
			if($(this).is(':checked')){
				$('#healthdesc').show();
			}
			else{
				$('#healthdesc').hide();
			}
		});
		$( "#gp" ).switchButton({on_label: 'YES',off_label: 'NO'}).change(function(){
			if($(this).is(':checked')){
				$('#gpdesc').show();
			}
			else{
				$('#gpdesc').hide();
			}	
		});
	});
</script>
</body></html>