<?php 
include("includes/classes/functions.php");
if(isset($_POST['Submit']))
{
	$update=$all->changepassword($_POST);
}
?>
<script type="text/javascript">
function check()
{
	var pass=$("#password").val();
	var npass=$("#npass").val();
	var cpass=$("#cpass").val();
	if(pass=='')
	{
		alert("Plase enter old password");
		$("#password").focus();
		return false;
	}
	if(npass=='')
	{
		alert("Plase enter New password");
		$("#npass").focus();
		return false;
	}
	if(cpass=='')
	{
		alert("Plase enter Confirm password");
		$("#cpass").focus();
		return false;
	}
	if(cpass!=npass)
	{
		alert("New Password and Confirm password are not same");
		$("#cpass").focus();
		return false;
	}
	if((npass.length<6) || (npass.length>8))
	{
		alert("Plase must contain 6 to 8 characters");
		$("#npass").focus();
		return false;
	}

}
</script>

<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-10">
    <h2>Change Password</h2>
    <ol class="breadcrumb">
      <li> <a href="index.php">Home</a> </li>
      <li class="active"> <strong>Change Password</strong> </li>
    </ol>
  </div>
  <div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
  <div class="row">
    <div class="col-lg-12">
      <?php  if(isset($_REQUEST['msg'])) { ?>
      <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <?php if($_REQUEST['msg']==1) { echo "Password Updated Successfully."; }
                    else if($_REQUEST['msg']==2) { echo "Old Password and New Password are mismatched."; }
                    else if($_REQUEST['msg']==3) { echo "Old Password is wrong."; } 
         ?>
      </div>
      <?php } ?>
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>Change Password</h5>
        </div>
        <div class="ibox-content">
          <form method="post" onsubmit="return check();">
            <div class="box-body"> 
              <!--<legend>Add Candidate</legend>-->
              <div class="form-group">
                <label class="control-label" for="focusedInput">Old Password<span class="required">*</span></label>
                <input class="form-control" type="password" name="password" id="password" value="" >
              </div>
              <div class="form-group">
                <label class="control-label" for="focusedInput">New Password<span class="required">*</span></label>
                <input class="form-control" type="password" name="npass" id="npass" value="">
              </div>
              <div class="form-group">
                <label class="control-label" for="focusedInput">Confirm Password<span class="required">*</span></label>
                <input class="form-control" type="password" name="cpass" id="cpass" value="">
              </div>
            </div>
            <div class="box-footer">
              <input type="reset" class="btn btn-default" name="cancel" id="cancel" value="Cancel">
              <input type="submit" name="Submit" value="Save Changes" id="submit" class="btn btn-info pull-right"/>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- /block --> 
  </div>
</div>