<?php
	include("../api/add_log.php");
	session_start();
	$id = $_SESSION['auserid'];
	if(isset($_GET['act']) && $_GET['act']=='delete' && $_GET['id'])
	{global $db,$general;	
		$query = "update buyer_details SET status='0' where buyer_id='".$_GET['id']."'";
		$insert=$db->query($query)  or die(mysql_error());
		if($insert){
			$query = "update login_and_user_details SET status='0' where id='".$_GET['id']."'";
			$insert=$db->query($query)  or die(mysql_error());
			if($insert){
				$query = "Select * from login_and_user_details where id='".$_GET['id']."'";
				$insert=$db->get_row($query)  or die(mysql_error());
					$obj = new add_log();
					$msg = "Owner deletes buyer";
					$result = $obj->log_details($insert['username'], 'buyer', $_GET['id'], $msg);
					if($result = 1)			
						$general->redirect('index.php?p=buyers-details&msg=3');
			}
		}
		
		
	}
?>
<style>
.sidenav {
    height: 600px;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    right: 0;
    background-color: #f1f1f1;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 25px;
    color: #818181;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color: #808080;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

.sidenav .subject
{
	position: absolute;
    top: 15px;
   
    font-size: 26px;
   
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2><?php// if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Inbox</h2>
		<ol class="breadcrumb">
			<li> <a href="index.php">Home</a> </li>
			<li class="active"> <strong><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?> Inbox</strong> </li>
		</ol>
	</div>
	<div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<?php if(isset($_GET['msg']) && (int)$_GET['msg']){?>
				<?php if($_GET['msg']==1 || $_GET['msg']==2) {?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">�</button>
						<?php if($_GET['msg']==1) { ?>
							User added successfully.
							<?php } else if($_GET['msg']==2) {?>
							Buyer updated successfully.
							<?php } else if($_GET['msg']==4) {?>
							User already exist.
						<?php } ?>
					</div>
				<?php } ?>
				<?php if($_GET['msg']==3){?>
					<div class="alert alert-success">
						<button type="button" class="close" data-dismiss="alert">�</button>
					Buyer deleted successfully. </div>
				<?php } ?>
			<?php } ?>
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<button class="btn btn-warning btn-s tooltip-top" onclick="getprod_dels(this.value);"  type="button" data-toggle="modal" data-target="#myModal2"  data-original-title="Compose">Compose</button>
				</div>
				<div class="ibox-title">
					<h5><?php //if(isset($_GET['type']) && $_GET['type']=='paid') echo 'Paid'; else echo 'Free';?>Inbox</h5>
					<div class="ibox-tools">
						<?php 
						$get_mail = $db->get_row("SELECT * FROM login_and_user_details where id='".$id."'");
						$msg_count = "Select * from mail_info where tomail = '".$get_mail['email']."' order by dateandtime DESC";
						//$msg_count1 = "Select * from mail_info order by dateandtime DESC limit 0,10";
						$count = $db->num_rows($msg_count);
						$rows = $db->get_results($msg_count);
						?>
						<span class="label label-warning-light pull-right"><?php echo $count; ?> Messages</span>
							<input type = "hidden" name="rownum" id = "rownum" value= "<?php echo $count; ?>" />
					</div>
				</div>
				<div class="ibox-content">
					<div class="table-responsive">
						<div style="text-align:right; margin-bottom:10px;">
						</div>
						<table class="table table-striped table-bordered table-hover dataTables-example" >
							<thead>
								<tr>
									<td>&nbsp;</td>									
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>										
										<?php 																
											foreach($rows as $row)
											{
												if($row['readstatus'] == '0')
													echo '<b>';	
												$user_details = $db->get_row("Select * from login_and_user_details where id='".$row['login_id']."'");
											?>
												<div class="feed-element" onclick="openNav('<? echo $row['ID']; ?>')">
													<a href="#" class="pull-left">
														<img alt="image" class="img-circle" src="img/profile.jpg">
													</a>
													<div class="media-body ">
													<?php 
														$olddate = strtotime($row['dateandtime']);
														$newdate = date('Y-m-d', $olddate);
														$newdate1 = date('d.m.Y', $olddate);
														$time = date('h:i A',$olddate);
														$timeDiff1 = "";
														if($newdate == date('Y-m-d'))
														{
														//echo date("Y-m-d h:i:sa");
															$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
															$timeDiff1 = abs($endTimeStamp1 - $olddate);
															$timeDiff1 = round($timeDiff1 / 60);
			
															if($timeDiff1 > 59)
															{
																$timeDiff1 = floor($timeDiff1 / 60);
																$timeDiff1 = $timeDiff1."hours ago";																
															}
															else
															{
																$timeDiff1 = $timeDiff1."mins ago";
															}
														}
														else if ($newdate == date('Y-m-d',strtotime("-1 days")))
														{
															$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
															$timeDiff1 = abs($endTimeStamp1 - $olddate);
															$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
														}
														else
														{
																$startTimeStamp = strtotime($newdate);
																$endTimeStamp = strtotime("today");

																$timeDiff1 = abs($endTimeStamp - $startTimeStamp);

																$numberDays = $timeDiff1/86400;  // 86400 seconds in one day

																// and you might want to convert to integer
																$timeDiff1 = intval($numberDays)."days ago";
																//echo $numberDays."days ago";
																}
													?>
														<small class="pull-right"><?php echo $timeDiff1; ?> </small>
														<strong><?php echo $user_details['username']; echo "(".$user_details['role'].")";?> </strong> 
														
														<br>
														<small class="text-muted"><?php
															
																if($newdate == date('Y-m-d'))
																	echo "Today";
																else if ($newdate == date('Y-m-d',strtotime("-1 days")))
																	echo "Yesterday";
																else
																{
																$startTimeStamp = strtotime($newdate);
																$endTimeStamp = strtotime("today");

																$timeDiff = abs($endTimeStamp - $startTimeStamp);

																$numberDays = $timeDiff/86400;  // 86400 seconds in one day

																// and you might want to convert to integer
																$numberDays = intval($numberDays);
																echo $numberDays."days ago";
																}
															
															echo " ".$time." - ".$newdate1;
															?> </small><br/>
														<strong class="text-muted"><? echo $row['subjects']; ?></strong>
													</div>
												</div>
										<?php 
											if($row['readstatus'] == '0')
											echo '</b>';
										}										
										?>										
									</td>
								</tr>								
							</tbody>
						</table>
						<div id="mySidenav" class="sidenav">							
							<!--<small class="pull-right"><a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a></small>
							<input type="hidden" id="mailid" name = "mailid" value="" />
							<input type="hidden" id="emailemail1" name="emailemail1" value=""/>
							<b class="pull-left subject" id="emailsubject"></b>							
							<div style="background-color:#1a1a1a;border:1px solid black;">								
							</div>							
							<div class="feed-element" style="border 1px solid red;">
								<a href="profile.html" class="pull-left">
									<img alt="image" class="img-circle" src="img/a7.jpg">
								</a>
								<div class="media-body "> 
									<small class="pull-right">46h ago<button type="button" class="btn btn-icon btn-pure btn-default"><i class="fa fa-reply" aria-hidden="true"></i></button></small>
									<strong id="emailname"></strong> <span id = "emailemail"></span><br>
									<small class="text-muted">to me</small> <br/>
									<small class="text-muted">3 days ago at 7:58 pm - 10.06.2014</small>
									<br><br><br>								
									<p  class="pull-left" id="emailmsg">
										
									</p>
								</div>
							</div>
							<div class="slidePanel-comment">    
								<textarea class="maxlength-textarea form-control mb-sm mb-20 form-control" rows="4" id="replymsg" name="replymsg"></textarea>
								<button class="btn btn-primary" data-dismiss="modal" type="button" onclick="reply_mail()">Reply</button>
							</div> -->
						</div>
						<div class="modal inmodal" id="myModal2" tabindex="-1" role="dialog" aria-hidden="true">
							<div class="modal-dialog">
								
								<form id="send_mail" method="post" enctype="multipart/form-data">
									<div class="modal-content animated bounceInRight">
										<div class="modal-header">											
											<h4 class="modal-title">Compose</h4>
											<small class="font-bold"></small>
										</div>										
										<div class="modal-body">
											<div class="row">	
												<div class="col-lg-12">
													<div  id ="Update_manufact_name_" class="form-group"><label>To*</label> 
														<Select name="toemail" id="toemail" class="form-control">
															<option value="-1">SELECT OPTION</option>
															<?php $getemail = $db->get_results("Select * from login_and_user_details where id <> '".$id."'");
																foreach($getemail as $row)
																{ ?>
																	<option value="<? echo $row['email']; ?>"><? echo $row['username'].'('.$row['role']. '/'. $row['location'].')'; ?></option>';
															<?	}
															?>
														</Select>
													</div>
												</div>	
											</div>	
											<div class="row">	
												<div class="col-lg-12">
													<div  id ="Update_manufact_name_" class="form-group"><label>Subject*</label> <input  id="subject" name="subject" type="text" placeholder="Enter Subject" class="form-control "></input></div>
												</div>	
											</div>	
											
											<div class="row">
												<div class="col-lg-12">
													<div  id ="Update_weight_"  class="form-group"><label>Message*</label> <textarea rows="4" cols="50" name="message" id="message"class="form-control "></textarea></div>
												</div>														
											</div>		
										</div>
										<div class="modal-footer">																					
											<button type="button" onclick="location.reload();" class="btn btn-white" data-dismiss="modal">Close</button>
											<button type="button" onclick="submit_1()" class="btn btn-primary">Send</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	function filterCat(val){
		location.replace('index.php?p=users&type=paid&cat='+val);
	}
</script>
<script>
function openNav(mail_id) 
{
		var readstatus = '1';
			jQuery.ajax({
				url:'../api/ajax_get_role.php?action=get_mail',
				type: "POST",
				data: {mail_id:mail_id,readstatus:readstatus},
				success: function(data)
				{
					//var fields = data.split('~');
					//alert(data);
					$("#mySidenav").html(data);
					//$( "#emailsubject" ).html(fields[0]);
					//$( "#emailname" ).html(fields[1]);
					//$( "#emailemail" ).html('('+fields[2]+')');
					//$( "#emailemail1" ).val(fields[2]);
					//$( "#emailmsg" ).html(fields[3]);
					//$("#mailid").val(mail_id);
				//	location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
			});
    document.getElementById("mySidenav").style.width = "650px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}


function submit_1(){
		
		var toemail = $.trim($("#toemail").val());
		var subject = $.trim($("#subject").val());
		var message = $.trim($("#message").val());		
		if ( $.trim($("#toemail").val())=="-1")
		{
			$( "#subject" ).removeClass( "has-error" );
			$( "#message" ).removeClass( "has-error" );
			$( "#toemail" ).addClass( "has-error" );
			
		}
		else if ( $.trim($("#subject").val())=="")
		{
			$( "#message" ).removeClass( "has-error" );
			$( "#toemail" ).removeClass( "has-error" );
			$( "#subject" ).addClass( "has-error" );
			
		}
		else if ( $.trim($("#message").val())=="")
		{
			$( "#toemail" ).removeClass( "has-error" );
			$( "#subject" ).removeClass( "has-error" );
			$( "#message" ).addClass( "has-error" );
			
		}
		else
		{
			$( "#subject" ).removeClass( "has-error" );
			$( "#message" ).removeClass( "has-error" );
			$( "#toemail" ).removeClass( "has-error" );
			
			jQuery.ajax({
				url:'../api/api.php?action=send_mail',
				type: "POST",
				data: {toemail:toemail,subject:subject,message:message},
				success: function(data)
				{
					
					if(data == 2)
					{
						alert('Mail Sent Successfully !');
					}
					else
					{
						alert('Mail not sent please try again after sometime. Thankyou !');
					}
					location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
			});
		}
	}
	
	
	function reply_mail(){
		
		var toemail = $.trim($("#emailemail1").val());
		var fromemail = $.trim($("#fromemail").val());
		var subject = $.trim($("#emailsubject").html());
		var message = $.trim($("#replymsg").val());	
		var mailid = $.trim($("#mailid").val());	
		if ( $.trim($("#replymsg").val())=="")
		{			
			$( "#replymsg" ).addClass( "has-error" );			
		}
		else
		{			
			$( "#replymsg" ).removeClass( "has-error" );			
			
			jQuery.ajax({
				url:'../api/api.php?action=reply_mail',
				type: "POST",
				data: {toemail:toemail,subject:subject,message:message,mailid:mailid,fromemail:fromemail},
				success: function(data)
				{
					
					if(data == 2)
					{
						alert('Mail Sent Successfully !');
					}
					else
					{
						alert('Mail not sent please try again after sometime. Thankyou !');
					}
					location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
			});
		}
	}
	
	
	function mail_dels(order_id)
	{
		jQuery.ajax({
				url:'../api/ajax_get_role.php?action=get_mail',
				type: "POST",
				data: {order_id:order_id},
				success: function(data)
				{
					var fields = data.split('~');
				//	alert(fields);
					$( "#subject" ).val(fields[1]);
					$( "#message" ).val(fields[2]);
				//	location.reload();
					
				},
				error: function(xhr, status, error) {
					alert(xhr.responseText);
					
				}
		});
	}
</script>