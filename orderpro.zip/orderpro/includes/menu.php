<nav class="navbar-default navbar-static-side" role="navigation">
	<div class="sidebar-collapse">
		<ul class="nav metismenu" id="side-menu">
			<li class="nav-header">
				<div class="dropdown profile-element"><a data-toggle="dropdown" class="dropdown-toggle" href="#"> <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo SITE_NAME;?></strong> </span> <span class="text-muted text-xs block"><?php echo ucwords($_SESSION['usertype']);?>  <b class="caret"></b></span> </span> </a>
					<ul class="dropdown-menu animated fadeInRight m-t-xs">
						<li><a href="index.php?p=edit-profile">Profile</a></li>
						<li><a href="index.php?p=change-password">Change Password</a></li>
						<li class="divider"></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
				<div class="logo-element"> LR+ </div>
			</li>
			<li class="<?php if(!isset($_GET['p'])) echo 'active';?>"><a href="index.php"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='distributor' || $_GET['p']=='distributor')) echo 'active';?>"> <a href="index.php?p=distributor"><i class="fa fa-users"></i> <span>Create New Distributor</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='distributors' || $_GET['p']=='distributorview')) echo 'active';?>"> <a href="index.php?p=distributors"><i class="fa fa-gittip"></i> <span>Manage Distributor</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='product_list_and_price_list' || $_GET['p']=='product_list_and_price_list')) echo 'active';?>"> <a href="index.php?p=product_list_and_price_list"><i class="fa fa-gittip"></i> <span>Product List & Price List</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<?php /*?><li class="<?php if(isset($_GET['p']) && ($_GET['p']=='prompt' || $_GET['p']=='prompts')) echo 'active';?>"> <a href="#"><i class="fa fa-gittip"></i> <span>Prompts</span> <i class="fa fa-angle-left pull-right"></i></a>
				<ul class="nav nav-second-level collapse">
				<li class="<?php if(isset($_GET['p']) && $_GET['p']=='prompt') echo 'active';?>"><a href="index.php?p=prompt">Add Prompt</a></li>
				<li class="<?php if(isset($_GET['p']) && $_GET['p']=='prompts') echo 'active';?>"><a href="index.php?p=prompts">All Prompts</a></li>
				</ul>
			</li><?php */?>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='purchaseorderhistoryview' || $_GET['p']=='purchaseorderhistory')) echo 'active';?>"> <a href="index.php?p=purchaseorderhistory"><i class="fa fa-gittip"></i> <span>Purchase Order History</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='physician' || $_GET['p']=='taxrates')) echo 'active';?>"> <a href="index.php?p=taxrates"><i class="fa fa-gittip"></i> <span>Taxes Rate’s</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='transportationcity' || $_GET['p']=='physicians')) echo 'active';?>"> <a href="index.php?p=transportationcity"><i class="fa fa-gittip"></i> <span>Transportation Rates</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='NewPayments' || $_GET['p']=='physicians')) echo 'active';?>"> <a href="index.php?p=NewPayments"><i class="fa fa-gittip"></i> <span>New Payments</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='addpayment' )) echo 'active';?>">  <a href="index.php?p=addpayment&id="><i class="fa fa-gittip"></i> <span>Add Payment</span> <i class="fa fa-angle-left pull-right"></i></a>
				
			</li>
			<li class="<?php if(isset($_GET['p']) && ($_GET['p']=='edit-profile' || $_GET['p']=='change-password')) echo 'active';?>"> <a href="#"><i class="fa fa-wrench"></i> <span>Settings</span> <i class="fa fa-angle-left pull-right"></i></a>
				<ul class="nav nav-second-level collapse">
					<li class="<?php if(isset($_GET['p']) && $_GET['p']=='edit-profile') echo 'active';?>"><a href="index.php?p=edit-profile">Edit Profile</a></li>
					<li class="<?php if(isset($_GET['p']) && $_GET['p']=='change-password') echo 'active';?>"><a href="index.php?p=change-password">Change Password</a></li>
				</ul>
			</li>
		</ul>
	</div>
</nav>
<div id="page-wrapper" class="gray-bg">
	<div class="row border-bottom">
		<nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
			<div class="navbar-header"> <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a> </div>
			<ul class="nav navbar-top-links navbar-right">
				
				<!-- Notifications Menu -->
				<li class="dropdown"> 
					
				</li>
				<li> <a href="logout.php"> <i class="fa fa-sign-out"></i> Log out </a> </li>
			</ul>
		</nav>
	</div>
