<?php 
include("includes/classes/functions.php");
if($_POST)
{
	$update=$all->updateprofile($_POST);	
}
 ?>
<script type="text/javascript">
function check()
	{
		if($('#aname').val()=='')
		{
           $('#anmae1').html('<span class="error1" id="aname1">Enter Your Name</span>');
		   $('#aname').focus();
           errr=1;
        } 
		else
		{
			$('#aname1').hide();
		}
		if($('#uname').val()=='')
		{
           $('#unmae1').html('<span class="error1" id="uname1">Enter Your Name</span>');
		   $('#uname').focus();
           errr=1;
        } 
		else
		{
			$('#uname1').hide();
		}	
		if($('#email').val()=='')
		{
            $('#email1').html('<span class="error1" id="email1">Enter Email Address</span>');
			 $('#email').focus();
			errr=1;
        }
		else if(!IsEmail($('#email').val())) 
		{ 
			 $('#email1').html('<span class="error1" id="email1">Invalid Email Address</span>');
			 $('#email').focus();
               errr=1;
		} 
		else
		{
			$('#email1').hide();
		}
		
		if(errr==1)
		{
            return false;
		}
	   	else
		{
			return true;
		}
	}
</script>

<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-10">
    <h2>Edit Profile</h2>
    <ol class="breadcrumb">
      <li> <a href="index.php">Home</a> </li>
      <li class="active"> <strong>Edit Profile</strong> </li>
    </ol>
  </div>
  <div class="col-lg-2"> </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">
  <div class="row">
    <div class="col-lg-12">
      <?php if(isset($_GET['msg'])){?>
      <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert">×</button>
        Profile details updated successfully.</div>
      <?php } ?>
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <h5>
            <?php if(isset($_GET['id'])) echo 'Edit'; else echo 'Add';?>
            Ad</h5>
        </div>
        <div class="ibox-content">
          <?php $details=$all->editprofile(); ?>
          <form method="post" enctype="multipart/form-data" onsubmit="return check();">
            <div class="box-body"> 
              <!--<legend>Add Candidate</legend>-->
              <div class="form-group">
                <label class="control-label" for="focusedInput">Name<span class="required">*</span></label>
                <input class="form-control" type="text" name="aname" id="aname" value="<?php echo $details['name']; ?>">
                <span id="anmae1"  style="color:#DE1F26;"></span> </div>
              <div class="form-group">
                <label class="control-label" for="focusedInput">Login Name<span class="required">*</span></label>
                <input class="form-control" type="text" name="uname" id="uname" value="<?php echo $details['username']; ?>">
                <span id="unmae1"  style="color:#DE1F26;"></span> </div>
              <div class="form-group">
                <label class="control-label" for="focusedInput">Email id<span class="required">*</span></label>
                <input class="form-control" type="email" name="email" id="email" value="<?php echo $details['email']; ?>">
                <span id="email1"  style="color:#DE1F26;"></span> </div>
              <div class="form-group">
                <label class="control-label" for="focusedInput">Phone Number<span class="required">*</span></label>
                <input class="form-control" type="text" name="phone" id="phone" value="<?php echo $details['phone']; ?>">
                <span id="phone"  style="color:#DE1F26;"></span> </div>
            </div>
            <div class="box-footer">
              <input type="reset" class="btn btn-default" name="cancel" id="cancel" value="Cancel" onclick="return canceldata();">
              <input type="submit" name="submit" value="Save Changes" id="submit" class="btn btn-info pull-right"/>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
function cancelme()
{
	$(".form-group").removeClass("error");
	$(".help-inline").hide();
	$("#aname").attr("value",""); 
	$("#uname").attr('value',"");
	$("#email").attr('value',"");
	$("#pic").css('display',"none");
}
</script> 
