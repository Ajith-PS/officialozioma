<?php
class allfunctions
{
	public function editprofile()
	{
		global $db; 
		if($_SESSION['usertype']=='admin'){
			$sql="select name,username,email,id,phone from admin where id=".(int)$_SESSION['auserid'];
		}
		else{
			$sql="select * from companies where id=".(int)$_SESSION['auserid'];
		}
		if($db->num_rows($sql))
		{
			$res=$db->get_row($sql);
		}
		return $res;
	}
	
	// update admin profile
	public function updateprofile($data)
	{
		global $db,$general;			
		$name=$db->escape($data['aname']);
		$uname=$db->escape($data['uname']);
		$email=	$db->escape($data['email']);
		$phone=$db->escape($data['phone']);
		if($_SESSION['usertype']=='admin'){
			$update=$db->query("update admin set name='".$name."', username='".$uname."',email='".$email."',phone='".$phone."' where id=".(int)$_SESSION['auserid']);
		}
		else{
			$update=$db->query("update companies set name='".$name."', email='".$email."',phone='".$phone."' where id=".(int)$_SESSION['auserid']);
		}
		
		if($update)
		{
			$_SESSION['username']=$name;
			$general->redirect('index.php?p=edit-profile&msg=success');	
		}
		else
		{
			$general->redirect('index.php?p=edit-profile&msg=failure');	
		}
	}
	public function changepassword($data)
	{
		global $db,$general;			
		$old=$db->escape($data['password']);
		$new=$db->escape($data['npass']);
		$cpass=$db->escape($data['cpass']);
		if($new!=$cpass)
		{
			$general->redirect('index.php?p=change-password&msg=2');
		}
		else
		{
			$check="select password from admin where id=".(int)$_SESSION['auserid'];
			if($db->num_rows($check))
			{
				$rcheck=$db->get_row($check);	
				if($rcheck['password']!=$old)
				{
					$general->redirect('index.php?p=change-password&msg=3');
				}
				else
				{
					if($_SESSION['usertype']=='admin'){
						$qres=$db->query("update admin set password='".$new."' where id=".(int)$_SESSION['auserid']);
					}
					else{
						$qres=$db->query("update companies set password='".$new."' where id=".(int)$_SESSION['auserid']);
					}
				}
			}
			else
			{
				$general->redirect('index.php?p=change-password&msg=4');
			}
		}
	}
}
$all=new allfunctions();
?>