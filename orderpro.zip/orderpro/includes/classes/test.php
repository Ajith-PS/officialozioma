<?php
class content
{
	function getData($id)
	{
		global $db;
		$select="select * from ads where id=".(int)$id;
		$data=$db->get_row($select);
		return $data;
	}
	
	function checkData($data,$id)
	{
		global $db; 
		$error=array();
		
		if(!strlen(trim($data['title']))) $error['title'] = "Enter title";
		/*else{
			if($id) $sub_qry = " AND id<>".(int)$id; else $sub_qry = "";
			$query = "SELECT * FROM ads WHERE title='".$db->escape($data['title'])."' $sub_qry";
			if($db->num_rows($query))  $error['title'] = "Page title already exists";
		}*/
		if(!strlen(trim($data['url']))) $error['url'] = "Enter url";	
		if(!strlen(trim($data['position']))) $error['position'] = "Enter position";
		
		return $error;
	}
	
	function updateData($data,$id)
	{	
		global $db, $general;
		$query = "update ads SET title='".$db->escape($data['title'])."', position='".$db->escape($data['position'])."', url='".$db->escape($data['url'])."', price='".$db->escape($data['price'])."' where id=".(int)$id;
		$insert=$db->query($query);
		if($insert){
			if(isset($_FILES['image']['name'])){
				$ext =  pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
				$image = "ad".$id.".".$ext;
				if(move_uploaded_file($_FILES['image']['tmp_name'],'../images/'.$image)){
					$query = "update ads SET image='".$db->escape($image)."' where id=".(int)$id;
					$db->query($query);
				}
			}
			$general->redirect('index.php?p=ads&msg=2');
		}
	}
	
	function insertData($data)
	{	
		global $db, $general;
		$query = "INSERT INTO ads SET title='".$db->escape($data['title'])."', position='".$db->escape($data['position'])."', url='".$db->escape($data['url'])."', price='".$db->escape($data['price'])."'";
		$insert = $db->query($query);
		
		if($insert){
			$id=$db->lastid();
			if(isset($_FILES['image']['name'])){
				$ext =  pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
				$image = "ad".$id.".".$ext;
				if(move_uploaded_file($_FILES['image']['tmp_name'],'../images/'.$image)){
					$query = "update ads SET image='".$db->escape($image)."' where id=".(int)$id;
					$db->query($query);
				}
			}
			$general->redirect('index.php?p=ads&msg=1');
		}
	}
	
}
?>