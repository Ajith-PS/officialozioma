<?php
if(isset($_GET['p'])) $p=$_GET['p']; else $p='home';
if(file_exists("includes/".$p.".php")){
	include("includes/".$p.".php");
}
?>