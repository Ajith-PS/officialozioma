<?php
	class general{
		function make_thumb($img_name,$filename,$new_w,$new_h,$ext)
		{
			if(!strcmp("jpg",$ext) || !strcmp("JPG",$ext) || !strcmp("jpeg",$ext) || !strcmp("JPEG",$ext))
			$src_img=imagecreatefromjpeg($img_name);
			
			if(!strcmp("gif",$ext) || !strcmp("GIF",$ext))
			$src_img=imagecreatefromgif($img_name);
			
			if(!strcmp("png",$ext) || !strcmp("PNG",$ext))
			$src_img=imagecreatefrompng($img_name);
			
			$old_x=imagesx($src_img);
			$old_y=imagesy($src_img);
			
			$ratio1=$old_x/$new_w;
			$ratio2=$old_y/$new_h;
			
			if($ratio1>$ratio2) {
				$thumb_w=$new_w;
				$thumb_h=$old_y/$ratio1;
			}
			else {
				$thumb_h=$new_h;
				$thumb_w=$old_x/$ratio2;
			}
			$dst_img=imagecreatetruecolor($thumb_w,$thumb_h);
			
			imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);
			
			if(!strcmp("png",$ext))
			imagepng($dst_img,$filename);
			if(!strcmp("gif",$ext))
			imagegif($dst_img,$filename);
			else
			imagejpeg($dst_img,$filename);
			
			imagedestroy($dst_img);
			imagedestroy($src_img);
		}
		function get_thumb_sizes(){
			return array("b"=>"500x500", "c"=>"80x80");
		}
		function get_thumb_ext($image){
			return pathinfo($image, PATHINFO_EXTENSION);
		}
		function redirect($url){
			echo "<script>location.replace('".$url."');</script>";
			exit;
		}
		function sendmail($to,$from,$subject,$message){
			
			$headers = "From: " . strip_tags($from) . "\r\n";
			$headers .= "Reply-To: ". strip_tags($from) . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";		
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";	
			
			$messages = '<html><body>';
			$messages .= $message;
			$messages .= '</body></html>';
			
			return mail($to, $subject, $message, $headers);
		}
		function time_elapsed_string($ptime)
		{
			$etime = time() - $ptime;	
			if ($etime < 1)
			{
				return '0 seconds';
			}
			
			$a = array( 365 * 24 * 60 * 60  =>  'year',
			30 * 24 * 60 * 60  =>  'month',
			24 * 60 * 60  =>  'day',
			60 * 60  =>  'hour',
			60  =>  'minute',
			1  =>  'second'
			);
			$a_plural = array( 'year'   => 'years',
			'month'  => 'months',
			'day'    => 'days',
			'hour'   => 'hours',
			'minute' => 'minutes',
			'second' => 'seconds'
			);
			
			foreach ($a as $secs => $str)
			{
				$d = $etime / $secs;
				if ($d >= 1)
				{
					$r = round($d);
					return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
				}
			}
		}
		
		function get_login_details($id)
		{
			global $db;
			$select="select * from login_and_user_details where id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		function get_cerdit_details($id)
		{global $db;
			$select="select * from credit_limit where buyer_id='".$id."'";
			$data=$db->get_row($select);
			return $data;
		}
		
		
		
		
		
		function encryptIt( $q ) {
			$cryptKey  = 'qJB0rGtIn5UB1xG03efyCpdasdasdsad3r2423';
			$qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
			return( $qEncoded );
		}
		
		function decryptIt( $q ) {
			$cryptKey  = 'qJB0rGtIn5UB1xG03efyCpdasdasdsad3r2423';
			$qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
			return( $qDecoded );
		}
		
	}
	$general = new general();
	
	
?>