<?php
	require_once(dirname(__FILE__).'/class.db.php');
	define("SITE_URL","http://happyjourneybags.com/orderpro/owner");
	define("SITE_NAME","Happy Journey bags");
	define("DB_HOST","localhost" );
	define("DB_USER","bagshapp_orderp" );
	define("DB_PASS","S*2Qlu*Jz@IC" );
	define("DB_NAME","bagshapp_orderprodata");
	define("SEND_ERRORS_TO","priyap0408@gmail.com" );
	define("DISPLAY_DEBUG", false );
	$db = new DB();
	date_default_timezone_set('Asia/Kolkata');
	$con=mysqli_connect("localhost", "root", "", "bagshapp_orderprodata");
?>