<?php 
if(!isset($_SESSION['auserid']) || $_SESSION['auserid']=="") 
{
	 header("Location:login.php");
}?>