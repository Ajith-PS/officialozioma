<?php
error_reporting(0);
$connection = mysqli_connect('localhost:3306', 'bagshapp_orderprodata', 'A&918CmB,CCtD[1495');
if (!$connection){
    die("Database Connection Failed" . mysql_error());
}
$select_db = mysqli_select_db('bagshapp_orderprodata');
if (!$select_db){
    die("Database Selection Failed" . mysql_error());
}