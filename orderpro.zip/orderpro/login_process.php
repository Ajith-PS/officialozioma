<?php
ob_start();
session_start();
require_once("connect.php");

if(isset($_POST['user'])){
	
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	
	
	$user = stripslashes($user);
	$pass = stripslashes($pass);
	$user = mysql_real_escape_string($user);
	$pass = mysql_real_escape_string($pass);
	
	$qry="select * from staff where password='$pass' AND username='$user'";
	$query = mysql_query($qry) or die($qry);
	
	$rows = mysql_num_rows($query);
	
	$rol="";
	if ($rows == 1) {
	while($rows=mysql_fetch_array($query))
	{
		//echo $rows['role'];
		$_SESSION['type']=$rows['type'];
		$_SESSION['distid']=$rows['districtid'];
		$_SESSION['login_user']=$rows['staffname'];; 
		
	}
	
	
	echo $_SESSION['type'];
	
	} else {
	
	echo $_SESSION['type'];
	}
	

}

?>