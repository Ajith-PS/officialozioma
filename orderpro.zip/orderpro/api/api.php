<?php
	session_start();
	error_reporting(0);
	include("../includes/config.php");
	include("../includes/functions.php");
	//session_start();
	$response = array();
	
	
	//add_discount
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_discount')
	{			
		for($i = 0 ; $i < sizeof($_REQUEST['idlist']); $i++)
		{
			$credit_limit = $db->get_row("SELECT * from credit_limit WHERE buyer_id='".$_REQUEST['sessionid'][$i]."'");
				
			$credit_initial = $credit_limit['credit_initial'];
			$credit_utilized = $credit_limit['credit_utilized'];
			$credit_balance = $credit_limit['credit_balance'];
			
			$orders = $db->get_row("SELECT * from orders WHERE id='".$db->escape($_REQUEST['idlist'][$i])."'");
			$prod_sub_total = (int)$orders['prod_sub_total'];
			$newdiscount = (float)$_REQUEST['discountlist'][$i];
			if($orders['discount'] == '')
			{
				$olddiscount = 0;
			}
			else
			{
				$olddiscount = (int)$orders['discount'];
			}
			if($olddiscount == 0)
			{
				$caldiscount = ($prod_sub_total * $newdiscount)/100;
				$credit_utilized_val = $credit_utilized - $caldiscount;
				$credit_balance_val = $credit_balance + $caldiscount;
			}
			else
			{				
				if($olddiscount > $newdiscount)
				{
					$oldcaldiscount = ($prod_sub_total * $olddiscount)/100;
					$newcaldiscount = ($prod_sub_total * $newdiscount)/100;
					$caldiscount = $oldcaldiscount - $newcaldiscount;
					$credit_utilized_val = $credit_utilized + $caldiscount;
					$credit_balance_val = $credit_balance - $caldiscount;
				}
				else if($olddiscount < $newdiscount)
				{
					$oldcaldiscount = ($prod_sub_total * $olddiscount)/100;
					$newcaldiscount = ($prod_sub_total * $newdiscount)/100;
					$caldiscount = $newcaldiscount - $oldcaldiscount;
					$credit_utilized_val = $credit_utilized - $caldiscount;
					$credit_balance_val = $credit_balance + $caldiscount;
				}
				else
				{
					$credit_utilized_val = $credit_utilized;
					$credit_balance_val = $credit_balance;
				}
			}
			//echo $credit_utilized_val;
			//echo "update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."' where buyer_id='".$_SESSION['auserid']."'";
			$result1 = $db->query("update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."' where buyer_id='".$_REQUEST['sessionid'][$i]."'")  or die(mysql_error());
			
			$query = "UPDATE orders SET discount='".$db->escape($_REQUEST['discountlist'][$i])."' where id='".$db->escape($_REQUEST['idlist'][$i])."' ";
			$result = $db->query($query);
			if($result)
			{
				$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$_REQUEST['sessionid'][$i]."'");
				$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='order for', user_id='".$db->escape($_REQUEST['sessionid'][$i])."', message='offered discount on ', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
				$db->query($query1);
			}
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//conform_cancalled
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_cancalled')
	{			
		$query = "UPDATE orders SET status ='Cancelled' where order_id='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM orders where order_id='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='order', user_id='".$db->escape($order_info['buyer_id'])."', message='cancelled', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	//conform_order
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_order')
	{			
		$query = "UPDATE orders SET status ='Confirmed' where order_id='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM orders where order_id='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='order', user_id='".$db->escape($order_info['buyer_id'])."', message='conformed', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//conform_DISPATCHED
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_DISPATCHED')
	{			
		$query = "UPDATE orders SET status ='Dispatched' where order_id='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM orders where order_id='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='order', user_id='".$db->escape($order_info['buyer_id'])."', message='dispatched', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//conform_deliver
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_deliver')
	{			
		$query = "UPDATE orders SET status ='Delivered' where order_id='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM orders where order_id='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='order', user_id='".$db->escape($order_info['buyer_id'])."', message='delivered', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//update_raw
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='update_raw')
	{			
		$query = "UPDATE raw_material SET qty ='".$db->escape($_REQUEST['qty'])."',
				colors = '".$db->escape($_REQUEST['colors'])."',
				size = '".$db->escape($_REQUEST['size'])."'
			where ID='".$db->escape($_REQUEST['id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($_REQUEST['mname'])."', role='raw material', user_id='".$db->escape($_REQUEST['id'])."', message='updated', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//re_order
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='re_order')
	{			
		$query = "SELECT * FROM orders where order_id='".$db->escape($_REQUEST['order_id'])."' ";
		$buyer = $db->get_row($query);
		$credit_limit = $db->get_row("SELECT * from credit_limit WHERE buyer_id='".$buyer['buyer_id']."'");
				
		$credit_initial = $credit_limit['credit_initial'];
		$credit_utilized = $credit_limit['credit_utilized'];
		$credit_balance = $credit_limit['credit_balance'];
		$totalval = (int)$_REQUEST['gtotal'];
		if($credit_balance >= $totalval)
		{
			$credit_balance_val = $credit_balance - $totalval;
			$credit_utilized_val = $credit_utilized + $totalval;
			$db->query("update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."' where buyer_id='".$buyer['buyer_id']."'")  or die(mysql_error());	
			
			$rows = $db->get_results($query);
			$order_id = mt_rand(100000, 999999);
			foreach($rows as $row) 
			{ 
				$query1 = "INSERT INTO orders SET order_id='".$db->escape($order_id)."',
					buyer_id='".$db->escape($row['buyer_id'])."',
					product_id='".$db->escape($row['product_id'])."',			
					product_name='".$db->escape($row['product_name'])."',
					qty='".$db->escape($row['qty'])."',
					size='".$db->escape($row['size'])."',
					color='".$db->escape($row['color'])."',
					unit='".$db->escape($row['unit'])."',
					unit_Price='".$db->escape($row['unit_Price'])."',
					gst='".$db->escape($row['gst'])."',
					prod_sub_total='".$db->escape($row['prod_sub_total'])."',
					status = 'Ordered'";
				$insert = $db->query($query1) or die(mysql_error());
				$user_id = $db->lastid();
				$query2 = "INSERT INTO Log_details SET full_name='".$db->escape($row['product_name'])."', role='Product', user_id='".$db->escape($user_id)."', message='added', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
				$insert1 = $db->query($query2) or die(mysql_error());
			}
			if($insert1)
				echo "2";
			else
			{ echo "3";
			}
		}
		else{
			echo "1";
		}
	}
	
	
	//conform_discuss
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_discuss')
	{			
		$query = "UPDATE payments SET Status ='Need to discuss' where payment_id='".$db->escape($_REQUEST['id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM payments where payment_id='".$db->escape($_REQUEST['id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['Dis_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='payment status need to discuss for', user_id='".$db->escape($_REQUEST['id'])."', message='updated', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//conform_delete
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_delete')
	{			
		$order_info = $db->get_row("SELECT * FROM payments where payment_id='".$db->escape($_REQUEST['id'])."' limit 0,1 ");
		$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['Dis_id']."'");
		$query = "DELETE FROM payments where payment_id='".$db->escape($_REQUEST['id'])."' ";
		$result = $db->query($query);
		if($result)
		{			
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='payment of', user_id='".$db->escape($_REQUEST['id'])."', message='deleted', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	//conform_payment
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_payment')
	{	
		$credit_limit = $db->get_row("SELECT * FROM credit_limit where buyer_id = '".$_REQUEST['buyer_id']."'");
		$credit_initial = $credit_limit['credit_initial'];
		$credit_utilized = $credit_limit['credit_utilized'];
		$credit_balance = $credit_limit['credit_balance'];
		
		$payment_info = $db->get_row("SELECT * FROM payments where Dis_id = '".$_REQUEST['buyer_id']."' and payment_id = '".$_REQUEST['payment_id']."'");
		$amount = $payment_info['amount'];
		
		if($credit_utilized >= $amount)
		{
			$credit_balance_val  = $credit_balance + $amount;
			$credit_utilized_val = $credit_utilized - $amount;
			$credit_initial_val = $credit_initial;
		}
		else
		{
			$extra = $amount - $credit_utilized;
			$credit_utilized_val = 0;
			$credit_initial_val = $credit_initial + $extra;
			$credit_balance_val = $credit_initial_val;
		}
		$db->query("update credit_limit SET  credit_utilized='".$credit_utilized_val."', credit_balance='".$credit_balance_val."', credit_initial = '".$credit_initial_val."' where buyer_id='".$_REQUEST['buyer_id']."'")  or die(mysql_error());	
		
		$query = "UPDATE payments SET Status ='Confirmed' where payment_id='".$_REQUEST['payment_id']."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM payments where payment_id='".$db->escape($_REQUEST['payment_id'])."' limit 0,1 ");
			$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['Dis_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($buyer_info['name_concerned_person'])."', role='payment', user_id='".$db->escape($_REQUEST['payment_id'])."', message='confirmed', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	//conform_material
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='conform_material')
	{			
		$query = "UPDATE raw_material SET status ='Confirmed' where ID='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM raw_material where ID='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			//$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($order_info['material_name'])."', role='raw material', user_id='".$db->escape($order_info['user_id'])."', message='confirmed', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//update_material
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='update_material')
	{			
		$query = "UPDATE raw_material SET qty ='".$db->escape($_REQUEST['qty'])."' where ID='".$db->escape($_REQUEST['order_id'])."' ";
		$result = $db->query($query);
		if($result)
		{
			$order_info = $db->get_row("SELECT * FROM raw_material where ID='".$db->escape($_REQUEST['order_id'])."' limit 0,1 ");
			//$buyer_info = $db->get_row("SELECT * from buyer_details WHERE buyer_id='".$order_info['buyer_id']."'");
			$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($order_info['material_name'])."', role='raw material', user_id='".$db->escape($_REQUEST['order_id'])."', message='updated', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			$result1 = $db->query($query1);
		}
		if($result1)
			echo "2";
		else
		{ echo "3";
		}
	}
	
	
	//add_feedbach
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='addfeed'){	
		
			$query_feed = "UPDATE orders SET feedstatus = '1' where order_id = '".$db->escape($_REQUEST['orderid'])."'";
			$db->query($query_feed) ; 
			$query = "INSERT INTO feedback_details SET product_id='".$db->escape($_REQUEST['orderid'])."', feed_subject='".$db->escape($_REQUEST['subject'])."', feed_msg='".$db->escape($_REQUEST['message'])."' ";
			if($db->query($query))
			{
				$user = $db->get_row("SELECT * FROM login_and_user_details where id ='".$db->escape($_SESSION['auserid'])."'");
				$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($user['username'])."', role='feedback', user_id='".$db->escape($user['id'])."', message='added', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
				if($db->query($query1))
				echo "2";
			}
			else
			{ echo "3";
			}
	}
	
	
	//send_mail
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='send_mail'){	
		
			$get_mail = $db->get_row("SELECT * FROM  login_and_user_details where id = '".$_SESSION['auserid']."'");			
			$query = "INSERT INTO mail_info SET login_id='".$db->escape($_SESSION['auserid'])."', frommail='".$db->escape($get_mail['email'])."', tomail='".$db->escape($_REQUEST['toemail'])."', subjects='".$db->escape($_REQUEST['subject'])."', message='".$db->escape($_REQUEST['message'])."', replystatus='0', readstatus = '0', dateandtime = NOW() ";
			$user_id = $db->lastid();
			if($db->query($query))
			{				
				$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($_REQUEST['toemail'])."', role='mail to', user_id='".$db->escape($user_id)."', message='sent', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
				if($db->query($query1))
				echo "2";
			}
			else
			{ echo "3";
			}
	}
	
	
	//reply_mail
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='reply_mail'){	
		
			$get_mail = $db->get_row("SELECT * FROM  login_and_user_details where id = '".$_SESSION['auserid']."'");
			if($_REQUEST['toemail'] == $get_mail['email'])
				$tomail = $_REQUEST['fromemail'];
			else
				$tomail = $_REQUEST['toemail'];
			$query = "INSERT INTO mail_info SET login_id='".$db->escape($_SESSION['auserid'])."', frommail='".$db->escape($get_mail['email'])."', tomail='".$db->escape($tomail)."', subjects='".$db->escape($_REQUEST['subject'])."', message='".$db->escape($_REQUEST['message'])."', replyorder = '".$db->escape($_REQUEST['mailid'])."',replystatus='0', readstatus = '0' , dateandtime = NOW()";
			$db->query("UPDATE mail_info SET replystatus='1' where id='".$_REQUEST['mailid']."'");
			if($db->query($query))
			{	
				$user_id = $db->lastid();
				$query1 = "INSERT INTO Log_details  SET full_name='".$db->escape($_REQUEST['toemail'])."', role='mail to', user_id='".$db->escape($user_id)."', message='replied', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
				if($db->query($query1))
				echo "2";
			}
			else
			{ echo "3";
			}
	}
	
	//check_distributorid
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check'){	
		if(!strlen(trim($db->escape($_REQUEST['distributorid']))))echo  "1";
		else
		{
			$query = "SELECT * FROM distributor_details WHERE Dis_id='".$db->escape($_REQUEST['distributorid'])."'";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	//check_username
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_username'){	
		if(!strlen(trim($db->escape($_REQUEST['username']))))echo  "1";
		else
		{
			$query = "SELECT * FROM distributor WHERE username='".$db->escape($_REQUEST['username'])."'";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	
	//check_Updateusername
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_Updateusername'){	
		if(!strlen(trim($db->escape($_REQUEST['username']))))echo  "1";
		else
		{
			$query = "SELECT * FROM distributor WHERE username='".$db->escape($_REQUEST['username'])."' and Dis_id='".$db->escape($_REQUEST['Dis_id'])."' ";
			if($db->num_rows($query)){ echo "3";}
			else
			{
				$query = "SELECT * FROM distributor WHERE username='".$db->escape($_REQUEST['username'])."'";
				if($db->num_rows($query)) echo "2" ;
				else
				{
					
					echo "3";
				}
			}
		}
		
	}
	//check_email
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_email'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_email1']))))echo  "1";
		else if(!filter_var($_REQUEST['check_email1'], FILTER_VALIDATE_EMAIL)) echo "4";
		
		else
		{
			$query = "SELECT * FROM distributor WHERE email='".$db->escape($_REQUEST['check_email1'])."'";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	//check_buyer_email
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_buyer_email'){
		
		if(filter_var($_REQUEST['check_email1'], FILTER_VALIDATE_EMAIL)  === false) echo "4";
		else
		{
			$query = "";
			if($_REQUEST['getid'] == "")
			{
				$query = "SELECT * FROM buyer_details WHERE email_id='".$db->escape($_REQUEST['check_email1'])."'";
			}
			else
			{
				$query = "SELECT * FROM buyer_details WHERE email_id='".$db->escape($_REQUEST['check_email1'])."' and buyer_id <> '".$db->escape($_REQUEST['getid'])."'";
			}
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	
	//check_supplier_email
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_supplier_email'){
		
		if(filter_var($_REQUEST['check_email1'], FILTER_VALIDATE_EMAIL)  === false) echo "4";
		else
		{
			$query = "";
			if($_REQUEST['getid'] == "")
			{
				$query = "SELECT * FROM supplier_details WHERE email='".$db->escape($_REQUEST['check_email1'])."'";
			}
			else
			{
				$query = "SELECT * FROM supplier_details WHERE email='".$db->escape($_REQUEST['check_email1'])."' and supplier_id <> '".$db->escape($_REQUEST['getid'])."'";
			}
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	
	//check_user_email
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_user_email'){
		
		if(filter_var($_REQUEST['check_email1'], FILTER_VALIDATE_EMAIL)  === false) echo "4";
		else
		{
			$query = "";
			if($_REQUEST['getid'] == "")
			{
				$query = "SELECT * FROM login_and_user_details WHERE email='".$db->escape($_REQUEST['check_email1'])."'";
			}
			else
			{
				$query = "SELECT * FROM login_and_user_details WHERE email='".$db->escape($_REQUEST['check_email1'])."' and id <> '".$db->escape($_REQUEST['getid'])."'";
			}
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	//check_email_update
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_email_update'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_email1']))))echo  "1";
		else if(!filter_var($_REQUEST['check_email1'], FILTER_VALIDATE_EMAIL)) echo "4";
		
		else
		{
			$query = "SELECT * FROM distributor WHERE email='".$db->escape($_REQUEST['check_email1'])."' and Dis_id='".$db->escape($_REQUEST['Dis_id'])."'";
			if($db->num_rows($query)) echo "3";
			else
			{
				
				$query = "SELECT * FROM distributor WHERE email='".$db->escape($_REQUEST['check_email1'])."'";
				if($db->num_rows($query)) echo "2";
				else
				{ 
					echo "3";
				}
			}
			
		}
		
	}
	//add_Prod
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_Prod'){
		
		
		if($db->query("INSERT INTO products SET Manufacturer_name='".$db->escape($_REQUEST['add_manufact_name'])."', product_name='".$db->escape($_REQUEST['add_prod_name'])."', weight='".$db->escape($_REQUEST['add_weight'])."', measurement_unit='".$db->escape($_REQUEST['category'])."', rate_per_unit='".$db->escape($_REQUEST['add_rate_per_unit'])."', package_type='".$db->escape($_REQUEST['package_type_'])."', special_discount='".$db->escape($_REQUEST['add_special_discount'])."', discount_expiry_date='".$db->escape($_REQUEST['add_discount_expiry_date'])."'"))
		{
			echo "Record Added Successfully";
		}
		
		else{
			echo "Record Not added please contact admin for more support";
		}
		//$user_id = $db->lastid();
		
	}
	
	
	
	//add_transportationcity
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_transportationcity'){
		
		
		if($db->query("INSERT INTO transportcity SET transportationcity_text='".$db->escape($_REQUEST['add_prod_name__'])."', transportationcity_val='".$db->escape($_REQUEST['add_prod_name__'])."', transportationcity_cost='".$db->escape($_REQUEST['add_manufact_name__'])."'"))
		{
			echo "Record Added Successfully";
		}
		
		else{
			echo "Record Not added please contact admin for more support";
		}
		//$user_id = $db->lastid();
		
	}
	
	//add_transportationcity_cost
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_transportationcity_cost'){
		
		for($i=0; $i<count($_REQUEST['add_weight']); $i++){
			
			if($db->query("INSERT INTO transport_cost_per_city SET  product_id='".$db->escape($_REQUEST['add_weight'][$i])."',  city_id='".$db->escape($_REQUEST['add_prod_name'])."', tr_cost_per_unit='".$db->escape($_REQUEST['add_manufact_name'])."'"))
			{
				$Status = "Record Added Successfully";
			}
			
			else
			{
				$Status =  "Record Not added please contact admin for more support";
			}
			
			//$user_id = $db->lastid();
		}
		echo $Status;
	}
	//update_transportationcity_cost
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='update_transportationcity_cost'){
		
		if($db->query("UPDATE transport_cost_per_city SET tr_cost_per_unit='".$db->escape($_REQUEST['add_manufact_name'])."' WHERE id='".$db->escape($_REQUEST['transport_cost_per_city_id'])."'"))
		{
			
			
			
			echo 'Price updated successfully';
		}
		else
		{
			
			echo 	'Contact admin Price not updated';
		}
		//$user_id = $db->lastid();
		
	}
	//add_vatstate
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_vatstate'){
		
		
		if($db->query("INSERT INTO vat_category SET vat_category_text='".$db->escape($_REQUEST['add_prod_name'])."', vat_category_value='".$db->escape($_REQUEST['add_prod_name'])."', vat_category_cost='".$db->escape($_REQUEST['add_manufact_name'])."'"))
		{
			echo "Record Added Successfully";
		}
		
		else{
			echo "Record Not added please contact admin for more support";
		}
		//$user_id = $db->lastid();
		
	}
	//prod_Update
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='prod_Update'){
		
		
		$query="select * from products where product_id='".$db->escape($_REQUEST['productname'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			$response['product_name']=$row['product_name'];
			$response['Manufacturername']=$row['Manufacturer_name'];
			$response['weight']=$row['weight'];
			$response['unit']=$row['measurement_unit'];
			$response['rate']=$row['rate_per_unit'];
			$response['package_type']=$row['package_type'];
			$response['special_discount']=$row['special_discount'];
			$response['discount_expiry_date']=$row['discount_expiry_date'];
			$response['id_update']=$db->escape($_REQUEST['productname']);
			
		}
		else{
			$response['message']='no records found';
			$response['status']='fail';
		}
		
		
		echo json_encode($response);
		
	}
	
	
	//transportcity_Update_ (Get info)
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='transportcity_Update'){
		
		
		$query="select * from transportcity where id='".$db->escape($_REQUEST['transportid'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			$response['product_name']=$row['transportationcity_text'];
			$response['Manufacturername']=$row['transportationcity_cost'];
			$response['id_update']=$db->escape($_REQUEST['transportid']);
		}
		else{
			$response['message']='no records found';
			$response['status']='fail';
		}
		
		
		echo json_encode($response);
		
	}
	//vatcat_Update (Get info)
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='vatcat_Update'){
		
		
		$query="select * from vat_category where id='".$db->escape($_REQUEST['transportid'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			$response['product_name']=$row['vat_category_text'];
			$response['Manufacturername']=$row['vat_category_cost'];
			$response['id_update']=$db->escape($_REQUEST['transportid']);
		}
		else{
			$response['message']='no records found';
			$response['status']='fail';
		}
		
		
		echo json_encode($response);
		
	}
	//prod_details
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='prod_details'){
		
		
		$query="select * from products where product_id='".$db->escape($_REQUEST['productname'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			$response['Manufacturername']=$row['Manufacturer_name'];
			$response['weight']=$row['weight'];
			$response['unit']=$row['measurement_unit'];
			$response['rate']=$row['rate_per_unit'];
			$response['packagetype']=$row['package_type'];
			$response['productcode']=$row['product_code'];
			$response['gst']=$row['gst'];
			$response['size']=$row['size'];
			$response['colors']=$row['colors'];
			
		}
		else{
			$response['message']='no records found';
			$response['status']='fail';
		}
		
		
		echo json_encode($response);
		
	}
	
	//get_mlist
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='get_mlist'){
		
		
		$query="select * from material_mst where category='".$db->escape($_REQUEST['category'])."' and ID = '".$db->escape($_REQUEST['id'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			//$response['Manufacturername']=$row['Manufacturer_name'];
			//$response['weight']=$row['weight'];
			$response['unit']=$row['measurement_unit'];
			//$response['rate']=$row['rate_per_unit'];
			$response['threshold']=$row['threshold'];
			//$response['productcode']=$row['product_code'];
			//$response['gst']=$row['gst'];
			$response['size']=$row['size'];
			$response['colors']=$row['colors'];
			
		}
		else{
			$response['message']='no records found';
			$response['status']='fail';
		}
		
		
		echo json_encode($response);
		
	}
	//add_prod
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='add_Purchaseorder'){
		echo $_REQUEST['quantity_hidden'];
		
		// foreach($_REQUEST as $fetchresult) {
		
		
		// $query="select * from products where product_id='".$db->escape($fetchresult['Prod_name_hidden'])."'";
		// $num= $db->num_rows($query);		  
		// if($num)
		// {
		// $row= $db->get_row($query);
		// $response['Manufacturername']=$row['Manufacturer_name'];
		// $response['weight']=$row['weight'];
		// $response['unit']=$row['measurement_unit'];
		// $response['rate']=$row['rate_per_unit'];
		// $response['packagetype']=$row['package_type'];
		
		// }
		// else{
		// $response['message']='no records found';
		// $response['status']='fail';
		// }
		
		
		// }
		// $response1['status']="das";
		//echo json_encode($response1);
	}
	//UpdateProd
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='UpdateProd'){
		if($db->query("UPDATE products SET product_name='".$db->escape($_REQUEST['Update_prod_name'])."', Manufacturer_name='".$db->escape($_REQUEST['Update_manufact_name'])."', weight='".$db->escape($_REQUEST['Update_weight'])."', measurement_unit='".$db->escape($_REQUEST['Updatecategory'])."', rate_per_unit='".$db->escape($_REQUEST['Update_rate_per_unit'])."', package_type='".$db->escape($_REQUEST['Updatepackage_type_'])."' , special_discount='".$db->escape($_REQUEST['Update_special_discount'])."', discount_expiry_date='".$db->escape($_REQUEST['Update_discount_expiry_date'])."' WHERE product_id='".$db->escape($_REQUEST['id_update'])."'"))
		{
			
			
			
			echo 'Product updated successfully';
		}
		else
		{
			
			echo 	'Contact admin Porduct not updated';
		}
		
	}
	//update_trCity
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='update_trCity'){
		if($db->query("UPDATE transportcity SET transportationcity_text='".$db->escape($_REQUEST['Update_prod_name'])."',transportationcity_cost='".$db->escape($_REQUEST['Update_manufact_name'])."' where id ='".$db->escape($_REQUEST['id_update'])."'"))
		{
			
			
			
			echo 'Data updated successfully';
		}
		else
		{
			
			echo 	'Contact admin Porduct not updated';
		}
		
	}
	//Update_GST_Excise
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='Update_GST_Excise'){
		if($db->query("UPDATE excise_gst SET GST='".$db->escape($_REQUEST['Gst'])."',excise='".$db->escape($_REQUEST['update_Excise'])."' where id ='1'"))
		{
			
			
			
			echo 'Data updated successfully';
		}
		else
		{
			
			echo 'Contact admin value not updated';
		}
		
	}
	
	
	//update_vat
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='update_vat'){
		if($db->query("UPDATE vat_category SET vat_category_text='".$db->escape($_REQUEST['Update_prod_name'])."', vat_category_cost='".$db->escape($_REQUEST['Update_manufact_name'])."' where id ='".$db->escape($_REQUEST['id_update'])."'"))
		{
			
			
			
			echo 'Data updated successfully';
		}
		else
		{
			
			echo 	'Contact admin Porduct not updated';
		}
		
	}
	
	//check_VAT_No
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_VAT_No'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_vatno']))))echo  "1";
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE vat='".$db->escape($_REQUEST['check_vatno'])."'";
			$num= $db->num_rows($query);
			if($num) 
			
			{
				echo "2";
			}
			else
			{ echo "3";
			}
		}
		
	}
	
	
	//check_VAT_No_update
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_VAT_No_update'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_vat_no']))))echo  "1";
		
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE vat='".$db->escape($_REQUEST['check_vat_no'])."' and Dis_id='".$db->escape($_REQUEST['Dis_id'])."'";
			if($db->num_rows($query)) echo "3";
			else
			{
				
				$query = "SELECT * FROM distributor_details WHERE vat='".$db->escape($_REQUEST['check_vat_no'])."'";
				if($db->num_rows($query)) echo "2";
				else
				{ 
					echo "3";
				}
			}
			
		}
		
	}
	
	
	//check_CST_No
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_CST_No'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_cstno']))))echo  "1";
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE cst='".$db->escape($_REQUEST['check_cstno'])."'";
			$num= $db->num_rows($query);
			if($num) 
			
			{
				echo "2";
			}
			else
			{ echo "3";
			}
		}
		
	}
	//Add_payment_admin
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='Add_payment_admin'){
		
		
		if($db->query("INSERT INTO payments SET Dis_id='".$db->escape($_REQUEST['dis_id'])."', payment_date='".$db->escape($_REQUEST['add_pay_date'])."', cheque_no='".$db->escape($_REQUEST['add_pay_cheque_no'])."', RTGS_no='".$db->escape($_REQUEST['add_pay_rtgs_no'])."', amount='".$db->escape($_REQUEST['add_pay_amount'])."', drawn_on_bank='".$db->escape($_REQUEST['add_pay_drawn_on_bank'])."', ref_purchase_order_no='".$db->escape($_REQUEST['Order_Number'])."', Status='Submitted', payment_date_time=NOW()"))
		{
			$user_id = $db->lastid();
			$query = "INSERT INTO Log_details  SET full_name='".$db->escape($_REQUEST['add_pay_amount'])."', role='payment of amount', user_id='".$db->escape($user_id)."', message='added', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			if($db->query($query))
				echo "Record Added Successfully";
		}
		
		else{
			echo "Record Not added please contact admin for more support";
		}
		
	}
	//check_tax
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_tax'){global $db,$general;	
		$k = 0;
		$m = 0;
		$id = $_SESSION['Dis_id'];
		foreach($data['measurementunit_hidden'] as $measurementunit) {	
			$measurementunitval= $measurementunit;
			//discount_expiry_date
			
			
			
			
			
			
			$Get_product_info = $db->get_row("SELECT * from products where product_name='".$data['Prod_name_hidden'][$k]."'");
			
			$Store_date=strtotime($Get_product_info['discount_expiry_date']);
			$curdate=date("m/d/Y");
			
			if ($Store_date >= $curdate){
				$amount = $Get_product_info["special_discount"];
				$Sub_total_Price = $data['rate_per_uni_hidden'][$k];
				
				$percentage_int =  intval($amount);  
				$Sub_total_Price_int = intval($Sub_total_Price);
				
				$New_discount_percent[$k] = ($percentage_int / 100) * $Sub_total_Price_int;
				
				
				//$newprice = $Sub_total_Price - $New_discount_percent;
				
				
				
			}
			else
			{
				
			}
			
			$k++;
		}
		if (isset($New_discount_percent)) {
			
			
			$Discount_amount =	array_sum($New_discount_percent);
		}
		else
		{
			$Discount_amount = intval(0);
		}
		
		$distributor_details = $db->get_row("SELECT * from distributor_details WHERE Dis_id='".$id."'");
		$credit_limit = $db->get_row("SELECT * from credit_limit WHERE dis_id='".$id."'");
		$excise_and_gst = $db->get_row("SELECT * from excise_gst");
		$transportcity = $db->get_row("SELECT * from transportcity where transportationcity_val ='".$distributor_details['transportation_city']."'");
		$vat_category = $db->get_row("SELECT * from vat_category where vat_category_value='".$distributor_details['vat_category']."'");
		$transportcity_id=$transportcity['id'];
		
		foreach($data['measurementunit_hidden'] as $measurementunit) {	
			$measurementunitval= $measurementunit;
			//discount_expiry_date
			//	echo "<script>alert(".$transportcity_id.");</script>";
			//echo "<script>alert(".$data['Prod_id_hidden'][$m].");</script>";
			
			$Get_Transport_cost = $db->get_row("SELECT * from transport_cost_per_city where product_id='".$data['Prod_id_hidden'][$m]."' and city_id='".$transportcity_id."'");
			
			$each_prod_Tr_cost = $Get_Transport_cost['tr_cost_per_unit'];
			
			$price_forprod[$m] = $each_prod_Tr_cost * $data['quantity_hidden'][$m];
			//echo "<script>alert(".$price_forprod[$m].");</script>";
			$m++;
		}
		
		
		
		
		if (isset($final_transport_cost)) {
			$final_transport_cost =	array_sum($price_forprod);
		}
		else
		{
			$final_transport_cost = intval(0);
		}
		
		
		$Company_Name=$distributor_details['company_name'];
		$credit_initial = $credit_limit['credit_initial'];
		$credit_utilized = $credit_limit['credit_utilized'];
		$credit_balance = $credit_limit['credit_balance'];
		$GST = $excise_and_gst['GST'];
		$excise = $excise_and_gst['excise'];
		$vat_category_cost = $vat_category['vat_category_cost'];
		for($i=0; $i<count($_REQUEST['rate_per_uni_hidden']); $i++){
			
			$totalval =	array_sum($_REQUEST['rate_per_uni_hidden']);
		}
		
		
		//	(int)str_replace(' ', '', $excise);
		
		$percentage =  $excise;  
		$cash_for_cash_payment = (1 / 100) * $totalval;
		if($db->escape($data['payment_terms']) =="Cash")
		
		{
			$cash_and_product_discount= $cash_for_cash_payment + $Discount_amount;	
		}
		else
		{
			$cash_and_product_discount=  $Discount_amount;	
		}
		
		
		
		$total_value = intval($totalval) - intval($cash_and_product_discount);
		
		$Excise_amount = ($percentage / 100) * $total_value;
		$GST_percentage =  $GST;  
		//	$GST_total_value = intval($totalval) - intval($Discount_amount);
		
		$GST__amount = ($GST_percentage / 100) * $totalval;
		
		$Sale_tax_percentage = $vat_category_cost;  
		$VAT = $total_value + $Excise_amount;
		$Sale_tax_percentage_value = ($Sale_tax_percentage / 100) * $VAT;
		
		$Grand_total = $total_value + $Excise_amount + $Sale_tax_percentage_value + $final_transport_cost + $GST__amount;
		$credit_balance_val = $credit_balance - $total_value;
		$credit_utilized_val = $credit_utilized + $total_value;
		if($db->escape($data['payment_terms']) =="Cash")
		
		{
			
		}
		else
		{
			
		}
		if($db->escape($data['payment_terms']) =="Cash")
		
		{
			
		}
		else
		{
			if($Grand_total > $credit_balance)
			{
				echo "Yes";
			}
			else if($Grand_total <= $credit_balance)
			{
				echo "2";
			}
		}
		
		
		
		
		
		
		
	}
	
	//Add_payment
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='Add_payment'){
		
		//, ref_purchase_order_no='".$db->escape($_REQUEST['Order_Number'])."',
		if($db->query("INSERT INTO payments SET Dis_id='".$_SESSION['auserid']."', payment_date='".$db->escape($_REQUEST['add_pay_date'])."', cheque_no='".$db->escape($_REQUEST['add_pay_cheque_no'])."', RTGS_no='".$db->escape($_REQUEST['add_pay_rtgs_no'])."', amount='".$db->escape($_REQUEST['add_pay_amount'])."', drawn_on_bank='".$db->escape($_REQUEST['add_pay_drawn_on_bank'])."', Status='Submitted', payment_date_time=NOW()"))
		{
			//$user_row = $d->get_row("Select * from login_and_user_details where id='".$_SESSION['auserid']."'");
			$user_id = $db->lastid();
			$query = "INSERT INTO Log_details  SET full_name='".$db->escape($_REQUEST['add_pay_amount'])."', role='payment of amount', user_id='".$db->escape($user_id)."', message='added', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			if($db->query($query))
			echo "2";
		}
		
		else{
			echo "3";
		}
		
	}
	// //Add_payment
	// if(isset($_REQUEST['action']) && $_REQUEST['action']=='Add_payment'){
	
	
	
	
	
	// $query = "SELECT * FROM purchase_orders WHERE ref_purchase_order_no='".$db->escape($_REQUEST['Order_Number'])."' or ref_purchase_order_no='".$db->escape($_REQUEST['add_pay_refference_purchase_order_noalert'])."'";
	// $num= $db->num_rows($query);
	// if($num) 
	
	// {
	// $row= $db->get_row($query);
	// $Credit_Limit = $db->get_row("SELECT * FROM credit_limit WHERE dis_id='".$row['dis_id']."'");
	
	
	// if($_REQUEST['add_pay_amount'] >= $Credit_Limit["credit_utilized"])
	
	// {
	// echo "Greater then Credit Limit Utilize Check amount";
	// }
	// else
	// {
	
	// if($row['sub_total'] > grandtotal)
	
	// $sub_total_value = $row['sub_total'] - $row['Discount'];
	
	
	
	
	
	// $Current_amount_val =$db->escape($_REQUEST['add_pay_amount']);
	
	// $Credite_utlize_val =$Credit_Limit["credit_utilized"];
	// $Credite_utlize_val_calc =  round($Credite_utlize_val - $Current_amount_val);
	
	// $add_credite_utilize = $Credite_utlize_val - $Current_amount_val;
	
	
	// // $query = "update purchase_orders SET order_status='".$_GET['Status']."' where ref_purchase_order_no='".$_GET['PoNo']."' and dis_id='".$_GET['id']."'";
	// // $insert=$db->query($query)  or die(mysql_error());
	// // if($insert){
	// // $general->redirect('index.php?p=purchaseorderhistory&msg=3');
	// // }
	
	// //echo $Credit_Limit["credit_utilized"];
	// }
	
	// $row['sub_total'];
	// }
	
	// else
	// {
	// echo "Payment Not added";
	// }
	
	
	
	// }
	
	
	//check_cst_No_update
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_cst_No_update'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_cstno']))))echo  "1";
		
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE cst='".$db->escape($_REQUEST['check_cstno'])."' and Dis_id='".$db->escape($_REQUEST['Dis_id'])."'";
			if($db->num_rows($query)) echo "3";
			else
			{
				
				$query = "SELECT * FROM distributor_details WHERE cst='".$db->escape($_REQUEST['check_cstno'])."'";
				if($db->num_rows($query)) echo "2";
				else
				{ 
					echo "3";
				}
			}
			
		}
		
	}
	
	
	
	//check_pan_No
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_pan_No'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['check_panno']))))echo  "1";
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE pan='".$db->escape($_REQUEST['check_panno'])."'";
			$num= $db->num_rows($query);
			if($num) 
			
			{
				echo "2";
			}
			else
			{ echo "3";
			}
		}
		
	}
	
	//check_pan_No_update
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_pan_No_update'){
		
		
		if(!strlen(trim($db->escape($_REQUEST['panno']))))echo  "1";
		
		
		else
		{
			$query = "SELECT * FROM distributor_details WHERE pan='".$db->escape($_REQUEST['panno'])."' and Dis_id='".$db->escape($_REQUEST['Dis_id'])."'";
			if($db->num_rows($query)) echo "3";
			else
			{
				
				$query = "SELECT * FROM distributor_details WHERE pan='".$db->escape($_REQUEST['panno'])."'";
				if($db->num_rows($query)) echo "2";
				else
				{ 
					echo "3";
				}
			}
			
		}
		
	}
	
	//getproducts
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='getproducts'){
		$items = array();
		
		$query2 = "select * from transport_cost_per_city where city_id='".$db->escape($_REQUEST['id'])."'";
		
		$rows2 = $db->get_results($query2);
		foreach($rows2 as $row2) { 
			$items[] = $row2['product_id'];
			
		}
		
		$query_prod = "select * from products";
		
		$rows_prod = $db->get_results($query_prod);
		foreach($rows_prod as $row_prod) {
			
			echo '<option '; if (in_array($row_prod['product_id'],$items)) {echo 'disabled="disabled" ';} echo 'value = "'.$row_prod['product_id'].'">'.$row_prod['product_name'].'</option>';
			
			
			
		}
		
	}
	
	
	//check_product
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_product'){	
		if(!strlen(trim($db->escape($_REQUEST['product_code']))))echo  "1";
		else
		{
			$query = "";
			if($_REQUEST['getid'] == '')
			{
				$query = "SELECT * FROM products WHERE product_code='".$db->escape($_REQUEST['product_code'])."'";
			}
			else
			{
				$query = "SELECT * FROM products WHERE product_code='".$db->escape($_REQUEST['product_code'])."' and product_id<>'".$db->escape($_REQUEST['getid'])."' ";
			}
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	
	
	//check_material
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_material'){	
		if(!strlen(trim($db->escape($_REQUEST['mname']))))echo  "1";
		else
		{
			$query = "SELECT * FROM material_mst WHERE category='".$db->escape($_REQUEST['category'])."' and mname = '".$db->escape($_REQUEST['mname'])."' ";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
	}
	
	
	$file = 'people.txt';
	$current = file_get_contents($file);
	$current .= $_SERVER['REQUEST_URI']."-".date("Y-m-d H:i:s")."\n";//implode(",",$_REQUEST);
	file_put_contents($file, $current);
	//Output
	header('Content-Type: application/json');
	
	
	// json_encode($response);
	
	
	
	
	
	
	
	exit;
?>			
