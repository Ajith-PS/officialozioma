<?php
	session_start();
	error_reporting(0);
	include("../includes/config.php");
	include("../includes/functions.php");
	date_default_timezone_set('Asia/Kolkata');
	
	if(isset($_POST['action']) && $_POST['action']=='get_punching'){
	    $sddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['start']);
	    $stdate = $sddate->format('Y-m-d');
	    $eddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['end']);
	    $endate = $eddate->format('Y-m-d');
	    $query = "Select  * from usertable WHERE ustat = '1'";
	/*    $result = '<div class="col-lg-12"><strong align="center"><h2>HAPPY JOURNEY</h2></strong></div>
	    <div class="col-lg-12"><h3 align="center">SAFAR BUILDING,SOUTH KALAMASSERY,CHANGAMPUZHA NAGAR PO,KOCHI- 682033</h3></div>
	    <div class="col-lg-12"><h3 align="center">Ph: 04842110796,04842110796</h3></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div>*/
	    $result = '<div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-10"><h4 align="center">PUNCHING REPORT FROM '.date('d-M-Y', strtotime($stdate)).' TO '.date('d-M-Y', strtotime($endate)).'</h4></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h3>Date: '.date('d-M-Y').'</h3></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h3>Time: '.date('h:i a').'</h3></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div>';
	    //<table class="table table-striped table-bordered table-hover dataTables-example">';
	    $sdate = $stdate;
	    $edate = $endate;
	    if($_REQUEST['staff'] != 'All')
	    {
	        $query.= " and uid = '".$_REQUEST['staff']."'";
	    }
	    if($db->num_rows($query))
		{
			$rows = $db->get_results($query);
			foreach($rows as $row) 
			{
			    $result = $result.'<div class="col-lg-12"><h3>EMPLOYEE NAME : '.$row['staffname'].'</h3></div><br>';
			    $result = $result.'<table class="table table-striped table-bordered table-hover dataTables-example">
			             <tr style="background-color:#92959b;"><th>DATE</th>
			             <th>FROM TIME</th>
			             <th>LOCATION</th>
			             <th>END TIME</th>
			             <th>LOCATION</th>
			             <th>TIME SPEND</th>
			             <th>REMARKS</th></tr>';
			    $query1 = "SELECT *, TIMEDIFF(outtime,intime) as duration FROM punching WHERE sid = '".$row['uid']."' and adate >= '".$sdate."' and adate <= '".$edate."'";
				if($db->num_rows($query1))
        		{
        			$rows1 = $db->get_results($query1);
        			foreach($rows1 as $row1) 
        			{
        			    $result = $result.'<tr><td>'.date('d/M/Y', strtotime($row1['adate'])).'</td>
        			            <td>'.date('h:i a',strtotime($row1['intime'])).'</td>
        			            <td>'.$row1['location'].'</td>
        			            <td>'.date('h:i a',strtotime($row1['outtime'])).'</td>
        			            <td>'.$row1['out_location'].'</td>
        			            <td>'.$row1['duration'].'</td>
        			            <td>&nbsp;</td>
        			            </tr>';
        			}
        		}
        		else
        		{
        		    $result = $result.'<tr style="background-color:#e8a792;"><td colspan="7">No Records Found</td></tr>';
        		}
        		$result = $result.'</table>';
			}
		}
		
		echo $result;
		
	}
	
	
    // get_collection
	if(isset($_POST['action']) && $_POST['action']=='get_collection'){	
	    $sddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['start']);
	    $stdate = $sddate->format('Y-m-d');
	    $eddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['end']);
	    $endate = $eddate->format('Y-m-d');
	    $query = "Select  * from usertable WHERE ustat = '1'";
	  /*  $result = '<div class="col-lg-12"><strong align="center"><h2>HAPPY JOURNEY</h2></strong></div>
	    <div class="col-lg-12"><h3 align="center">SAFAR BUILDING,SOUTH KALAMASSERY,CHANGAMPUZHA NAGAR PO,KOCHI- 682033</h3></div>
	    <div class="col-lg-12"><h3 align="center">Ph: 04842110796,04842110796</h3></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div>*/
	    $result = '<div class="col-lg-12" style="border:2px solid black;"></div> 
	    <div class="col-lg-10"><h4 align="center">COLLECTION REPORT FROM '.date('d-M-Y', strtotime($stdate)).' TO '.date('d-M-Y', strtotime($endate)).'</h4></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h3>Date: '.date('d-M-Y').'</h3></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h3>Time: '.date('h:i a').'</h3></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div>';
	    //<table class="table table-striped table-bordered table-hover dataTables-example">';
	    $sdate = $stdate;
	    $edate = $endate;
	    if($_REQUEST['staff'] != 'All')
	    {
	        $query.= " and uid = '".$_REQUEST['staff']."'";
	    }
	    if($db->num_rows($query))
		{
			$rows = $db->get_results($query);
			foreach($rows as $row) 
			{
			    $result = $result.'<div class="col-lg-12"><h3>EMPLOYEE NAME : '.$row['staffname'].'</h3></div><br>';
			    $result = $result.'<table class="table table-striped table-bordered table-hover dataTables-example">
			             <tr style="background-color:#92959b;"><th>DATE</th>
			             <th>CUSTOMER NAME</th>
			             <th>ADDRESS</th>
			             <th>CHEQUE AMOUNT</th>
			             <th>CASH AMOUNT</th>
			             <th>REMARKS</th></tr>';
			    $query1 = "SELECT receiptchild.*,persons.* FROM receiptchild, persons WHERE receiptchild.sid = '".$row['uid']."' and receiptchild.cid = persons.pid and receiptchild.rdate >= '".$sdate."' and receiptchild.rdate <= '".$edate."'";
				if($db->num_rows($query1))
        		{
        			$rows1 = $db->get_results($query1);
        			foreach($rows1 as $row1) 
        			{
        			    $result = $result.'<tr><td>'.date('d/M/Y', strtotime($row1['rdate'])).'</td>
        			            <td>'.date('h:i a',strtotime($row1['pname'])).'</td>
        			            <td>'.$row1['paddress'].'</td>
        			            <td>'.$row1['chkamt'].'.00</td>
        			            <td>'.$row1['cashamt'].'.00</td>
        			            <td>'.$row1['remarks'].'</td>
        			            </tr>';
        			}
        		}
        		else
        		{
        		    $result = $result.'<tr style="background-color:#e8a792;"><td colspan="6">No Records Found</td></tr>';
        		}
        		$result = $result.'</table>';
			}
		}
		
		echo $result;
		
	}
	

    // get_order
	if(isset($_POST['action']) && $_POST['action']=='get_order'){
	    $sddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['start']);
	    $stdate = $sddate->format('Y-m-d');
	    $eddate = $date = DateTime::createFromFormat('d/m/Y', $_REQUEST['end']);
	    $endate = $eddate->format('Y-m-d');
	    $query = "Select  * from usertable WHERE ustat = '1'";
	    /*$result = '<div class="col-lg-12"><strong align="center"><h2>HAPPY JOURNEY</h2></strong></div>
	    <div class="col-lg-12"><h4 align="center">SAFAR BUILDING,SOUTH KALAMASSERY,CHANGAMPUZHA NAGAR PO,KOCHI- 682033</h4></div>
	    <div class="col-lg-12"><h4 align="center">Ph: 04842110796,04842110796</h4></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div> */
	    $result = '<div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-10"><h4 align="center">ORDER REPORT FROM '.date('d-M-Y', strtotime($stdate)).' TO '.date('d-M-Y', strtotime($endate)).'</h4></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h4>Date: '.date('d-M-Y').'</h4></div>
	    <div class="col-lg-10"></div><div class="col-lg-2"><h4>Time: '.date('h:i a').'</h4></div>
	    <div class="col-lg-12" style="border:2px solid black;"></div>
	    <div class="col-lg-12" style="border:2px solid White;"></div>';
	    //<table class="table table-striped table-bordered table-hover dataTables-example">';
	    $sdate = $stdate;
	    $edate = $endate;
	    if($_REQUEST['staff'] != 'All')
	    {
	        $query.= " and uid = '".$_REQUEST['staff']."'";
	    }
	    if($db->num_rows($query))
		{
			$rows = $db->get_results($query);
			foreach($rows as $row) 
			{
			    $queryorder = "Select ordermaster.*, persons.* from ordermaster, persons WHERE ordermaster.sid = '".$row['uid']."' and ordermaster.pid = persons.pid and ordermaster.odate >= '".$sdate."' and ordermaster.odate <= '".$edate."'";
			    $orderrows = $db->get_results($queryorder);
			    if($db->num_rows($queryorder))
			    {
    			    foreach($orderrows as $orderrow)
    			    {
        			    $result = $result.'<div class="col-lg-9"><h4>To,</h4></div><div class="col-lg-3"><h4>ORDER NO : '.$orderrow['oid'].'</h4></div><br>';
        			    $result = $result.'<div class="col-lg-9"><h4>&nbsp; &nbsp; &nbsp;'.$orderrow['pname'].'</h4></div><div class="col-lg-3"><h4>DATE : '.date('d/M/Y',strtotime($orderrow['odate'])).'</h4></div><br>';
        			   // $result = $result.'<div class="col-lg-12"><h4>To,</h4></div><br>';
        			   // $result = $result.'<div class="col-lg-12"><h4>&nbsp; &nbsp; &nbsp;'.$orderrow['pname'].'</h4></div><br>';
        			    $result = $result.'<div class="col-lg-12"><h4>&nbsp; &nbsp; &nbsp;'.$orderrow['paddress'].'</h4></div><br>';
        			    $result = $result.'<div class="col-lg-12"><h4>&nbsp; &nbsp; &nbsp;</h4></div><br>';
        			    $result = $result.'<table class="table table-striped table-bordered table-hover dataTables-example">
        			             <tr style="background-color:#92959b;"><th>SLNO</th>
        			             <th>GROUP</th>
        			             <th>TYPE</th>
        			             <th>ITEM NAME</th>
        			             <th>QTY</th>
        			             <th>RATE</th>
        			             <th>AMOUNT</th></tr>';
        			    $query1 = "SELECT orderchild.*,itemmaster.*, itemtype.*,groupitem.* FROM orderchild, itemmaster,itemtype,groupitem WHERE orderchild.oid = '".$orderrow['oid']."' and orderchild.imid = itemmaster.imid and itemmaster.tid = itemtype.tid and itemmaster.bid = groupitem.bid";
        				if($db->num_rows($query1))
                		{
                			$rows1 = $db->get_results($query1);
                			$i = 1;
                			$total = 0;
                			foreach($rows1 as $row1) 
                			{
                			    $result = $result.'<tr><td>'.$i.'</td>
                			            <td>'.$row1['bname'].'</td>
                			            <td>'.$row1['typeitem'].'</td>
                			            <td>'.$row1['itemname'].'</td>
                			            <td>'.$row1['qty'].'</td>
                			            <td>'.$row1['rate'].'.00</td>
                			            <td>'.(int)$row1['qty']*(int)$row1['rate'].'.00</td>
                			            </tr>';
                			    $i++;
                			    $total+=(int)$row1['qty']*(int)$row1['rate'];
                			}
                			$result = $result.'<tr style="background-color:#bdbfc1;"><td colspan="3">'.$row['staffname'].'</td><td colspan="3">TOTAL AMOUNT</td><td>'.$total.'.00</td>';
                		}
                		else
                		{
                		    $result = $result.'<tr style="background-color:#e8a792;"><td colspan="7">No Records Found</td></tr>';
                		}
                		$result = $result.'</table>';
    			    }
    			}
    			else
    			{
    			    $result = $result.'<table class="table table-striped table-bordered table-hover dataTables-example">
        			             <tr style="background-color:#92959b;"><th>SLNO</th>
        			             <th>GROUP</th>
        			             <th>TYPE</th>
        			             <th>ITEM NAME</th>
        			             <th>QTY</th>
        			             <th>RATE</th>
        			             <th>AMOUNT</th></tr>';
        			$result = $result.'<tr style="background-color:#e8a792;"><td colspan="7">No Records Found</td></tr>';
        		    $result = $result.'<tr style="background-color:#bdbfc1;"><td colspan="3">'.$row['staffname'].'</td><td colspan="3">TOTAL AMOUNT</td><td>00.00</td>';
        		    $result = $result.'</table>';
    			}
			}
		}
		
		echo $result;
		
	}
	
	//get_mail
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='get_mail')
	{
		if($_REQUEST['readstatus'] == '1')
		{
			$db->query("UPDATE mail_info SET readstatus = '1' WHERE ID='".$db->escape($_REQUEST['mail_id'])."'");
		}
		$query="select * from mail_info where ID='".$db->escape($_REQUEST['mail_id'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);			
			if($row['replyorder'] == '0')
			{	
				$user_details = $db->get_row("Select * from login_and_user_details where id='".$row['login_id']."'");
				echo '<small class="pull-right"><a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a></small>
					<input type="hidden" id="mailid" name = "mailid" value="'.$_REQUEST['mail_id'].'" />
					<input type="hidden" id="emailemail1" name="emailemail1" value="'.$row['frommail'].'"/>
					<input type = "hidden" id="fromemail" name="fromemail" value="'.$row['tomail'].'" />
					<b class="pull-left subject" id="emailsubject">'.$row['subjects'].'</b>							
					<div style="background-color:#1a1a1a;border:1px solid black;">								
					</div>							
					<div class="feed-element" style="border 1px solid red;">
						<a href="profile.html" class="pull-left">
							<img alt="image" class="img-circle" src="img/a7.jpg">
						</a>';
				$olddate = strtotime($row['dateandtime']);
				$newdate = date('Y-m-d', $olddate);
				$newdate1 = date('d.m.Y', $olddate);
				$time = date('h:i A',$olddate);
				$timeDiff1 = "";
				if($newdate == date('Y-m-d'))
				{
					//echo date("Y-m-d h:i:sa");
					$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
					$timeDiff1 = abs($endTimeStamp1 - $olddate);
					$timeDiff1 = round($timeDiff1 / 60);			
					if($timeDiff1 > 59)
					{
						$timeDiff1 = floor($timeDiff1 / 60);
						$timeDiff1 = $timeDiff1."hours ago";																
					}
					else
					{
						$timeDiff1 = $timeDiff1."mins ago";
					}
				}
				else if ($newdate == date('Y-m-d',strtotime("-1 days")))
				{
					$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
					$timeDiff1 = abs($endTimeStamp1 - $olddate);
					$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
				}
				else
				{
					$startTimeStamp = strtotime($newdate);
					$endTimeStamp = strtotime("today");
					$timeDiff1 = abs($endTimeStamp - $startTimeStamp);
					$numberDays = $timeDiff1/86400;  // 86400 seconds in one day
					// and you might want to convert to integer
					$timeDiff1 = intval($numberDays)."days ago";
					//echo $numberDays."days ago";
				}
				echo '<div class="media-body "> 
					<small class="pull-right">'.$timeDiff1.'<button type="button" class="btn btn-icon btn-pure btn-default"><i class="fa fa-reply" aria-hidden="true"></i></button></small>
					<strong id="emailname">'.$user_details['username'].'</strong> <span id = "emailemail"> ('.$row['frommail'].') </span><br>
					<small class="text-muted">to me</small> <br/>
					<small class="text-muted">';
					if($newdate == date('Y-m-d'))
						echo "Today";
					else if ($newdate == date('Y-m-d',strtotime("-1 days")))
						echo "Yesterday";
					else
					{
						$startTimeStamp = strtotime($newdate);
						$endTimeStamp = strtotime("today");
						$timeDiff = abs($endTimeStamp - $startTimeStamp);
						$numberDays = $timeDiff/86400;  // 86400 seconds in one day
						// and you might want to convert to integer
						$numberDays = intval($numberDays);
						echo $numberDays."days ago";
					}															
					echo " ".$time." - ".$newdate1;
					echo '</small>
						<br><br><br>								
						<p  class="pull-left" id="emailmsg">
							'.$row['message'].'	
						</p>
					</div></div>';
				if($row['replystatus'] == '1')
				{					
					$reply_query="select * from mail_info where replyorder='".$db->escape($_REQUEST['mail_id'])."'";
					$reply_row = $db->get_results($reply_query);
					foreach($reply_row as $rows)
					{
						echo '<div style="background-color:#1a1a1a;border:0.5px solid gray;">								
								</div>';
						echo '<div class="feed-element" style="border 1px solid red;">
									<a href="profile.html" class="pull-left">
										<img alt="image" class="img-circle" src="img/a7.jpg">
									</a>';
						$olddate = strtotime($rows['dateandtime']);
						$newdate = date('Y-m-d', $olddate);
						$newdate1 = date('d.m.Y', $olddate);
						$time = date('h:i A',$olddate);
						$timeDiff1 = "";
						if($newdate == date('Y-m-d'))
						{
							//echo date("Y-m-d h:i:sa");
							$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
							$timeDiff1 = abs($endTimeStamp1 - $olddate);
							$timeDiff1 = round($timeDiff1 / 60);			
							if($timeDiff1 > 59)
							{
								$timeDiff1 = floor($timeDiff1 / 60);
								$timeDiff1 = $timeDiff1."hours ago";																
							}
							else
							{
								$timeDiff1 = $timeDiff1."mins ago";
							}
						}
						else if ($newdate == date('Y-m-d',strtotime("-1 days")))
						{
							$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
							$timeDiff1 = abs($endTimeStamp1 - $olddate);
							$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
						}
						else
						{
							$startTimeStamp = strtotime($newdate);
							$endTimeStamp = strtotime("today");
							$timeDiff1 = abs($endTimeStamp - $startTimeStamp);
							$numberDays = $timeDiff1/86400;  // 86400 seconds in one day
							// and you might want to convert to integer
							$timeDiff1 = intval($numberDays)."days ago";
							//echo $numberDays."days ago";
						}
						echo '<div class="media-body "> 
								<small class="pull-right">'.$timeDiff1.'<button type="button" class="btn btn-icon btn-pure btn-default"><i class="fa fa-reply" aria-hidden="true"></i></button></small>
								<strong id="emailname">'.$user_details['username'].'</strong> <span id = "emailemail"> ('.$rows['frommail'].')</span><br>
								<small class="text-muted">to '.$rows['tomail'].'</small> <br/>
								<small class="text-muted">';
						if($newdate == date('Y-m-d'))
							echo "Today";
						else if ($newdate == date('Y-m-d',strtotime("-1 days")))
							echo "Yesterday";
						else
						{
							$startTimeStamp = strtotime($newdate);
							$endTimeStamp = strtotime("today");
							$timeDiff = abs($endTimeStamp - $startTimeStamp);
							$numberDays = $timeDiff/86400;  // 86400 seconds in one day
							// and you might want to convert to integer
							$numberDays = intval($numberDays);
							echo $numberDays."days ago";
						}															
						echo " ".$time." - ".$newdate1;
						echo '</small>
							<br><br><br>								
							<p  class="pull-left" id="emailmsg">
								'.$rows['message'].'	
							</p>
							</div></div>';
					}
				}
			}
			else
			{				
				$replyquery="select * from mail_info where ID='".$db->escape($row['replyorder'])."'";
				$row1= $db->get_row($replyquery);
				$user_details1 = $db->get_row("Select * from login_and_user_details where id='".$row1['login_id']."'");
				echo '<small class="pull-right"><a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a></small>
					<input type="hidden" id="mailid" name = "mailid" value="'.$row['replyorder'].'" />
					<input type="hidden" id="emailemail1" name="emailemail1" value="'.$row1['frommail'].'"/>
					<input type = "hidden" id="fromemail" name="fromemail" value="'.$row1['tomail'].'" />
					<b class="pull-left subject" id="emailsubject">'.$row1['subjects'].'</b>							
					<div style="background-color:#1a1a1a;border:1px solid black;">								
					</div>							
					<div class="feed-element" style="border 1px solid red;">
						<a href="profile.html" class="pull-left">
							<img alt="image" class="img-circle" src="img/a7.jpg">
						</a>';
				$olddate = strtotime($row1['dateandtime']);
				$newdate = date('Y-m-d', $olddate);
				$newdate1 = date('d.m.Y', $olddate);
				$time = date('h:i A',$olddate);
				$timeDiff1 = "";
				if($newdate == date('Y-m-d'))
				{
					//echo date("Y-m-d h:i:sa");
					$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
					$timeDiff1 = abs($endTimeStamp1 - $olddate);
					$timeDiff1 = round($timeDiff1 / 60);			
					if($timeDiff1 > 59)
					{
						$timeDiff1 = floor($timeDiff1 / 60);
						$timeDiff1 = $timeDiff1."hours ago";																
					}
					else
					{
						$timeDiff1 = $timeDiff1."mins ago";
					}
				}
				else if ($newdate == date('Y-m-d',strtotime("-1 days")))
				{
					$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
					$timeDiff1 = abs($endTimeStamp1 - $olddate);
					$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
				}
				else
				{
					$startTimeStamp = strtotime($newdate);
					$endTimeStamp = strtotime("today");
					$timeDiff1 = abs($endTimeStamp - $startTimeStamp);
					$numberDays = $timeDiff1/86400;  // 86400 seconds in one day
					// and you might want to convert to integer
					$timeDiff1 = intval($numberDays)."days ago";
					//echo $numberDays."days ago";
				}
				echo '<div class="media-body "> 
					<small class="pull-right">'.$timeDiff1.'<button type="button" class="btn btn-icon btn-pure btn-default"><i class="fa fa-reply" aria-hidden="true"></i></button></small>
					<strong id="emailname">'.$user_details1['username'].'</strong> <span id = "emailemail"> ('.$row1['frommail'].') </span><br>
					<small class="text-muted">to me</small> <br/>
					<small class="text-muted">';
					if($newdate == date('Y-m-d'))
						echo "Today";
					else if ($newdate == date('Y-m-d',strtotime("-1 days")))
						echo "Yesterday";
					else
					{
						$startTimeStamp = strtotime($newdate);
						$endTimeStamp = strtotime("today");
						$timeDiff = abs($endTimeStamp - $startTimeStamp);
						$numberDays = $timeDiff/86400;  // 86400 seconds in one day
						// and you might want to convert to integer
						$numberDays = intval($numberDays);
						echo $numberDays."days ago";
					}															
					echo " ".$time." - ".$newdate1;
					echo '</small>
						<br><br><br>								
						<p  class="pull-left" id="emailmsg">
							'.$row1['message'].'	
						</p>
					</div></div>';
				if($row1['replystatus'] == '1')
				{
					$reply_query="select * from mail_info where replyorder='".$db->escape($row['replyorder'])."'";
					$reply_row = $db->get_results($reply_query);
					foreach($reply_row as $rows)
					{
						echo '<div style="background-color:#1a1a1a;border:0.5px solid gray;">								
								</div>';
						echo '<div class="feed-element" style="border 1px solid red;">
								<a href="profile.html" class="pull-left">
									<img alt="image" class="img-circle" src="img/a7.jpg">
								</a>';
						$olddate = strtotime($rows['dateandtime']);
					$newdate = date('Y-m-d', $olddate);
					$newdate1 = date('d.m.Y', $olddate);
					$time = date('h:i A',$olddate);
					$timeDiff1 = "";
					if($newdate == date('Y-m-d'))
					{
						//echo date("Y-m-d h:i:sa");
						$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
						$timeDiff1 = abs($endTimeStamp1 - $olddate);
						$timeDiff1 = round($timeDiff1 / 60);			
						if($timeDiff1 > 59)
						{
							$timeDiff1 = floor($timeDiff1 / 60);
							$timeDiff1 = $timeDiff1."hours ago";																
						}
						else
						{
							$timeDiff1 = $timeDiff1."mins ago";
						}
					}
					else if ($newdate == date('Y-m-d',strtotime("-1 days")))
					{
						$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
						$timeDiff1 = abs($endTimeStamp1 - $olddate);
						$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
					}
					else
					{
						$startTimeStamp = strtotime($newdate);
						$endTimeStamp = strtotime("today");
						$timeDiff1 = abs($endTimeStamp - $startTimeStamp);
						$numberDays = $timeDiff1/86400;  // 86400 seconds in one day
						// and you might want to convert to integer
						$timeDiff1 = intval($numberDays)."days ago";
						//echo $numberDays."days ago";
					}
					echo '<div class="media-body "> 
						<small class="pull-right">'.$timeDiff1.'<button type="button" class="btn btn-icon btn-pure btn-default"><i class="fa fa-reply" aria-hidden="true"></i></button></small>
						<strong id="emailname">'.$user_details1['username'].'</strong> <span id = "emailemail"> ('.$rows['frommail'].')</span><br>
						<small class="text-muted">to '.$rows['tomail'].'</small> <br/>
						<small class="text-muted">';
						if($newdate == date('Y-m-d'))
							echo "Today";
						else if ($newdate == date('Y-m-d',strtotime("-1 days")))
							echo "Yesterday";
						else
						{
							$startTimeStamp = strtotime($newdate);
							$endTimeStamp = strtotime("today");
							$timeDiff = abs($endTimeStamp - $startTimeStamp);
							$numberDays = $timeDiff/86400;  // 86400 seconds in one day
							// and you might want to convert to integer
							$numberDays = intval($numberDays);
							echo $numberDays."days ago";
						}															
					echo " ".$time." - ".$newdate1;
					echo '</small>
						<br><br><br>								
						<p  class="pull-left" id="emailmsg">
							'.$rows['message'].'	
						</p>
						</div></div>';
					}
				}
			}
			echo '<div class="slidePanel-comment">    
					<textarea class="maxlength-textarea form-control mb-sm mb-20 form-control" rows="4" id="replymsg" name="replymsg"></textarea>
					<button class="btn btn-primary" data-dismiss="modal" type="button" onclick="reply_mail()">Reply</button>
				</div>';
			
			//echo $row['subjects'].'~';
			//echo $user_details['username'].'~';
			//echo $row['frommail'].'~';			
			//echo $row['message'].'~';
			//echo $row['dateandtime'];
		}
		
		
	}
	
	
	//reply_mail
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='reply_mail')
	{
		if($_REQUEST['readstatus'] == '1')
		{
			$db->query("UPDATE mail_info SET readstatus = '1' WHERE ID='".$db->escape($_REQUEST['mail_id'])."'");
		}
		$query="select * from mail_info where ID='".$db->escape($_REQUEST['mail_id'])."'";
		$num= $db->num_rows($query);	
		if($num)
		{
			$row= $db->get_row($query);
			if($row['replystatus'] == '1')
			{					
				$reply_query="select * from mail_info where replyorder='".$db->escape($_REQUEST['mail_id'])."' order by dateandtime DESC";
				$reply_row = $db->get_results($reply_query);
				foreach($reply_row as $rows)
				{
					$user_details = $db->get_row("Select * from login_and_user_details where id='".$rows['login_id']."'");					
					$olddate = strtotime($rows['dateandtime']);
					$newdate = date('Y-m-d', $olddate);
					$newdate1 = date('d.m.Y', $olddate);
					$time = date('h:i A',$olddate);
					$timeDiff1 = "";
					if($newdate == date('Y-m-d'))
					{
						//echo date("Y-m-d h:i:sa");
						$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
						$timeDiff1 = abs($endTimeStamp1 - $olddate);
						$timeDiff1 = round($timeDiff1 / 60);			
						if($timeDiff1 > 59)
						{
							$timeDiff1 = floor($timeDiff1 / 60);
							$timeDiff1 = $timeDiff1."hours ago";																
						}
						else
						{
							$timeDiff1 = $timeDiff1."mins ago";
						}
					}
					else if ($newdate == date('Y-m-d',strtotime("-1 days")))
					{
						$endTimeStamp1 = strtotime(date("Y-m-d h:i:sa"));
						$timeDiff1 = abs($endTimeStamp1 - $olddate);
						$timeDiff1 = floor($timeDiff1 / 3600)."hours ago";
					}
					else
					{
						$startTimeStamp = strtotime($newdate);
						$endTimeStamp = strtotime("today");
						$timeDiff1 = abs($endTimeStamp - $startTimeStamp);
						$numberDays = $timeDiff1/86400;  // 86400 seconds in one day
						// and you might want to convert to integer
						$timeDiff1 = intval($numberDays)."days ago";
						//echo $numberDays."days ago";
					}
					echo '<div class="social-comment">
					<input type="hidden" id="mailid" name = "mailid" value="'.$_REQUEST['mail_id'].'" />
					<input type="hidden" id="emailemail1" name="emailemail1" value="'.$row['frommail'].'"/>
					<input type = "hidden" id="fromemail" name="fromemail" value="'.$row['tomail'].'" />
                            <a href="" class="pull-left">
                                <img alt="image" src="img/a1.jpg">
                            </a>
                            <div class="media-body">
                                <a href="#">'.$user_details['username'].'</a><br>';
					echo $rows['message'];
					echo '<br>';							
					echo '<small class="text-muted">';
					if($newdate == date('Y-m-d'))
						echo "Today";
					else if ($newdate == date('Y-m-d',strtotime("-1 days")))
						echo "Yesterday";
					else
					{
						$startTimeStamp = strtotime($newdate);
						$endTimeStamp = strtotime("today");
						$timeDiff = abs($endTimeStamp - $startTimeStamp);
						$numberDays = $timeDiff/86400;  // 86400 seconds in one day
						// and you might want to convert to integer
						$numberDays = intval($numberDays);
						echo $numberDays."days ago";
					}															
					echo " ".$time." - ".$newdate1;
					echo '</small>
						</div></div>';
				}
			}
		}
		echo '<div class="social-comment">
                <a href="" class="pull-left">
                    <img alt="image" src="img/a3.jpg">
                </a>
                <div class="media-body">
                    <textarea class="form-control" placeholder="Write message..." id="replymsg"></textarea>
                </div>
				<button class="btn btn-primary" type="button" onclick="reply_mail()">Reply</button>
            </div>';
	}
	
	
	//get_credit
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='get_credit')
	{
		$sel_query = "SELECT * from buyer_details where sys_dis_id = '".$db->escape($_REQUEST['comp_id'])."'";
		$rows = $db->get_row($sel_query);
		$query="select * from credit_limit where buyer_id='".$db->escape($rows['buyer_id'])."'";
		$num= $db->num_rows($query);		  
		if($num)
		{
			$row= $db->get_row($query);
			echo $row['credit_initial'].'~';
			echo $row['credit_utilized'].'~';
			echo $row['credit_balance'];
		}
		else{
			echo '0~';
			echo '0~';
			echo '0';
		}
		
	}
?>			
