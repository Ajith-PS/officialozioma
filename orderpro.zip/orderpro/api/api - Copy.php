<?php
	session_start();
	error_reporting(0);
	include("../includes/config.php");
	include("../includes/functions.php");
	$response = array();
	
	//check_distributorid
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check'){	
		if(!strlen(trim($db->escape($_REQUEST['distributorid']))))echo  "1";
		else
		{
			$query = "SELECT * FROM distributor_details WHERE Dis_id='".$db->escape($_REQUEST['distributorid'])."'";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	//check_username
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='check_username'){	
		if(!strlen(trim($db->escape($_REQUEST['username']))))echo  "1";
		else
		{
			$query = "SELECT * FROM distributor WHERE username='".$db->escape($_REQUEST['username'])."'";
			if($db->num_rows($query)) echo "2";
			else
			{ echo "3";
			}
		}
		
	}
	
	$file = 'people.txt';
	$current = file_get_contents($file);
	$current .= $_SERVER['REQUEST_URI']."-".date("Y-m-d H:i:s")."\n";//implode(",",$_REQUEST);
	file_put_contents($file, $current);
	//Output
	header('Content-Type: application/json');
	
	
	// json_encode($response);
	
	
	
	
	
	
	
	exit;
	?>			
