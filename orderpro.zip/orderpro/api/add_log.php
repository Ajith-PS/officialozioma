<?php
	date_default_timezone_set('Asia/Kolkata');
	class add_log
	{
		public function log_details($fullname, $role, $userid, $msg)
		{
			session_start();
			global $db;
			$dt = date("Y-m-d h:i:s", time());
			$query = "INSERT INTO Log_details  SET full_name='".$db->escape($fullname)."', role='".$db->escape($role)."', user_id='".$db->escape($userid)."', message='".$db->escape($msg)."', added_by='".$db->escape($_SESSION['auserid'])."', dateandtime=NOW()";
			if($db->query($query))  return 1;
			else
			{ return 0;
			}
		}
		
	}
		
?>