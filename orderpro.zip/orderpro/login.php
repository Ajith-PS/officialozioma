<?php 
	session_start(); 
	include("includes/config.php");
	if(isset($_SESSION['auserid']) && $_SESSION['auserid']!='') { 
		
		if(isset($_SESSION['role']) && $_SESSION['role'] =='owner') { 
			echo "<script>location.replace('owner/index.php?p=home');</script>"; 
			
		}
		else if(isset($_SESSION['role']) && $_SESSION['role']=='admin') { 
			echo "<script>location.replace('admin/index.php?p=home');</script>"; 
			
		}
		else if(isset($_SESSION['role']) && $_SESSION['role']=='suppliers') { 
			echo "<script>location.replace('suppliers/index.php?p=home');</script>"; 
			
		}
		else if(isset($_SESSION['role']) && $_SESSION['role']=='buyers') { 
			echo "<script>location.replace('buyers/index.php?p=home');</script>"; 
			
		}
		else if(isset($_SESSION['role']) && $_SESSION['role']=='purchasemanager') { 
			echo "<script>location.replace('purchasemanager/index.php?p=home');</script>"; 
			
		}
		else if(isset($_SESSION['role']) && $_SESSION['role']=='salesmanager') { 
			echo "<script>location.replace('salesmanager/index.php?p=home');</script>"; 
			
		}
		
		else if(isset($_SESSION['role']) && $_SESSION['role']=='plantmanager') { 
			echo "<script>location.replace('plantmanager/index.php?p=home');</script>"; 
			
		}
	}
	
	if(isset($_POST['btn_login']))
	{
		$error='';
		if(!strlen(trim($_POST['email']))) $error.='Please enter email id.<br />';
		if(!strlen(trim($_POST['password']))) $error.='Please enter Password.';
		if($error=='')
		{
		    $pass = MD5($_POST['password']);
	echo		$query="select * from usertable where username='".$db->escape($_POST['email'])."' and password='".$db->escape($pass)."' and ustat=1";
			$num= $db->num_rows($query);
			
			if($num)
			{
				$row= $db->get_row($query);
				$_SESSION['auserid']=$row['id'];
				$_SESSION['role']=$row['role'];
				$_SESSION['username']=$row['username'];
				$_SESSION['email']=$row['email'];
				if(isset($_POST['remember']))
				{
					$year = time() + 31536000;
					setcookie('remember_me', $_POST['email'], $year);  
				}
				else
				{
					if(isset($_COOKIE['remember_me'])) 
					{
						$past = time() - 100;
						setcookie('remember_me', gone, $past);
					}
				}
				if(isset($_SESSION['role']) && $_SESSION['role'] =='owner') { 
					echo "<script>location.replace('owner/index.php?p=home');</script>"; 
					
				}
				else if(isset($_SESSION['role']) && $_SESSION['role']=='admin') { 
					echo "<script>location.replace('admin/index.php?p=home');</script>"; 
					
				}
				else if(isset($_SESSION['role']) && $_SESSION['role']=='suppliers') { 
					echo "<script>location.replace('suppliers/index.php?p=home');</script>"; 
					
				}
				else if(isset($_SESSION['role']) && $_SESSION['role']=='buyer') { 
					echo "<script>location.replace('buyers/index.php?p=home');</script>"; 
					
				}
				else if(isset($_SESSION['role']) && $_SESSION['role']=='purchasemanager') { 
					echo "<script>location.replace('purchasemanager/index.php?p=home');</script>"; 
					
				}
				else if(isset($_SESSION['role']) && $_SESSION['role']=='salesmanager') { 
					echo "<script>location.replace('salesmanager/index.php?p=home');</script>"; 
					
				}
				
				else if(isset($_SESSION['role']) && $_SESSION['role']=='plantmanager') { 
					echo "<script>location.replace('plantmanager/index.php?p=home');</script>"; 
					
				}
			}
			else $error.='Please enter valid details.';
		}
	}
?>
<!DOCTYPE html>
<html>
	
	<head>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<title><?php echo SITE_NAME;?> | Login</title>
		
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="font-awesome/css/font-awesome.css" rel="stylesheet">
		
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
		
	</head>
	
	<body class="gray-bg">
		
		<div class="middle-box text-center loginscreen animated fadeInDown">
			<div>
				<!--<h3><?php //echo SITE_NAME;?></h3>-->
				<img src="../images/logo-7.png" alt="" width="155" height="82" data-normal="" data-trans="" style="display: inline-block;/* width: 100%; */margin-bottom: 3%;">
				<p><?php if(isset($error)) echo '<span style="color:#F00;">'.$error.'</span>'; else echo 'Login in. To see it in action.';?></p>
				<form class="m-t" role="form" method="post">
					<div class="form-group">
						<input type="text" name="email" class="form-control" placeholder="Username" required="">
					</div>
					<div class="form-group">
						<input type="password" name="password" class="form-control" placeholder="Password" required="">
					</div>
					<button type="submit" class="btn btn-primary block full-width m-b" name="btn_login">Login</button>
					
					<!--<a href="#"><small>Forgot password?</small></a>
						<p class="text-muted text-center"><small>Do not have an account?</small></p>
					<a class="btn btn-sm btn-white btn-block" href="register.html">Create an account</a>-->
				</form>
			</div>
		</div>
		
		<!-- Mainly scripts -->
		<script src="js/jquery-2.1.1.js"></script>
		<script src="js/bootstrap.min.js"></script>
		
	</body>
	
</html>
