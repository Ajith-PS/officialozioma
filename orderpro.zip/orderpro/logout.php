<?php session_start();
unset($_SESSION['auserid']);
unset($_SESSION['usertype']);
unset($_SESSION['username']);
session_destroy();
echo '<script>window.location.href="../orderpro/index.php";</script>';
?>