//BaseURL

var path = "http://promptmate.com.au/";