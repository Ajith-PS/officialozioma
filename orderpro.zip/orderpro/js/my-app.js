// Initialize your app
var myApp = new Framework7({
    animateNavBackIcon: true,
    // Enable templates auto precompilation
    precompileTemplates: false,
	onPageInit: function (app, page) {
		//Home
		if(page.name=='home'){
			$.post(path+'api/api.php?action=loadHome',function(data){
				$('.page[data-page="home"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Posts
		if(page.name=='posts'){
			$.post(path+'api/api.php?action=loadPosts',function(data){
				$('.page[data-page="posts"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Profile
		if(page.name=='profile'){
			$.post(path+'api/api.php?action=getProfile',function(data){
				$('.page[data-page="profile"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Profile
		if(page.name=='editprofile'){
			$.post(path+'api/api.php?action=editProfile',function(data){
				$('.page[data-page="editprofile"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Signup
		if(page.name=='signup'){
			//Calendar
			var myCalendar = myApp.calendar({
				input: '#calendar-input'
			});  
		}
		//Connections
		if(page.name=='connections'){
			$.post(path+'api/api.php?action=getConnections',function(data){
				$('.page[data-page="connections"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Chat
		if(page.name=='chat'){
			$.post(path+'api/api.php?action=getPrevchat&rid='+page.query.id,function(data){
				$('.page[data-page="chat"]').find('.mdl-layout__content').html(data.output);
				document.getElementById('chat-area').scrollTop = document.getElementById('chat-area').scrollHeight;
			});
			$('#rid').val(page.query.id);
			$.post(path+'api/api.php?action=getMychat',function(data){
				$('#mychatname').val(data.mychatname);
				$('#mychatimage').val(data.mychatimage);
			});
			setInterval('updateChat()', 1000);
		}
		//inbox
		if(page.name=='inbox'){
			$.post(path+'api/api.php?action=inbox',function(response){
				var len = response.data.length;
				var txt = "";
				if(len > 0)
				{
					txt += '<div class="item"><ul class="chat">';
					$.each( response.data, function( index, value ){
						txt +=	'<div class="conn-row-fld" onclick="startChat('+value.uid+');">';
						txt +=	'<div class="pro-img"> <img src="'+value.uimage+'" alt="profile-img" /></div>';
						txt +=	'<div class="pro-mid">';
						txt +=	  '<h3>'+value.uname+'</h3>';
						//txt +=	  '<span>Hello</span>';
						txt +=	  ' </div>';
						txt +=	'<div class="pro-last">';
						txt +=	  '<h3>('+value.count+')</h3>';
						txt +=	'</div>';
						txt +=  '</div>';						
					});
					txt += '</ul></div>';
					$('.page[data-page="inbox"]').find('.mdl-layout__content').html(txt);
				}
			});
		}
		//notifications
		if(page.name=='notifications'){
			$.post(path+'api/api.php?action=getNotifications',function(data){
				$('.page[data-page="notifications"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Edit Work
		if(page.name=='editwork'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getWork&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="company"]').val(data.company);
					$('input[name="designation"]').val(data.designation);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		if(page.name=='editeducation'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getEducation&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="institute"]').val(data.institute);
					$('input[name="course"]').val(data.course);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		if(page.name=='editvolunteer'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getVolunteer&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="institute"]').val(data.institute);
					$('input[name="volunteering"]').val(data.volunteering);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		if(page.name=='editaward'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getAwards&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="institute"]').val(data.institute);
					$('input[name="award"]').val(data.award);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		if(page.name=='editaccomplish'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getAccomplishment&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="institute"]').val(data.institute);
					$('input[name="accomplishment"]').val(data.accomplishment);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		if(page.name=='editcourse'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$.post(path+'api/api.php?action=getCourses&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="institute"]').val(data.institute);
					$('input[name="course"]').val(data.course);
					$('input[name="year"]').val(data.year);
				});
			}
		}
		//Companies
		if(page.name=='companies'){
			$.post(path+'api/api.php?action=getCompanies',function(data){
				$('.page[data-page="companies"]').find('.mdl-layout__content').html(data.output);
			});
		}
		//Edit Company		
		if(page.name=='editcompany'){
			var editid = page.query.editid;
			if(editid!='' && editid!=undefined){
				$('span.mdl-layout-title').html('Edit Company');
				$.post(path+'api/api.php?action=getCompany&id='+editid,function(data){
					$('input[name="editid"]').val(editid);
					$('input[name="name"]').val(data.name);
					$('textarea[name="description"]').val(data.description);
					$('input[name="company_type"]').val(data.company_type);
					$('input[name="company_size"]').val(data.company_size);
					$('input[name="website"]').val(data.website);
					$('input[name="email"]').val(data.email);
					$('input[name="phone"]').val(data.phone);
					$('input[name="operating_hours"]').val(data.operating_hours);
					$('input[name="location"]').val(data.location);
					$('input[name="industry"]').val(data.industry);
					$('input[name="founded"]').val(data.founded);
					$('input[name="logo"]').after('<div><img src="'+data.logo+'" style="width:73px;height:55px;" alt="#"></div>');
					$('input[name="banner"]').after('<div><img src="'+data.banner+'" style="width:73px;height:55px;" alt="#"></div>');
				});
			}
		}
	},
	onPageBeforeInit: function (app, page) {
		//CheckLogin
		if(page.name=='index'){
			$.post(path+'api/api.php?action=checkLogin',function(response) {			
				if(response.status=='Success'){
					mainView.router.loadPage('home.html');					
				}
			});
		}
	},
    // Enabled pages rendering using Template7
	swipeBackPage: true,
	pushState: true,
    template7Pages: true
});

// Export selectors engine
var $$ = Dom7;

// Add main View
var mainView = myApp.addView('.view-main', {
    // Enable dynamic Navbar
    dynamicNavbar: true,
});

$$(document).on('pageInit', function (e) {
  		$(".swipebox").swipebox();
		$(".videocontainer").fitVids();
		
		$("#loginForm").validate({
			submitHandler: function(form) {
				ajaxLogin(form);
				return false;
			}
		});
		
		$("#ContactForm").validate({
			submitHandler: function(form) {
			ajaxContact(form);
			return false;
			}
		});
		
		$("#RegForm").validate({
			rules: {
				UserPassword: "required",
				UserConfirmPassword: {
					equalTo: "#UserPassword"
				}
			},
			messages:{
				UserConfirmPassword: {
					equalTo: "Password does not match"
				}
			},
			submitHandler: function(form) {
				ajaxRegister(form);
				return false;
			}
		});
		
		$("#reffinalForm").validate({
			submitHandler: function(form) {
			ajaxCompleteRegister(form);
			return false;
			}
		});
		
		$("#postForm").validate({
			submitHandler: function(form) {
			ajaxPost(form);
			return false;
			}
		});
		$("#postNextform").validate({
			submitHandler: function(form) {
			ajaxPostnext(form);
			return false;
			}
		});		
		$("#editProfForm").validate({
			submitHandler: function(form) {
			ajaxEditprofile(form);
			return false;
			}
		});	
		$("#editWork").validate({
			submitHandler: function(form) {
			ajaxEditwork(form);
			return false;
			}
		});	
		$("#editEducation").validate({
			submitHandler: function(form) {
			ajaxEditeducation(form);
			return false;
			}
		});	
		$("#editVolunteer").validate({
			submitHandler: function(form) {
			ajaxEditvolunteer(form);
			return false;
			}
		});	
		$("#editAward").validate({
			submitHandler: function(form) {
			ajaxEditaward(form);
			return false;
			}
		});	
		$("#editAccomplish").validate({
			submitHandler: function(form) {
			ajaxEditaccomplish(form);
			return false;
			}
		});	
		$("#editCourse").validate({
			submitHandler: function(form) {
			ajaxEditCourse(form);
			return false;
			}
		});
		$("#editCompany").validate({
			submitHandler: function(form) {
			ajaxEditcompany(form);
			return false;
			}
		});
		
		$(".posts li").hide();	
		size_li = $(".posts li").size();
		x=3;
		$('.posts li:lt('+x+')').show();
		$('#loadMore').click(function () {
			x= (x+1 <= size_li) ? x+1 : size_li;
			$('.posts li:lt('+x+')').show();
			if(x == size_li){
				$('#loadMore').hide();
				$('#showLess').show();
			}
		});


		
	$("a.switcher").bind("click", function(e){
		e.preventDefault();
		
		var theid = $(this).attr("id");
		var theproducts = $("ul#photoslist");
		var classNames = $(this).attr('class').split(' ');
		
		
		if($(this).hasClass("active")) {
			// if currently clicked button has the active class
			// then we do nothing!
			return false;
		} else {
			// otherwise we are clicking on the inactive button
			// and in the process of switching views!

  			if(theid == "view13") {
				$(this).addClass("active");
				$("#view11").removeClass("active");
				$("#view11").children("img").attr("src","images/switch_11.png");
				
				$("#view12").removeClass("active");
				$("#view12").children("img").attr("src","images/switch_12.png");
			
				var theimg = $(this).children("img");
				theimg.attr("src","images/switch_13_active.png");
			
				// remove the list class and change to grid
				theproducts.removeClass("photo_gallery_11");
				theproducts.removeClass("photo_gallery_12");
				theproducts.addClass("photo_gallery_13");

			}
			
			else if(theid == "view12") {
				$(this).addClass("active");
				$("#view11").removeClass("active");
				$("#view11").children("img").attr("src","images/switch_11.png");
				
				$("#view13").removeClass("active");
				$("#view13").children("img").attr("src","images/switch_13.png");
			
				var theimg = $(this).children("img");
				theimg.attr("src","images/switch_12_active.png");
			
				// remove the list class and change to grid
				theproducts.removeClass("photo_gallery_11");
				theproducts.removeClass("photo_gallery_13");
				theproducts.addClass("photo_gallery_12");

			} 
			else if(theid == "view11") {
				$("#view12").removeClass("active");
				$("#view12").children("img").attr("src","images/switch_12.png");
				
				$("#view13").removeClass("active");
				$("#view13").children("img").attr("src","images/switch_13.png");
			
				var theimg = $(this).children("img");
				theimg.attr("src","images/switch_11_active.png");
			
				// remove the list class and change to grid
				theproducts.removeClass("photo_gallery_12");
				theproducts.removeClass("photo_gallery_13");
				theproducts.addClass("photo_gallery_11");

			} 
			
		}

	});	
	
	document.addEventListener('touchmove', function(event) {
	   if(event.target.parentNode.className.indexOf('navbarpages') != -1 || event.target.className.indexOf('navbarpages') != -1 ) {
		event.preventDefault(); }
	}, false);
	
	var ScrollFix = function(elem) {
		if(!elem)
			return;
		// Variables to track inputs
		var startY = startTopScroll = deltaY = undefined,
	
		elem = elem || elem.querySelector(elem);
	
		// If there is no element, then do nothing	
		if(!elem)
			return;
	
		// Handle the start of interactions
		elem.addEventListener('touchstart', function(event){
			startY = event.touches[0].pageY;
			startTopScroll = elem.scrollTop;
	
			if(startTopScroll <= 0)
				elem.scrollTop = 1;
	
			if(startTopScroll + elem.offsetHeight >= elem.scrollHeight)
				elem.scrollTop = elem.scrollHeight - elem.offsetHeight - 1;
		}, false);
	};	
	// Add ScrollFix
	var scrollingContent = document.getElementById("pages_maincontent");
	new ScrollFix(scrollingContent);	
})
