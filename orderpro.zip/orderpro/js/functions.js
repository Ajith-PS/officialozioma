//Init
jQuery(document).ready(function(){
	$("#promptForm1").validate({
		submitHandler: function(form) {
			//ajaxProfileupdate(form);
			form.submit();
			return true;
		}
	});
	$("#regForm1").validate({
		submitHandler: function(form) {
			ajaxRegform(form);
			return false;
		}
	});
	$("#changeId").validate({
		rules : {
               password : {
                    minlength : 5
               },
               confirm_password : {
                    minlength : 5,
                    equalTo : "#password"
               }
       },
		submitHandler: function(form) {
			ajaxChangeform(form);
			return false;
		}
	});
	$(document).on("click",".open-panel",function(){
		$('body').addClass('with-panel-left-cover');
		$('.panel-left').addClass('active');
	});
	$(document).on("click",".close-panel,.mdl-layout__content",function(){
		$('body').removeClass('with-panel-left-cover');
		$('.panel-left').removeClass('active');
	});
	$(document).swipe( {
		swipe:function(event, direction, distance, duration, fingerCount, fingerData) {
		  if(direction=='left'){
			  $('.panel-left').removeClass('active');
		  }
		  if(direction=='right'){
			  $('.panel-left').addClass('active');
		  }
		},
		allowPageScroll:"vertical", 
		preventDefaultEvents:false
	});
});
function ajaxChangeform(theForm){
	var $ = jQuery;
	$('.success,.error').html('');
	var formData = $(theForm).serialize();
	$.ajax({
		type: "POST",
		url: "api/api.php?action=doChangepass",
		data: formData,
		success: function(response) {		
			if(response.status=='success'){	
				$('.success').html(response.message);
				jQuery('#changeId input[type="password"]').val('');
				closePopup();
			}
			else{
				$('.error').html(response.message);
			}
		}
	});
	return false;
}
function ajaxProfileupdate(theForm) {
	var $form    = theForm;
	var formData = new FormData();
    var params   = $($form).serializeArray();
    if($('[name="profile_pic"]').val()!=''){
		var files    = $($form).find('[name="profile_pic"]')[0].files;
		$.each(files, function(i, file) {
			formData.append('profile_pic' + i, file);
		});
	}
    $.each(params, function(i, val) {
        formData.append(val.name, val.value);
    });
	
	$.ajax({
		type: "POST",
		url: path+"api/api.php?action=doProfileupdate",
		dataType: "json",
		data: formData,
		mimeType: "multipart/form-data",
		contentType: false,
		processData: false
	}).done(function (response) {
		if(response.status=='success'){	
			$('.success').html(response.message);
		}
	});
	return false;
}
function ajaxRegform(theForm) {
	var $ = jQuery;
	var formData = $(theForm).serialize();
	$.ajax({
		type: "POST",
		url: path+"api/api.php?action=doRegcont",
		data: formData,
		success: function(response) {		
			if(response.status=='success'){	
				$('.success').html(response.message);
				location.replace('home.html?user_id='+response.user_id);
			}
		}
	});
	return false;	
}
function ajaxStepform(theForm) {
	var $ = jQuery;
	var formData = $(theForm).serialize();
	$.ajax({
		type: "POST",
		url: path+"api/api.php?action=doStepcont",
		data: formData,
		success: function(response) {		
			if(response.status=='success'){	
				$('.success').html(response.message);
				location.replace('home.html?user_id='+response.user_id);
			}
		}
	});
	return false;	
}
function openPopup1(){
	$('#light1').fadeIn();
	$('#fade').fadeIn();
}
function openPopup2(){
	$('#light2').fadeIn();
	$('#fade').fadeIn();
}
function openPopup3(){
	$('#light3').fadeIn();
	$('#fade').fadeIn();
}
function openPopup4(content,e){
	if(e.pageX>320){		
		if($(e.target).parent('a').parent('li').hasClass('active')){
			
		}
		else{
			$('#light4 .popcontent').html(content);
			$('#light4').fadeIn();
			$('#fade').fadeIn();
			$(e.target).parent('a').parent('li').addClass('active')
		}
	}
}
function openPopup5(id,e){
	if(e.pageX>320){	
		if($(e.target).parent('a').parent('li').hasClass('active')){
			
		}
		else{	
			if(confirm("Are you sure to delete prompt?")){
				location.replace("promptlist.html?delete="+id);
			}
		}
	}
}
function openPopup6(){
	if($('#light6').length>0){
		$('#light6').fadeIn();
		$('#fade').fadeIn();
	}
}
function openPopupChange(){
	$('#light5').fadeIn();
	$('#fade').fadeIn();
}
function closePopup(){
	$('#category_id').val('');
	$('.white_content').hide();
	$('#fade').hide();
}
function load(){
}
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('#uploadBtn').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]);
    }
}
$("#imgInp").change(function(){
    readURL(this);
});