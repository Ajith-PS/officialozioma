var pictureSource;   // picture source
var destinationType; // sets the format of returned value

// Wait for device API libraries to load
//
document.addEventListener("deviceready",onDeviceReady,false);

// device APIs are available
//
function onDeviceReady() {
    pictureSource = navigator.camera.PictureSourceType;
    destinationType = navigator.camera.DestinationType;
}


// Called when a photo is successfully retrieved
//
function onPhotoURISuccess(imageURI) {
	if($('.selimg').length>=6){
		alert('You can add only 6 photos');
		$('#popup2').hide();
	}
	else{
		var im='<img class="selimg" src="data:image/jpeg;base64,'+imageURI+'" width="75px" height="70px;" align="left">';
		$('#popup2').hide();
		$('#selectedimages').append(im);
	}
    // Show the selected image
    //var smallImage = document.getElementById('smallImage');
    //smallImage.style.display = 'block';
    //smallImage.src = imageURI;
}


// A button will call this function
//
function getPhoto(source) {
  // Retrieve image file location from specified source
	navigator.camera.getPicture(onPhotoURISuccess, onFail, { quality: 50,
	destinationType: destinationType.FILE_URI,
	sourceType: source });
}

function capturePhoto() {
    navigator.camera.getPicture(onPhotoDataSuccess, onFail, {
        quality : 50,
        destinationType : destinationType.FILE_URI
    });
}
function onPhotoDataSuccess(imageURI){
  if($('.selimg').length<6){
  	var im='<div class="photo_1"><a class="clo" onclick="$(this).parent().remove();">x</a><img class="selimg" src="'+imageURI+'" style="width:100%" align="left"></a>';
  	$('#popup2').hide();
  	$('#selectedimages').append(im);
  }
  else{
    $('#popup2').hide();
  }
}
function uploadPhotoTest() {

    //selected photo URI is in the src attribute (we set this on getPhoto)
    var imageURI = document.getElementById('smallImage').getAttribute("src");
    if (!imageURI) {
        alert('Please select an image first.');
        return;
    }

    //set upload options
    /*var options = new FileUploadOptions();
    options.fileKey = "file";
    options.fileName = imageURI.substr(imageURI.lastIndexOf('/')+1);
    options.mimeType = "image/jpeg";

    options.params = {
        firstname: document.getElementById("firstname").value,
        lastname: document.getElementById("lastname").value,
        workplace: document.getElementById("workplace").value
    }*/

    var ft = new FileTransfer();
    ft.upload(imageURI, encodeURI(path + "api/api.php?action=uploadimage"), win, fail, options);
}

// Called if something bad happens.
//
function onFail(message) {
  console.log('Failed because: ' + message);
}

function win(r) {
    console.log("Code = " + r.responseCode);
    console.log("Response = " + r.response);
    //alert("Response =" + r.response);
    console.log("Sent = " + r.bytesSent);
}

function fail(error) {
    alert("An error has occurred: Code = " + error.code);
    console.log("upload error source " + error.source);
    console.log("upload error target " + error.target);
}

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
			if($('.selimg').length>=6){
				alert('You can add only 6 photos');
				$('#popup2').hide();
			}
			else{
				var im='<div class="photo_1"><a onclick="$(this).parent().remove();">x</a><img class="selimg" src="'+e.target.result+'" width="75px" height="70px;" align="left"></div>';
				$('#popup2').hide();
				$('#selectedimages').append(im);
			}
        }
        reader.readAsDataURL(input.files[0]);
    }
}
function getPics() {

    imagePicker.getPictures(
        function (result) {
          var content = '';
          for (var i = 0; i < result.length; i++) {
            if($('.selimg').length<6){
              content = '<div class="photo_1"><a onclick="$(this).parent().remove();">x</a><img class="selimg" src="' + result[i] + '" width="75px" height="70px;" align="left"/></div>';
              $('#selectedimages').append(content);
            }
            else{
              $('#popup2').hide();
            }            
            //content += '<img src="data:image/jpg;base64,'+result[i]+'" style="max-width:200px"/>';
          }
          //document.getElementById("selectedimages").innerHTML = content;
		  $('#popup2').hide();
        }, function (error) {
          //alert('Error: ' + error);
        }, {
          // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
          maximumImagesCount: 6,
          title: 'Select pix',
          message: 'Pick max 6 items', // optional default no helper message above the picker UI
          // be careful with these options as they require additional processing
          width: 400,
          quality: 80
          //             outputType: imagePicker.OutputType.BASE64_STRING
        }
    );
  }
  function uploadPhoto(ids) {
	var ic=0;
    if($('.selimg').length>0){
		$('.selimg').each(function(){
			var img = $(this);
			var imageURI = $(img).attr('src');
			var ft = new FileTransfer();
			ft.upload(imageURI, encodeURI(path + "api/api.php?action=uploadimage&ids="+ids+"&ic="+ic));
			//$.post(path + "api/api.php?action=uploadimage&ids="+ids+"&ic="+ic,{file:imageURI});
			ic++;
			//alert(ic);
		});
	}
  }
